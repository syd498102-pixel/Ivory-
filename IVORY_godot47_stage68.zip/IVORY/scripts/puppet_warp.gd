class_name PuppetWarp
extends Node2D
## Bending a drawing by pinning it and pulling.

## You put pins on the artwork. The pins you hold still hold the drawing
## still; the pin you drag takes the drawing with it, and everything in
## between bends the way paper bends rather than sliding apart.
##
## ## The deformation
##
## Rigid Moving Least Squares (Schaefer, McPhail and Warren, 2006). For every
## point on the mesh it asks: *what single rotation and translation best
## explains where all the pins moved, as seen from here?* Near a pin that pin
## dominates the answer and the drawing follows it exactly. Between two pins
## the answer blends, and because the answer is a rotation rather than a
## slide, the drawing turns instead of smearing.
##
## Three properties follow, and they are the whole difference from a falloff
## scheme that simply adds up weighted movements:
##
##   * **Absolute, not incremental.** Every solve is computed from the rest
##     pose, so dragging a pin back returns the drawing exactly. Nothing
##     accumulates.
##   * **It interpolates.** A point under a pin lands on that pin.
##   * **Rigid.** Only rotation and position are fitted, never scale, so ink
##     keeps its thickness and a face does not smear while an arm is moved.
##
## ## The mesh follows the ink, and distance runs through it
##
## The mesh used to be a plain rectangle over the drawing's bounding box, and
## measured every distance in a straight line. Both are wrong for any shape
## that is not roughly a blob, and a **U** shows why: the two arms are a few
## pixels apart across the gap, and a long way apart through the drawing. A
## pin on one arm was therefore treated as being right beside the other, and
## pulling it dragged ink that nothing connects it to — a pull arriving from
## across empty space.
##
## So the mesh is built only where there is ink, and distance is measured by
## walking the mesh rather than by crossing the gap. On the U, a pin on the
## left arm is now the full length of the bend away from the right arm, which
## is the truth, and the deformation follows the shape.
##
## Building on the ink also costs less: the empty half of a U's bounding box
## carried about as many triangles as the drawing did, and they were solved
## every frame to move nothing. That saving is spent on a finer mesh, which
## is what makes the bend smooth — the warp is exact only where the mesh has
## a vertex, and between vertices a triangle carries the drawing flat.

signal changed()

const MIN_CELLS: int = 16
const MAX_CELLS: int = 88
const MAX_BAKE: int = 4096
## Below this many pins there is no rotation to find, so the drawing is
## simply carried.
const RIGID_FROM: int = 2
## Alpha under this is not ink. Low, because an antialiased edge fades a long
## way down and the mesh should reach past the last visible pixel.
const INK_FLOOR: float = 0.004
## Unreachable — a piece of drawing no path connects to this pin.
const FAR: float = 1.0e20

class Pin extends RefCounted:
	## Where the pin was placed, in page coordinates. Never changes while the
	## pin exists — every solve is measured from here.
	var rest: Vector2 = Vector2.ZERO
	## Where it is now.
	var now: Vector2 = Vector2.ZERO
	## Pinned down: it holds the drawing but cannot be dragged, so a hand can
	## never move an anchor by accident while reaching past it.
	var anchored: bool = false
	## Which side of a fold this pin's part of the drawing is on. Higher is
	## nearer the viewer.
	var depth: int = 0
	## The mesh vertex this pin sits on. Distances are measured outwards from
	## here through the mesh.
	## Which mesh vertex this pin sits on. Named `vertex` rather than `seed`
	## because `seed` is a built-in function and the compiler says so.
	var vertex: int = -1

# --- what is being bent ---
var rect: Rect2i = Rect2i()
var source: Image = null
var pins: Array = []

# --- how it is bent ---
## How sharply a pin's own neighbourhood belongs to it. Higher makes each
## pin's grip more local; lower lets the whole drawing answer to every pin.
var stiffness: float = 1.0
## The radius, in page units, over which a pin's pull is spread instead of
## concentrated on a single point.
##
## Straight inverse-square weighting divides by the distance to the pin, and
## at the pin itself that distance is nothing — the weight runs away to
## infinity. The result is a tiny, absolutely rigid disc at each pin with the
## rest of the drawing bending around it, which on a stroke reads as a kink
## exactly where the finger is. A radius under the distance keeps the weight
## finite and turns that kink into a curve:
##
##     w = 1 / (d² + softness²) ^ stiffness
##
## Well past `softness` this is the same inverse-square falloff it always
## was. Close in, it is the thing that was missing.
var softness: float = 7.0
## How hard the mesh is relaxed towards a smooth surface after solving.
var smoothing: float = 0.4
## How strongly triangles resist being squashed.
var area_keep: float = 0.55

var show_mesh: bool = true
var zoom: float = 1.0
## The pin the hand last touched — what the panel's controls act on.
var selected: int = -1

## How fine the mesh currently is, in cells across its longest side.
##
## Public because the panel's Grid slider used to open at a hardcoded 34
## whatever the mesh actually was, so the first touch of it jumped the
## drawing to a density nobody asked for.
var cells: int = 34

var _tex: ImageTexture = null
var _mesh_node: MeshInstance2D = null

# --- the mesh ---
var _cols: int = 0
var _rows: int = 0
var _cell: Vector2 = Vector2.ONE
## Grid slot -> vertex index, or -1 where the drawing has no ink.
var _slot: PackedInt32Array = PackedInt32Array()
## Vertex index -> grid slot, for neighbour lookups.
var _home: PackedInt32Array = PackedInt32Array()
var _rest_v: PackedVector2Array = PackedVector2Array()
var _now_v: PackedVector2Array = PackedVector2Array()
var _uv: PackedVector2Array = PackedVector2Array()
## The triangles as the grid built them, before depth has any say. `_index`
## is this same list put in drawing order.
var _tris: PackedInt32Array = PackedInt32Array()
var _index: PackedInt32Array = PackedInt32Array()
## Four neighbours per vertex, -1 where the mesh ends. Flat, four per vertex.
var _near: PackedInt32Array = PackedInt32Array()
## True where a vertex sits on the outline of the mesh.
var _rim: PackedByteArray = PackedByteArray()

# --- solving ---
var _weights: PackedFloat32Array = PackedFloat32Array()
## Distance from each pin to every vertex, measured through the mesh. One
## array per pin. Costly to work out and completely unaffected by dragging,
## so it is built when the pins change and then simply read.
var _reach: Array = []
var _rest_area: PackedFloat32Array = PackedFloat32Array()
## Per vertex, how completely it belongs to a pin. Near 1 the vertex is doing
## what a pin told it to and must be left alone by the relaxation passes.
var _hold: PackedFloat32Array = PackedFloat32Array()
var _fix: PackedVector2Array = PackedVector2Array()
var _order_dirty: bool = true
var _reach_dirty: bool = true

func _ready() -> void:
	z_index = 40

# ------------------------------------------------------------------ set up

## Takes a picture of a layer and builds a mesh over its ink. Returns false
## when there is nothing on the layer worth bending.
func begin(image: Image, region: Rect2i, density: int = 34) -> bool:
	if image == null or region.size.x < 4 or region.size.y < 4:
		return false
	source = image
	rect = region
	_tex = ImageTexture.create_from_image(image)
	pins.clear()
	selected = -1
	_build_grid(density)
	if _rest_v.is_empty():
		return false

	if _mesh_node == null:
		_mesh_node = MeshInstance2D.new()
		_mesh_node.name = "WarpPreview"
		# The canvas keeps premultiplied pixels, and the preview is those
		# same pixels — so it has to blend the way every layer blends or the
		# drawing would darken the moment warping started.
		_mesh_node.material = PaintSurface.premultiplied_material()
		_mesh_node.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
		# Underneath this node's own drawing. A child paints after its
		# parent, so the artwork was going down on top of the grid and the
		# pins and hiding both — the grid was being drawn all along, just
		# never seen.
		_mesh_node.z_index = -1
		add_child(_mesh_node)
	_mesh_node.texture = _tex
	_mesh_node.visible = true
	solve()
	return true

## The mesh is laid over the ink and nowhere else.
##
## Cells are kept when the drawing puts something in them, plus one ring
## outwards so a stroke always has mesh on both sides of its edge. Empty
## cells are dropped: they cost the same to solve as drawn ones and move
## nothing, and — worse — they bridge gaps that the drawing does not, which
## is what let a pull cross from one arm of a U to the other.
func _build_grid(density: int) -> void:
	var want: int = clampi(density, MIN_CELLS, MAX_CELLS)
	cells = want
	var span: Vector2 = Vector2(float(rect.size.x), float(rect.size.y))
	var longest: float = maxf(span.x, span.y)
	_cols = clampi(int(round(want * span.x / longest)), 2, MAX_CELLS) + 1
	_rows = clampi(int(round(want * span.y / longest)), 2, MAX_CELLS) + 1
	_cell = Vector2(span.x / float(_cols - 1), span.y / float(_rows - 1))

	var cells_x: int = _cols - 1
	var cells_y: int = _rows - 1
	var inked: PackedByteArray = _ink_map(cells_x, cells_y)

	# --- vertices, for kept cells only ---
	_slot = PackedInt32Array()
	_slot.resize(_cols * _rows)
	_slot.fill(-1)
	_rest_v = PackedVector2Array()
	_uv = PackedVector2Array()
	_home = PackedInt32Array()

	var origin: Vector2 = Vector2(rect.position)
	var claim: Callable = func(x: int, y: int) -> int:
		var at: int = y * _cols + x
		if _slot[at] >= 0:
			return _slot[at]
		var fx: float = float(x) / float(_cols - 1)
		var fy: float = float(y) / float(_rows - 1)
		_rest_v.append(origin + Vector2(fx * span.x, fy * span.y))
		_uv.append(Vector2(fx, fy))
		_home.append(at)
		_slot[at] = _rest_v.size() - 1
		return _slot[at]

	_tris = PackedInt32Array()
	for cy in cells_y:
		for cx in cells_x:
			if inked[cy * cells_x + cx] == 0:
				continue
			var a: int = claim.call(cx, cy)
			var b: int = claim.call(cx + 1, cy)
			var c: int = claim.call(cx, cy + 1)
			var d: int = claim.call(cx + 1, cy + 1)
			# The diagonal alternates. A grid whose triangles all lean the
			# same way bends more easily along that diagonal than across it,
			# and a drawing pulled at forty-five degrees shows the bias as a
			# staircase. Alternating cancels it out.
			if (cx + cy) % 2 == 0:
				_tris.append_array([a, b, c])
				_tris.append_array([b, d, c])
			else:
				_tris.append_array([a, b, d])
				_tris.append_array([a, d, c])

	_now_v = _rest_v.duplicate()
	_link()
	_measure_rest()
	_order_dirty = true
	_reach_dirty = true

## Which cells the drawing actually reaches.
##
## The image is shrunk to one pixel per cell in one call rather than being
## read pixel by pixel from script — for a drawing of any size that is the
## difference between instant and a visible pause.
func _ink_map(cells_x: int, cells_y: int) -> PackedByteArray:
	var raw: PackedByteArray = PackedByteArray()
	if cells_x < 1 or cells_y < 1 or source == null:
		# Nothing to measure. An empty map means "mesh everywhere", which is
		# the safe answer — a warp over a blank patch does nothing, where a
		# resize to zero brings the whole app down.
		raw.resize(maxi(cells_x * cells_y, 1))
		raw.fill(1)
		return raw
	raw.resize(cells_x * cells_y)

	var probe: Image = source.duplicate()
	if probe.get_width() < 1 or probe.get_height() < 1:
		raw.fill(1)
		return raw
	probe.resize(cells_x, cells_y, Image.INTERPOLATE_BILINEAR)
	var any: bool = false
	for y in cells_y:
		for x in cells_x:
			var on: bool = probe.get_pixel(x, y).a > INK_FLOOR
			raw[y * cells_x + x] = 1 if on else 0
			any = any or on
	if not any:
		raw.fill(1)
		return raw

	# One ring outwards, so the mesh always extends a little past the ink and
	# an edge is never the very last row of vertices.
	var grown: PackedByteArray = raw.duplicate()
	for y in cells_y:
		for x in cells_x:
			if raw[y * cells_x + x] != 0:
				continue
			var touch: bool = false
			for dy in range(-1, 2):
				for dx in range(-1, 2):
					var nx: int = x + dx
					var ny: int = y + dy
					if nx < 0 or ny < 0 or nx >= cells_x or ny >= cells_y:
						continue
					if raw[ny * cells_x + nx] != 0:
						touch = true
						break
				if touch:
					break
			if touch:
				grown[y * cells_x + x] = 1
	return grown

## Who each vertex is joined to. This is the map every distance is walked
## along, and the reason a gap in the drawing is a gap in the measurement.
func _link() -> void:
	var count: int = _rest_v.size()
	_near = PackedInt32Array()
	_near.resize(count * 4)
	_near.fill(-1)
	_rim = PackedByteArray()
	_rim.resize(count)

	var steps: Array = [Vector2i(1, 0), Vector2i(-1, 0),
		Vector2i(0, 1), Vector2i(0, -1)]
	for i in count:
		var slot: int = _home[i]
		var gx: int = slot % _cols
		var gy: int = slot / _cols
		var found: int = 0
		for k in 4:
			var step: Vector2i = steps[k]
			var nx: int = gx + step.x
			var ny: int = gy + step.y
			if nx < 0 or ny < 0 or nx >= _cols or ny >= _rows:
				continue
			var other: int = _slot[ny * _cols + nx]
			if other < 0:
				continue
			_near[i * 4 + k] = other
			found += 1
		_rim[i] = 1 if found < 4 else 0

## The area of every triangle before anything was pulled.
func _measure_rest() -> void:
	var count: int = floori(float(_tris.size()) / 3.0)
	_rest_area = PackedFloat32Array()
	_rest_area.resize(count)
	for t in count:
		_rest_area[t] = _area(_rest_v[_tris[t * 3]], _rest_v[_tris[t * 3 + 1]],
			_rest_v[_tris[t * 3 + 2]])
	_fix = PackedVector2Array()
	_fix.resize(_rest_v.size())
	_hold = PackedFloat32Array()
	_hold.resize(_rest_v.size())

## Signed, so a triangle that has been turned inside out reports a negative
## area and the constraint pushes it back the right way instead of settling
## happily into a fold.
static func _area(a: Vector2, b: Vector2, c: Vector2) -> float:
	return 0.5 * ((b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y))

func set_density(density: int) -> void:
	if source == null:
		return
	var pose: Array = []
	for p in pins:
		pose.append([(p as Pin).rest, (p as Pin).now, (p as Pin).anchored,
			(p as Pin).depth])
	_build_grid(density)
	# The pins are put back on the new mesh rather than thrown away: changing
	# how finely something is measured should not undo the pose.
	pins.clear()
	for row in pose:
		var p: Pin = Pin.new()
		p.rest = row[0]
		p.now = row[1]
		p.anchored = row[2]
		p.depth = row[3]
		p.vertex = _vertex_near(p.rest)
		if p.vertex >= 0:
			pins.append(p)
	selected = mini(selected, pins.size() - 1)
	solve()
	changed.emit()

## Re-solving after a setting changes. The pose is untouched — only the way
## it is worked out.
func restyle() -> void:
	_order_dirty = true
	_reach_dirty = true
	solve()

# -------------------------------------------------------------------- pins

## The mesh vertex nearest a point, or -1 when the point is off the mesh.
func _vertex_near(at: Vector2) -> int:
	if _rest_v.is_empty():
		return -1
	var best: int = -1
	var best_d: float = INF
	for i in _rest_v.size():
		var d: float = _rest_v[i].distance_squared_to(at)
		if d < best_d:
			best_d = d
			best = i
	# Beyond a cell or so from any vertex there is no drawing here to pin.
	var span: float = _cell.length() * 1.25
	if best_d > span * span:
		return -1
	return best

## Whether a pin may be put down here at all.
func can_pin(at: Vector2) -> bool:
	return _vertex_near(at) >= 0

## Pins live on the mesh, and the mesh is the drawing.
##
## A pin dropped on blank paper used to be accepted and then quietly did
## nothing sensible: it had no ink to hold, and it dragged whatever happened
## to be nearest in a straight line. Now a tap off the drawing is refused,
## and a tap just outside its edge is taken as meaning the edge.
func add_pin(at: Vector2) -> int:
	var vertex: int = _vertex_near(at)
	if vertex < 0:
		return -1
	var p: Pin = Pin.new()
	p.rest = _rest_v[vertex]
	p.now = p.rest
	p.vertex = vertex
	pins.append(p)
	selected = pins.size() - 1
	_order_dirty = true
	_reach_dirty = true
	solve()
	changed.emit()
	return selected

## The pin under a finger, nearest first. `reach` is in page units so the
## target stays the same size on screen at any zoom.
func pin_at(at: Vector2, reach: float) -> int:
	var best: int = -1
	var best_d: float = reach * reach
	for i in pins.size():
		var d: float = at.distance_squared_to((pins[i] as Pin).now)
		if d <= best_d:
			best_d = d
			best = i
	return best

func move_pin(index: int, to: Vector2) -> void:
	if index < 0 or index >= pins.size():
		return
	var p: Pin = pins[index] as Pin
	if p.anchored:
		return
	if _last_pose.size() != pins.size():
		remember_pose()
	p.now = to
	solve()
	changed.emit()

func toggle_anchor(index: int) -> void:
	if index < 0 or index >= pins.size():
		return
	var p: Pin = pins[index] as Pin
	p.anchored = not p.anchored
	queue_redraw()
	changed.emit()

func is_anchored(index: int) -> bool:
	if index < 0 or index >= pins.size():
		return false
	return (pins[index] as Pin).anchored

## Moves a pin's part of the drawing in front of or behind the rest.
func set_depth(index: int, depth: int) -> void:
	if index < 0 or index >= pins.size():
		return
	(pins[index] as Pin).depth = clampi(depth, -9, 9)
	_order_dirty = true
	solve()
	changed.emit()

func depth_of(index: int) -> int:
	if index < 0 or index >= pins.size():
		return 0
	return (pins[index] as Pin).depth

func remove_pin(index: int) -> void:
	if index < 0 or index >= pins.size():
		return
	pins.remove_at(index)
	if selected >= pins.size():
		selected = pins.size() - 1
	_order_dirty = true
	_reach_dirty = true
	solve()
	changed.emit()

## Puts every pin back where it was placed. The pins stay — what goes is the
## pose, which is the thing a hand wants to take back.
## One step back, and only one — a pose is explored by pulling and pulling
## back, and a hand mid-pose wants the last pull undone far more often than it
## wants a list of every pull it has made.
var _last_pose: Array = []

func remember_pose() -> void:
	_last_pose = []
	for p in pins:
		_last_pose.append((p as Pin).now)

func has_step_back() -> bool:
	return _last_pose.size() == pins.size() and not _last_pose.is_empty()

func step_back() -> void:
	if not has_step_back():
		return
	var swap: Array = []
	for i in pins.size():
		swap.append((pins[i] as Pin).now)
		(pins[i] as Pin).now = _last_pose[i]
	_last_pose = swap
	solve()
	changed.emit()

func reset_pose() -> void:
	remember_pose()
	for p in pins:
		(p as Pin).now = (p as Pin).rest
	solve()
	changed.emit()

func clear_pins() -> void:
	pins.clear()
	selected = -1
	_order_dirty = true
	_reach_dirty = true
	solve()
	changed.emit()

# ------------------------------------------------------------ measuring out

## How far every part of the drawing is from every pin, walking the mesh.
##
## Straight-line distance is what made a pull arrive from the wrong place:
## across the mouth of a U it is a few pixels from one arm to the other, so
## each arm was weighted as though it were sitting on top of the other. Walked
## through the mesh the same two points are the whole length of the bend
## apart, and the drawing behaves as the shape it is.
##
## Worked out by repeated relaxation: every vertex offers each neighbour a
## route through itself, and the passes repeat until no route improves. Sweeps
## alternate direction so a distance travelling against the raster order does
## not need one pass per step. It costs a great deal more than subtracting two
## points — and it is done when the pins change, never while one is being
## dragged, because where a pin was *placed* is what it measures from.
func _rebuild_reach() -> void:
	_reach_dirty = false
	_reach = []
	var count: int = _rest_v.size()
	for p in pins:
		var pin: Pin = p as Pin
		if pin.vertex < 0 or pin.vertex >= count:
			pin.vertex = _vertex_near(pin.rest)
		var far: PackedFloat32Array = PackedFloat32Array()
		far.resize(count)
		far.fill(FAR)
		if pin.vertex >= 0:
			far[pin.vertex] = 0.0
		_spread(far)
		_reach.append(far)

func _spread(far: PackedFloat32Array) -> void:
	var count: int = far.size()
	for round_i in 64:
		var moved: bool = false
		var forward: bool = round_i % 2 == 0
		for step in count:
			var i: int = step if forward else count - 1 - step
			var here: float = far[i]
			if here >= FAR:
				continue
			for k in 4:
				var other: int = _near[i * 4 + k]
				if other < 0:
					continue
				var walk: float = here + _rest_v[i].distance_to(_rest_v[other])
				if walk < far[other] - 0.0001:
					far[other] = walk
					moved = true
		if not moved:
			return

## How much of each vertex belongs to a pin rather than to the mesh.
##
## The relaxation passes are the price of a smooth surface: they move vertices
## for reasons that have nothing to do with where the pins are. Near a pin
## that is exactly wrong — a pin has to mean the place it sits on — so near a
## pin they are turned off, and they fade back in with distance.
func _measure_hold() -> void:
	var span: float = maxf(_cell.length() * 1.6, softness)
	var span2: float = span * span
	for i in _hold.size():
		var near: float = 0.0
		for r in _reach:
			var d: float = (r as PackedFloat32Array)[i]
			if d >= FAR:
				continue
			near = maxf(near, exp(-(d * d) / span2))
		_hold[i] = clampf(near, 0.0, 1.0)

# --------------------------------------------------------------- the solve

func solve() -> void:
	if _rest_v.is_empty():
		return
	var count: int = pins.size()

	if count == 0:
		_now_v = _rest_v.duplicate()
	else:
		if _reach_dirty:
			_rebuild_reach()
			_measure_hold()
		if count < RIGID_FROM:
			# One pin cannot describe a rotation, so it carries the drawing —
			# but only as far as the mesh reaches from it, so a separate piece
			# with no pin of its own stays where it is.
			var only: Pin = pins[0] as Pin
			var shift: Vector2 = only.now - only.rest
			var far: PackedFloat32Array = _reach[0]
			for i in _rest_v.size():
				_now_v[i] = _rest_v[i] + (shift if far[i] < FAR else Vector2.ZERO)
		else:
			if _weights.size() != count:
				_weights.resize(count)
			for i in _rest_v.size():
				_now_v[i] = _warp(i)
			# Smoothing first, because relaxing a surface always loses a
			# little of it; restoring the area afterwards puts back what the
			# smoothing took as well as what the pull took.
			for pass_i in 2:
				_relax_smooth()
				_relax_area()

	if _order_dirty:
		_order_triangles()
	_push_mesh()
	queue_redraw()

## Where one vertex of the rest drawing ends up.
##
## Weigh every pin by how far it is through the mesh; find the weighted centre
## of the pins as they were and as they are now; then find the single rotation
## that best carries the first arrangement onto the second, as weighted from
## this vertex. Turn the vertex by that rotation about the rest centre and put
## it down at the new centre. Because only a rotation is fitted — never a
## stretch — the drawing keeps its proportions.
func _warp(at: int) -> Vector2:
	var v: Vector2 = _rest_v[at]
	var count: int = pins.size()
	var total: float = 0.0
	var p_star: Vector2 = Vector2.ZERO
	var q_star: Vector2 = Vector2.ZERO
	var soft2: float = softness * softness
	var plain: bool = absf(stiffness - 1.0) < 0.0001

	for i in count:
		var pin: Pin = pins[i] as Pin
		var d: float = (_reach[i] as PackedFloat32Array)[at]
		if d >= FAR:
			# No path from this pin to here. Nothing this pin does should
			# reach a piece of drawing it is not joined to.
			_weights[i] = 0.0
			continue
		var d2: float = d * d
		if d2 < 0.000001:
			return pin.now
		# `pow` is called once per vertex per pin — tens of thousands of times
		# for every frame of a drag — so the default exponent skips it.
		var den: float = d2 + soft2
		var w: float = 1.0 / den if plain else 1.0 / pow(den, stiffness)
		_weights[i] = w
		total += w
		p_star += pin.rest * w
		q_star += pin.now * w

	if total <= 0.0:
		return v
	p_star /= total
	q_star /= total

	var u: Vector2 = v - p_star
	var fr: Vector2 = Vector2.ZERO
	for i in count:
		if _weights[i] <= 0.0:
			continue
		var other: Pin = pins[i] as Pin
		var ph: Vector2 = other.rest - p_star
		var qh: Vector2 = other.now - q_star
		# The two halves of a rotation, read off the rest offset against this
		# vertex: how much it lies along it, and how much across it.
		var along: float = ph.dot(u)
		var across: float = ph.x * u.y - ph.y * u.x
		fr += _weights[i] * Vector2(
			qh.x * along - qh.y * across,
			qh.x * across + qh.y * along)

	var span: float = fr.length()
	if span < 0.000000001:
		return q_star
	# Only the direction of the fit is kept; the distance from the centre is
	# the one the vertex already had. That is the whole of "rigid": the fit
	# may turn the drawing, never stretch it.
	return q_star + fr * (u.length() / span)

## Pulls every vertex a little towards the middle of its neighbours.
##
## This is what turns the corner where two triangles meet at an angle into a
## curve running through both. Outline vertices are averaged only against
## other outline vertices, never inward — a silhouette relaxed towards the
## middle of the drawing would slowly eat itself.
func _relax_smooth() -> void:
	if smoothing <= 0.001:
		return
	for i in _now_v.size():
		_fix[i] = Vector2.ZERO
	for i in _now_v.size():
		var sum: Vector2 = Vector2.ZERO
		var n: int = 0
		for k in 4:
			var other: int = _near[i * 4 + k]
			if other < 0:
				continue
			if _rim[i] == 1 and _rim[other] == 0:
				continue
			sum += _now_v[other]
			n += 1
		if n == 0:
			continue
		_fix[i] = (sum / float(n) - _now_v[i]) \
			* smoothing * 0.5 * (1.0 - _hold[i])
	for i in _now_v.size():
		_now_v[i] += _fix[i]

## Gives every triangle back the area it started with.
##
## Rigid MLS never stretches a triangle on its own — it fits a rotation and
## nothing else. What squashes the drawing is the blend *between* two pins
## pulling different ways: each region is rigid, and the ground between them
## takes up the difference by collapsing. Pull two pins together and the
## drawing between them thins out.
##
## For each triangle, take how much area it has lost, work out which direction
## each corner would have to move to give that area back fastest, and move
## them that way by the smallest amount that does it. Because area is width
## times height, a triangle squeezed one way is handed its area back as width
## in the other — the behaviour wanted, arrived at by arithmetic rather than
## bolted on as a rule.
func _relax_area() -> void:
	if area_keep <= 0.001 or _rest_area.is_empty():
		return
	for i in _now_v.size():
		_fix[i] = Vector2.ZERO
	var count: int = floori(float(_tris.size()) / 3.0)
	for t in count:
		var ia: int = _tris[t * 3]
		var ib: int = _tris[t * 3 + 1]
		var ic: int = _tris[t * 3 + 2]
		var a: Vector2 = _now_v[ia]
		var b: Vector2 = _now_v[ib]
		var c: Vector2 = _now_v[ic]
		var err: float = _area(a, b, c) - _rest_area[t]
		if absf(err) < 0.0001:
			continue
		# Which way each corner moves to change the area quickest.
		var ga: Vector2 = Vector2(b.y - c.y, c.x - b.x) * 0.5
		var gb: Vector2 = Vector2(c.y - a.y, a.x - c.x) * 0.5
		var gc: Vector2 = Vector2(a.y - b.y, b.x - a.x) * 0.5
		var denom: float = ga.length_squared() + gb.length_squared() \
			+ gc.length_squared()
		if denom < 0.000001:
			continue
		# `push` rather than `scale`: this class is a Node2D and `scale` is
		# one of its own properties, so a local of that name hides it.
		var push: float = -err / denom * area_keep * 0.5
		_fix[ia] += ga * push * (1.0 - _hold[ia])
		_fix[ib] += gb * push * (1.0 - _hold[ib])
		_fix[ic] += gc * push * (1.0 - _hold[ic])
	for i in _now_v.size():
		_now_v[i] += _fix[i]

## Puts the triangles in the order they should be painted.
##
## A flat mesh has no depth buffer — later simply covers earlier. So when a
## limb is folded across a body, which one is on top is decided by nothing at
## all, and the two sets of triangles interleave. Each triangle takes the
## depth of the pins nearest it, weighted the way the warp weights them, and
## the list is sorted lowest first. Sorting happens when the depths change,
## not while a pin is dragged: a triangle's depth is read from where it
## started, so a drag cannot alter it.
func _order_triangles() -> void:
	_order_dirty = false
	var count: int = floori(float(_tris.size()) / 3.0)
	if count == 0:
		return

	var mixed: bool = false
	for p in pins:
		if (p as Pin).depth != 0:
			mixed = true
			break
	if not mixed or pins.is_empty() or _reach.size() != pins.size():
		# Everything on one plane: the grid's own order is correct and costs
		# nothing.
		_index = _tris.duplicate()
		return

	var soft2: float = softness * softness
	var ranked: Array = []
	ranked.resize(count)
	for t in count:
		var total: float = 0.0
		var deep: float = 0.0
		for i in pins.size():
			var d: float = 0.0
			for k in 3:
				d += (_reach[i] as PackedFloat32Array)[_tris[t * 3 + k]]
			d /= 3.0
			if d >= FAR:
				continue
			var w: float = 1.0 / (d * d + soft2)
			total += w
			deep += w * float((pins[i] as Pin).depth)
		ranked[t] = [deep / maxf(total, 0.000001), t]
	ranked.sort_custom(func(x: Array, y: Array) -> bool:
		return float(x[0]) < float(y[0]))

	var out: PackedInt32Array = PackedInt32Array()
	out.resize(_tris.size())
	for k in count:
		var t: int = int((ranked[k] as Array)[1])
		out[k * 3] = _tris[t * 3]
		out[k * 3 + 1] = _tris[t * 3 + 1]
		out[k * 3 + 2] = _tris[t * 3 + 2]
	_index = out

# ------------------------------------------------------------------ drawing

func _push_mesh() -> void:
	if _mesh_node == null or _now_v.is_empty():
		return
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = _now_v
	arrays[Mesh.ARRAY_TEX_UV] = _uv
	arrays[Mesh.ARRAY_INDEX] = _index
	var mesh: ArrayMesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_mesh_node.mesh = mesh

## The mesh and the pins, drawn at a constant size on screen: a hairline stays
## a hairline and a pin stays thumb-sized whether the page is at 20% or 600%.
func _draw() -> void:
	if _now_v.is_empty():
		return
	var thin: float = 1.0 / maxf(zoom, 0.0001)

	if show_mesh:
		# Twice: a dark pass first so the mesh is legible over pale artwork,
		# then a bright one over it. One colour cannot be seen against both
		# white paper and black ink, and this mesh has to sit on top of both.
		_draw_wire(Color(0.05, 0.04, 0.03, 0.35), 2.6 * thin)
		_draw_wire(Color(0.99, 0.96, 0.88, 0.50), 1.1 * thin)
		# The outline of the mesh, which is the edge of what can be pinned.
		for i in _rim.size():
			if _rim[i] == 0:
				continue
			for k in 4:
				var other: int = _near[i * 4 + k]
				if other > i and _rim[other] == 1:
					draw_line(_now_v[i], _now_v[other],
						Color("#E8D5A3"), 2.0 * thin)

	# Deepest last, so where two pins overlap a finger lands on the one in
	# front.
	var order: Array = []
	for i in pins.size():
		order.append(i)
	order.sort_custom(func(x: int, y: int) -> bool:
		return (pins[x] as Pin).depth < (pins[y] as Pin).depth)
	for i in order:
		_draw_pin(pins[i] as Pin, thin, i == selected)

func _draw_wire(col: Color, width: float) -> void:
	for i in _now_v.size():
		for k in 4:
			var other: int = _near[i * 4 + k]
			# Once per edge, not twice: every join is listed from both ends.
			if other > i:
				draw_line(_now_v[i], _now_v[other], col, width)

func _draw_pin(p: Pin, thin: float, chosen: bool = false) -> void:
	var r: float = 13.0 * thin
	# Where it was placed, and the line back to it: the pin's own history is
	# the clearest way to see how far the drawing has been pulled.
	if p.now.distance_squared_to(p.rest) > 1.0:
		draw_circle(p.rest, 4.0 * thin, Color(0.95, 0.93, 0.88, 0.30))
		draw_line(p.rest, p.now, Color(0.95, 0.93, 0.88, 0.34), thin)

	draw_circle(p.now + Vector2(1.0, 2.0) * thin, r + 2.0 * thin,
		Color(0.0, 0.0, 0.0, 0.30))
	if p.anchored:
		# An anchor is a different shape, not a different shade: shape reads
		# at a glance over any drawing, a shade does not.
		var side: float = r * 0.92
		draw_rect(Rect2(p.now - Vector2(side, side), Vector2(side, side) * 2.0),
			Color("#FFF8E7"), true)
		draw_rect(Rect2(p.now - Vector2(side, side), Vector2(side, side) * 2.0),
			Color("#8A7C58"), false, 2.5 * thin)
	else:
		draw_circle(p.now, r, Color("#FFF8E7"))
		draw_arc(p.now, r, 0.0, TAU, 24, Color("#E8D5A3"), 2.5 * thin)
	draw_circle(p.now, r * 0.34, Color("#8A7C58"))
	if chosen:
		draw_arc(p.now, r * 1.55, 0.0, TAU, 28, Color("#FFF8E7"), 2.0 * thin)
	if p.depth != 0:
		# A pin that has been lifted or pushed says so with rungs: up for in
		# front, down for behind. Countable at a glance, and unlike a colour
		# it survives being drawn over any artwork.
		var step: float = 3.6 * thin
		var dir: float = -1.0 if p.depth > 0 else 1.0
		for k in absi(p.depth):
			var oy: float = dir * (r + step * float(k + 1) + 2.0 * thin)
			draw_line(p.now + Vector2(-r * 0.5, oy),
				p.now + Vector2(r * 0.5, oy), Color("#FFF8E7"), 2.0 * thin)

# ------------------------------------------------------------------ baking

## The box the bent drawing now needs, which is rarely the box it started in —
## pulling a limb out puts ink where there was none.
func deformed_bounds() -> Rect2i:
	if _now_v.is_empty():
		return rect
	var lo: Vector2 = _now_v[0]
	var hi: Vector2 = _now_v[0]
	for v in _now_v:
		lo.x = minf(lo.x, v.x)
		lo.y = minf(lo.y, v.y)
		hi.x = maxf(hi.x, v.x)
		hi.y = maxf(hi.y, v.y)
	# A pixel of air on each side, so a linear sample at the very edge has
	# something to read and the outline does not come back clipped.
	var pad: Vector2 = Vector2(2.0, 2.0)
	var box: Rect2i = Rect2i(Vector2i((lo - pad).floor()),
		Vector2i((hi - lo + pad * 2.0).ceil()))
	box.size.x = clampi(box.size.x, 1, MAX_BAKE)
	box.size.y = clampi(box.size.y, 1, MAX_BAKE)
	return box

## Renders the bent drawing once and hands back the pixels.
##
## The graphics card does the rasterising. Walking a few thousand triangles by
## hand in script would take long enough to be felt, and it would have to
## reinvent the sampling the card already does properly.
func bake() -> Dictionary:
	if _now_v.is_empty() or _tex == null:
		return {}
	var box: Rect2i = deformed_bounds()

	var shifted: PackedVector2Array = PackedVector2Array()
	shifted.resize(_now_v.size())
	var origin: Vector2 = Vector2(box.position)
	for i in _now_v.size():
		shifted[i] = _now_v[i] - origin

	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = shifted
	arrays[Mesh.ARRAY_TEX_UV] = _uv
	arrays[Mesh.ARRAY_INDEX] = _index
	var mesh: ArrayMesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)

	var port: SubViewport = SubViewport.new()
	port.size = box.size
	port.transparent_bg = true
	port.disable_3d = true
	port.render_target_update_mode = SubViewport.UPDATE_ONCE
	port.render_target_clear_mode = SubViewport.CLEAR_MODE_ONCE
	# The bake is the pixels the drawing keeps, so it is sampled as well as
	# the card can rather than as fast as it can.
	port.msaa_2d = Viewport.MSAA_4X

	var flat: MeshInstance2D = MeshInstance2D.new()
	flat.mesh = mesh
	flat.texture = _tex
	flat.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	flat.material = PaintSurface.premultiplied_material()
	port.add_child(flat)
	add_child(port)

	# Two frames: one for the viewport to be told to draw, one for the draw to
	# have happened. Reading after a single frame returns the frame before
	# this one, which on the first bake is nothing at all.
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var out: Image = port.get_texture().get_image()
	port.queue_free()
	if out == null:
		return {}
	if out.get_format() != Image.FORMAT_RGBA8:
		out.convert(Image.FORMAT_RGBA8)
	return {"image": out, "at": box.position, "rect": box}

func finish() -> void:
	if _mesh_node != null:
		_mesh_node.visible = false
		_mesh_node.mesh = null
	source = null
	_tex = null
	pins.clear()
	selected = -1
	_rest_v = PackedVector2Array()
	_now_v = PackedVector2Array()
	_reach = []
	queue_redraw()
