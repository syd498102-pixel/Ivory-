extends Control
## IVORY — main room.
##
## The canvas gets the whole screen. Everything else is a small floating
## cluster that stays out of the drawing hand's way: tools on the left,
## selection and clipboard top-left, layers top-right, and readouts that
## appear only when they have something to say.

const ICON: String = "res://assets/icons/%s.png"
const ZOOM_HOLD: float = 0.9      # seconds the zoom badge lingers
const THUMB_EVERY: float = 1.2    # seconds between layer thumbnail refreshes

var view: CanvasView = null
var rail: PanelContainer = null
var edit_bar: PanelContainer = null
var layer_btn_bar: PanelContainer = null
var panel_host: PanelContainer = null
var layers_panel: LayersPanel = null
var coord_bar: PanelContainer = null
var zoom_badge: PanelContainer = null
var note_badge: PanelContainer = null
var page_bar: PanelContainer = null
var layout_bar: PanelContainer = null
var _layout_btn: Button = null
var timeline: TimelinePanel = null
var timeline_btn: PanelContainer = null
var _page_label: Label = null
var action_bar: PanelContainer = null
var solo_bar: PanelContainer = null
var puppet_bar: PanelContainer = null
var bspline_room: BSplineRoom = null
var room_360: Room360 = null

var open_panel: String = ""
var _shade_from: Vector2 = Vector2.ZERO
var _shade_armed: bool = false
var coord_label: Label = null
var zoom_label: Label = null
var note_label: Label = null
var solo_index: int = -1

var _tool_buttons: Dictionary = {}
var _last_world: Vector2 = Vector2.ZERO
var _settings_page: String = "menu"
var _save_timer: float = Vault.INTERVAL
var _comic_page: int = 0
var _ui: CanvasLayer = null
var _shade: Control = null
var _options_for: ProjectManager.Project = null
var _zoom_timer: float = 0.0
var _note_timer: float = 0.0
var _last_zoom: float = 1.0
var _thumb_timer: float = 0.0
var _btn_close_shape: Button = null
var _btn_place: Button = null
var _btn_cancel: Button = null
var _btn_symmetry_cancel: Button = null

func _ready() -> void:
	App.ui_scale = clampf(float(DisplayServer.screen_get_dpi()) / 160.0, 1.0, 3.0)
	UiKit.scale = App.ui_scale
	UiKit.load_font()

	view = CanvasView.new()
	view.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(view)
	view.view_changed.connect(_on_zoom)
	view.pointer_moved.connect(_on_pointer)
	view.selection_changed.connect(_refresh_action_bar)
	view.action_taken.connect(_on_action)
	view.notice.connect(_flash)
	view.text_restyle_needed.connect(_redraw_text_layer)
	view.project_menu_requested.connect(_show_project_options)
	view.frame_colour_requested.connect(_show_frame_colour)
	view.project_focused.connect(func(p: ProjectManager.Project) -> void:
		_comic_page = p.active_page
		_sync_shell()
		_refresh_timeline_button()
		_refresh_focus_bar()
		_flash(p.title))
	view.project_changed.connect(_sync_rail)
	view.project_changed.connect(_refresh_timeline_button)
	view.symmetry_mode_changed.connect(_on_symmetry_mode_changed)

	# The interface sits in its own layer. Project frames, titles and the
	# drawing itself all live in the canvas below it, so nothing can ever
	# be drawn over a button again — no matter what z-index it asks for.
	_ui = CanvasLayer.new()
	_ui.layer = 1
	add_child(_ui)

	# A sheet of nothing behind every floating panel. Reaching back to the
	# button that opened a panel in order to close it is the kind of small
	# tax a user pays a hundred times a session, and there is no reason for
	# it: a tap anywhere else already means "not this".
	_shade = Control.new()
	_shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_shade.mouse_filter = Control.MOUSE_FILTER_STOP
	_shade.visible = false
	_shade.gui_input.connect(_shade_touched)
	_ui.add_child(_shade)

	_build_rail()
	_build_edit_bar()
	_build_layer_button()
	_build_coord_bar()
	_build_zoom_badge()
	_build_note_badge()
	_build_page_bar()
	_build_layout_bar()
	_build_timeline_button()
	_build_action_bar()
	_build_solo_bar()
	_build_puppet_bar()
	_build_symmetry_cancel()

	resized.connect(_layout)
	App.tool_changed.connect(_on_tool_changed)
	App.open_fill_colour.connect(func() -> void:
		_close_panel()
		_mount(ToolPanels.color(view, true), "fill"))

	get_tree().auto_accept_quit = false
	# Without this the export folder is invisible to the gallery and to
	# every other app on the phone, which defeats the point of exporting.
	if OS.get_name() == "Android":
		OS.request_permissions()
	# A drawing program is idle most of the time it is open. Sleeping
	# between frames rather than spinning is the single cheapest thing a
	# tablet app can do for its battery.
	OS.low_processor_usage_mode = true
	OS.low_processor_usage_mode_sleep_usec = 6000

	await get_tree().process_frame
	view.reset_view()
	# Anything left from last time comes back closed and compressed, so a
	# full workspace costs nothing until a project is opened.
	Vault.load_all(view.projects)
	# Anything on disk that no project answers for is swept up at startup,
	# so old copies cannot pile up unseen.
	Vault.purge_orphans(view.projects)
	_sync_shell()
	_last_zoom = view.view_zoom
	_layout()
	_sync_rail()
	_update_coords()

## The one moment where saving cannot be put off.
func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_park()
		get_tree().quit()
	elif what == NOTIFICATION_APPLICATION_PAUSED:
		_park()

## A sheet the user opened the dialog for and never put down is thrown away
## rather than written to disk, so it cannot return uninvited.
func _park() -> void:
	if view == null:
		return
	var loose: ProjectManager.Project = view.projects.placing
	if loose != null:
		view.projects.remove(loose)
	Vault.save_all(view.projects)

func _input(event: InputEvent) -> void:
	# Panels and bars live outside the canvas, so the canvas never sees the
	# touches that drive them — without this they would animate at the idle
	# pace and feel broken.
	if event is InputEventScreenTouch or event is InputEventScreenDrag \
			or event is InputEventMouseButton or event is InputEventKey:
		view.mark_busy()

func _process(delta: float) -> void:
	_save_timer -= delta
	if _save_timer <= 0.0:
		_save_timer = Vault.INTERVAL
		for p in view.projects.take_dirty():
			if Vault.save(p):
				view.projects.mark_saved(p)
	if _zoom_timer > 0.0:
		_zoom_timer -= delta
		if _zoom_timer <= 0.0:
			zoom_badge.visible = false
	if _note_timer > 0.0:
		_note_timer -= delta
		if _note_timer <= 0.0:
			note_badge.visible = false
	if layers_panel != null and layers_panel.visible:
		_thumb_timer -= delta
		if _thumb_timer <= 0.0:
			_thumb_timer = THUMB_EVERY
			layers_panel.refresh_thumbs()

# ------------------------------------------------------------------ layout

func _layout() -> void:
	var pad: float = UiKit.s(14.0)
	if rail != null:
		rail.position = Vector2(pad, (size.y - rail.size.y) * 0.5)
	if edit_bar != null:
		edit_bar.position = Vector2(pad, pad)
	if layer_btn_bar != null:
		layer_btn_bar.position = Vector2(size.x - layer_btn_bar.size.x - pad, pad)
	if zoom_badge != null:
		zoom_badge.position = Vector2((size.x - zoom_badge.size.x) * 0.5, pad)
	if note_badge != null:
		note_badge.position = Vector2((size.x - note_badge.size.x) * 0.5,
			pad + UiKit.s(48.0))
	if solo_bar != null:
		solo_bar.position = Vector2((size.x - solo_bar.size.x) * 0.5, pad)
	if puppet_bar != null and puppet_bar.visible:
		puppet_bar.position = Vector2((size.x - puppet_bar.size.x) * 0.5,
			size.y - puppet_bar.size.y - pad)
	if _btn_symmetry_cancel != null and _btn_symmetry_cancel.visible:
		_btn_symmetry_cancel.position = Vector2((size.x - _btn_symmetry_cancel.size.x) * 0.5,
			pad + UiKit.s(54.0))
	if coord_bar != null:
		coord_bar.position = Vector2(size.x - coord_bar.size.x - pad,
			size.y - coord_bar.size.y - pad)
	if action_bar != null:
		action_bar.position = Vector2((size.x - action_bar.size.x) * 0.5,
			size.y - action_bar.size.y - pad)
	if layout_bar != null and layout_bar.visible:
		layout_bar.position = Vector2(pad, size.y - layout_bar.size.y - pad)
	if timeline_btn != null and timeline_btn.visible:
		# Lifted clear of the very corner, where a thumb resting on the
		# bezel would find it by accident.
		var lift: float = pad + UiKit.s(26.0)
		if timeline != null and timeline.visible:
			lift += timeline.size.y + UiKit.s(8.0)
		timeline_btn.position = Vector2(size.x - timeline_btn.size.x - pad,
			size.y - timeline_btn.size.y - lift)
	if timeline != null:
		var band: float = clampf(size.y * 0.34, UiKit.s(180.0), UiKit.s(360.0))
		timeline.size = Vector2(size.x, band)
		timeline.position = Vector2(0.0, size.y - band)
	if page_bar != null and page_bar.visible:
		var page_lift: float = pad
		if action_bar != null and action_bar.visible:
			page_lift += action_bar.size.y + UiKit.s(8.0)
		page_bar.position = Vector2((size.x - page_bar.size.x) * 0.5,
			size.y - page_bar.size.y - page_lift)
	if panel_host != null:
		# A panel is capped at the screen and then clamped inside it, so a
		# tall one can never grow off an edge and take its own buttons with
		# it. The cap comes first: clamping alone cannot rescue a panel
		# already taller than the screen.
		var room: Vector2 = size - Vector2(pad * 2.0, pad * 2.0)
		if panel_host.size.y > room.y:
			panel_host.size = Vector2(panel_host.size.x, room.y)
		var x: float = pad + (rail.size.x if rail != null else 0.0) + UiKit.s(12.0)
		if open_panel == "layers":
			x = size.x - panel_host.size.x - pad
		var x_max: float = maxf(size.x - panel_host.size.x - pad, pad)
		var y: float = (size.y - panel_host.size.y) * 0.5
		var y_max: float = maxf(size.y - panel_host.size.y - pad, pad)
		panel_host.position = Vector2(clampf(x, pad, x_max), clampf(y, pad, y_max))

# -------------------------------------------------------------------- rail

func _build_rail() -> void:
	rail = PanelContainer.new()
	rail.add_theme_stylebox_override("panel", UiKit.rail_style())
	rail.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	_ui.add_child(rail)
	rail.resized.connect(_layout)

	var col: VBoxContainer = VBoxContainer.new()
	col.add_theme_constant_override("separation", int(UiKit.s(4.0)))
	rail.add_child(col)

	col.add_child(_tool_btn("brush", "brush", UiKit.label_for("Brush", "الفرشاة")))
	col.add_child(_tool_btn("fill", "fill", UiKit.label_for("Fill", "الملء")))
	col.add_child(_tool_btn("shapes", "shapes", UiKit.label_for("Shapes", "الأشكال")))
	col.add_child(_tool_btn("color", "color_wheel", UiKit.label_for("Color", "الألوان")))
	col.add_child(_tool_btn("eraser", "eraser", UiKit.label_for("Eraser", "الممحاة")))

func _tool_btn(id: String, icon_name: String, tip: String) -> Button:
	var b: Button = UiKit.make_tool_button(ICON % icon_name, tip)
	b.pressed.connect(func() -> void: _on_rail_pressed(id))
	_tool_buttons[id] = b
	return b

func _on_rail_pressed(id: String) -> void:
	if id == "brush":
		App.set_tool(App.Tool.BRUSH)
	elif id == "fill":
		App.set_tool(App.Tool.FILL)
	elif id == "shapes":
		App.set_tool(App.Tool.SHAPE)
	elif id == "eraser":
		App.set_tool(App.Tool.ERASER)
	elif id == "select":
		App.set_tool(App.Tool.SELECT)
	_toggle_panel(id)
	_sync_rail()

func _on_tool_changed(t: int) -> void:
	if t == App.Tool.PICK:
		_close_panel()
	_sync_rail()

## On the workspace there is one thing to do — make something — so there is
## one button. A rail of brushes over a grid with no paper on it is five
## controls that cannot do anything, and they were the first thing anyone
## saw. They come back the moment a project is focused.
func _sync_shell() -> void:
	var inside: bool = view.projects.focus_on != null
	if rail != null:
		rail.visible = inside
	if edit_bar != null:
		edit_bar.visible = inside
	if layer_btn_bar != null:
		# The settings button lives in this bar, and settings is the one
		# thing the workspace needs — so the bar stays and its layers button
		# is the part that steps aside.
		layer_btn_bar.visible = true
		if _tool_buttons.has("layers"):
			(_tool_buttons["layers"] as Button).visible = inside
		if _tool_buttons.has("compass"):
			(_tool_buttons["compass"] as Button).visible = inside
		if _tool_buttons.has("timeline"):
			(_tool_buttons["timeline"] as Button).visible = inside
	if coord_bar != null:
		coord_bar.visible = inside
	if inside and open_panel != "" and open_panel != "settings":
		pass
	elif not inside and open_panel != "" and open_panel != "settings":
		_close_panel()
	_layout()

func _sync_rail(_ignored: int = 0) -> void:
	var active: String = ""
	if App.current_tool == App.Tool.BRUSH:
		active = "brush"
	elif App.current_tool == App.Tool.FILL:
		active = "fill"
	elif App.current_tool == App.Tool.SHAPE:
		active = "shapes"
	elif App.current_tool == App.Tool.ERASER:
		active = "eraser"
	elif App.current_tool == App.Tool.SELECT:
		active = "select"
	for id in _tool_buttons.keys():
		var b: Button = _tool_buttons[id]
		var on: bool = (id == active) or (id == open_panel and id == "color") \
			or (id == "layers" and open_panel == "layers") \
			or (id == "compass" and open_panel == "compass") \
			or (id == "settings" and open_panel == "settings")
		b.set_pressed_no_signal(on)

# ------------------------------------------------- selection and clipboard

func _build_edit_bar() -> void:
	edit_bar = PanelContainer.new()
	edit_bar.add_theme_stylebox_override("panel", UiKit.rail_style())
	edit_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	_ui.add_child(edit_bar)
	edit_bar.resized.connect(_layout)

	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", int(UiKit.s(4.0)))
	edit_bar.add_child(row)

	var input_b: Button = UiKit.make_tool_button(ICON % "input_event",
		UiKit.label_for("Input event", "حدث الإدخال"))
	input_b.pressed.connect(_open_input_event)
	row.add_child(input_b)

	var copy_b: Button = UiKit.make_tool_button(ICON % "copy",
		UiKit.label_for("Copy", "نسخ"))
	copy_b.toggle_mode = false
	copy_b.pressed.connect(func() -> void: view.copy_selection())
	row.add_child(copy_b)

	var paste_b: Button = UiKit.make_tool_button(ICON % "paste",
		UiKit.label_for("Paste", "لصق"))
	paste_b.toggle_mode = false
	paste_b.pressed.connect(func() -> void: view.paste_clipboard())
	row.add_child(paste_b)

func _build_layer_button() -> void:
	layer_btn_bar = PanelContainer.new()
	layer_btn_bar.add_theme_stylebox_override("panel", UiKit.rail_style())
	layer_btn_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	_ui.add_child(layer_btn_bar)
	layer_btn_bar.resized.connect(_layout)

	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", int(UiKit.s(4.0)))
	layer_btn_bar.add_child(row)
	row.add_child(_tool_btn("layers", "layers", UiKit.label_for("Layers", "الطبقات")))
	# The compass sits beside the layers button and in the same style, because
	# what it holds is the same kind of thing: not a brush, but a place to go.
	row.add_child(_tool_btn("compass", "compass",
		UiKit.label_for("Compass", "البوصلة")))
	row.add_child(_tool_btn("settings", "settings_gear",
		UiKit.label_for("Settings", "الإعدادات")))


# ---------------------------------------------------------------- compass

## What the compass holds: places, not tools.
##
## The rail chooses what the hand is doing to the drawing. These three change
## what is being worked on, or where the work is happening — which is why they
## are gathered under their own mark rather than added to a row of brushes.
func _compass_panel() -> PanelContainer:
	# Character 360 is offered only where there is time to turn a figure
	# through. See the note on ToolPanels.compass.
	var p: ProjectManager.Project = current_project()
	var animated: bool = p != null and p.kind == ProjectManager.Kind.ANIMATION
	return ToolPanels.compass(animated,
		func() -> void: enter_bspline_room(),
		func() -> void: add_text_layer(),
		func() -> void: enter_360_room(),
		func() -> void: begin_tangled_lines())

## Straight lines that arrive already joined.
##
## Reached from the compass rather than from the shapes panel because it is a
## way of building rather than one more outline — you keep drawing until the
## thing is built, and every line lands joined to the last. It still *is* the
## shape tool underneath, which is why it inherits the brush, the colour and
## the undo you already have.
func begin_tangled_lines() -> void:
	_close_panel()
	if not view.has_project():
		_flash(UiKit.label_for("Open a project first", "افتح مشروعاً أولاً"))
		return
	view.break_chain()
	App.shape_mode = App.Shape.CHAIN
	App.set_tool(App.Tool.SHAPE)
	App.settings_changed.emit()
	_flash(UiKit.label_for(
		"Draw the first line. Every line after it starts where the last one ended.",
		"ارسم الخط الأول. وكل خط بعده يبدأ حيث انتهى سابقه."))

# ------------------------------------------------------------------- text

var _text_state: Dictionary = {}

## Writing goes on a layer of its own, always.
##
## Text on a drawing layer is ink the moment it lands — to change a word you
## would have to erase it and hope you erased only that. On its own layer it
## can be moved, restyled, or thrown away without touching a single stroke
## underneath, which is what makes it text rather than a picture of text.
func add_text_layer() -> void:
	_close_panel()
	if not view.has_project():
		_flash(UiKit.label_for("Open a project first", "افتح مشروعاً أولاً"))
		return
	if _text_state.is_empty():
		_text_state = {
			"text": "", "size": 64.0, "leading": 1.15,
			"colour": Color("#1A1712"), "halo": 0.0,
			"halo_colour": Color("#FFF8E7"),
			"align": HORIZONTAL_ALIGNMENT_LEFT,
		}
	_mount(ToolPanels.text_maker(_text_state,
		func() -> void: pass,
		func() -> void: _place_text()), "text")

func _place_text() -> void:
	var words: String = String(_text_state.get("text", "")).strip_edges()
	if words == "":
		_flash(UiKit.label_for("Write something first", "اكتب شيئاً أولاً"))
		return
	var made: Image = await TextRender.render(_text_state)
	if made == null:
		_flash(UiKit.label_for("Could not draw that", "تعذّر رسم ذلك"))
		return
	var stack: LayerStack = view.layers
	var layer: LayerStack.Layer = stack.add_layer_here()
	if layer == null:
		_flash(UiKit.label_for("No room for another layer", "لا مكان لطبقة أخرى"))
		return
	layer.title = "%s — %s" % [UiKit.label_for("Text layer", "طبقة نص"),
		words.substr(0, 18)]
	layer.is_text = true
	layer.text_state = _text_state.duplicate(true)
	layer.text_turn = 0.0

	# Centred on the page, because that is where a first look wants it and
	# moving it afterwards is one drag.
	var page: Vector2 = view.projects.active.page
	var at: Vector2 = (page - Vector2(made.get_width(), made.get_height())) * 0.5
	layer.text_at = at.round()
	layer.surface.blit_image(made, layer.text_at, true)
	view.begin_text_box(layer.id)
	stack.changed.emit()
	view.projects.mark_dirty(view.projects.active)
	_close_panel()
	_flash(UiKit.label_for("Text layer added", "أُضيفت طبقة النص"))

## Writing that is already on the page, opened again.
##
## The words were kept, not just their picture, so this re-opens the same
## settings and re-renders from the text. Nothing is traced over or resampled.
func edit_text_layer(index: int) -> void:
	_close_panel()
	var stack: LayerStack = view.layers
	if index < 0 or index >= stack.layers.size():
		return
	var l: LayerStack.Layer = stack.layers[index]
	if not l.is_text:
		return
	stack.set_active(index)
	_text_state = l.text_state.duplicate(true)
	view.begin_text_box(l.id)
	_mount(ToolPanels.text_maker(_text_state,
		func() -> void: pass,
		func() -> void: _restyle_text(l)), "text")

## The box was let go of, so the writing is drawn again where and how it now
## sits. This is the whole reason text keeps its edge no matter how often it
## is turned: it is never a picture being rotated, always words being written.
func _redraw_text_layer(layer_id: int) -> void:
	var stack: LayerStack = view.layers
	var l: LayerStack.Layer = null
	for one in stack.layers:
		if one.id == layer_id:
			l = one
			break
	if l == null or not l.is_text or l.text_state.is_empty():
		return
	var doc: Dictionary = l.text_state.duplicate(true)
	doc["turn"] = l.text_turn
	var made: Image = await TextRender.render(doc)
	if made == null:
		return
	view.replace_text_at(layer_id, made, l.text_at)

func _restyle_text(l: LayerStack.Layer) -> void:
	var words: String = String(_text_state.get("text", "")).strip_edges()
	if words == "":
		_flash(UiKit.label_for("Write something first", "اكتب شيئاً أولاً"))
		return
	var doc: Dictionary = _text_state.duplicate(true)
	doc["turn"] = l.text_turn
	var made: Image = await TextRender.render(doc)
	if made == null:
		return
	l.text_state = _text_state.duplicate(true)
	view.replace_text_pixels(l.id, made)
	_close_panel()
	_flash(UiKit.label_for("Text updated", "حُدّث النص"))

# ---------------------------------------------------------- character 360

func enter_360_room() -> void:
	_close_panel()
	if room_360 != null or bspline_room != null:
		return
	if not view.has_project():
		_flash(UiKit.label_for("Open a project first", "افتح مشروعاً أولاً"))
		return
	var room: Room360 = Room360.new()
	if not room.setup(view):
		room.queue_free()
		return
	room_360 = room
	room.closed.connect(_leave_360_room)
	room.exported.connect(_take_360_character)
	_ui.add_child(room)
	_room_shell(true)

func _leave_360_room() -> void:
	if room_360 == null:
		return
	room_360.queue_free()
	room_360 = null
	_room_shell(false)

## The turnaround comes back as a layer of its own.
##
## It is not flattened into ink. The eight drawings and the angle stay on the
## layer, so it can still be turned after it has been placed — a character
## that could only be turned inside the room it was imported in would be a
## picture of a character.
func _take_360_character(character: Character360) -> void:
	if character == null or character.count() == 0:
		return
	var stack: LayerStack = view.layers
	var layer: LayerStack.Layer = stack.add_layer_here()
	if layer == null:
		_flash(UiKit.label_for("No room for another layer", "لا مكان لطبقة أخرى"))
		return
	layer.title = UiKit.label_for("Layer 360", "طبقة ٣٦٠")
	layer.is_360 = true
	layer.character = character
	layer.turn_360 = room_360.turn if room_360 != null else 0.0
	if room_360 != null:
		layer.rig_360 = room_360.rig
	# A rigged layer is posed, never redrawn — so the frame button on it can
	# only ever duplicate what is there and step forward. This is the flag
	# the timeline reads; see LayerStack.frames_locked.
	layer.rig = {"kind": "360"}

	_stamp_360(layer)
	stack.changed.emit()
	view.projects.mark_dirty(view.projects.active)
	_leave_360_room()
	_flash(UiKit.label_for("Character placed as Layer 360",
		"وُضعت الشخصية كطبقة ٣٦٠"))

## Draws the figure at its current angle into the layer's pixels.
##
## The drawing on the canvas is only ever the pose it is turned to. Nothing of
## the rig — no grid, no guide, no control — is ever written into it: those
## belong to the room, and a character exported with its scaffolding still on
## it would be unusable.
func _stamp_360(layer: LayerStack.Layer) -> void:
	var character: Character360 = layer.character
	if character == null:
		return
	var pair: Dictionary = character.between(layer.turn_360)
	if pair.is_empty():
		return
	var pose: Character360.Pose = pair["a"]
	if pose == null or pose.art == null:
		return
	var page: Vector2 = view.projects.active.page
	var trimmed: Image = Image.create_empty(pose.ink.size.x, pose.ink.size.y,
		false, Image.FORMAT_RGBA8)
	trimmed.blit_rect(pose.art, pose.ink, Vector2i.ZERO)
	# Premultiplied on the way in, because that is the form the canvas keeps
	# and an ordinary image blitted straight in would show a bright fringe
	# everywhere its edge is soft. `_premultiply` already existed for image
	# import — it is shared rather than written again.
	_premultiply(trimmed)
	var at: Vector2i = Vector2i(
		int(round((page.x - float(pose.ink.size.x)) * 0.5)),
		int(round(page.y - float(pose.ink.size.y))))
	layer.surface.clear_all()
	layer.surface.blit_image(trimmed, Vector2(at), true)


## Turning a placed character re-draws it. The layer still holds all eight
## drawings, so this is a fresh pose rather than a rotated picture of one.
func _turn_360_layer(index: int) -> void:
	var stack: LayerStack = view.layers
	if index < 0 or index >= stack.layers.size():
		return
	var l: LayerStack.Layer = stack.layers[index]
	if not l.is_360 or l.character == null:
		return
	_stamp_360(l)
	stack.changed.emit()
	view.projects.mark_dirty(view.projects.active)

func _room_shell(inside: bool) -> void:
	if rail != null:
		rail.visible = not inside and view.projects.focus_on != null
	if edit_bar != null:
		edit_bar.visible = not inside and view.projects.focus_on != null
	if layer_btn_bar != null:
		layer_btn_bar.visible = not inside
	if coord_bar != null:
		coord_bar.visible = not inside and view.projects.focus_on != null
	if timeline_btn != null and inside:
		timeline_btn.visible = false
	if not inside:
		_sync_shell()
		_refresh_timeline_button()
		_refresh_action_bar()
	_layout()

# ------------------------------------------------------------- b-spline room

func enter_bspline_room() -> void:
	_close_panel()
	if bspline_room != null:
		return
	var room: BSplineRoom = BSplineRoom.new()
	if not room.setup(view):
		room.queue_free()
		_flash(UiKit.label_for("Draw something on this layer first",
			"ارسم شيئاً على هذه الطبقة أولاً"))
		return
	bspline_room = room
	room.closed.connect(_leave_bspline_room)
	room.applied.connect(func() -> void:
		_flash(UiKit.label_for("Applied", "طُبّق")))
	_ui.add_child(room)
	_bspline_shell(true)

## The folder, opened as one figure.
func enter_animation_layer(group_id: int) -> void:
	_close_panel()
	if bspline_room != null:
		return
	var room: BSplineRoom = BSplineRoom.new()
	if not room.setup_group(view, group_id):
		room.queue_free()
		_flash(UiKit.label_for("Nothing in this folder has bones yet",
			"لا شيء في هذا المجلد له عظام بعد"))
		return
	bspline_room = room
	room.closed.connect(_leave_bspline_room)
	room.applied.connect(func() -> void:
		_flash(UiKit.label_for("Applied", "طُبّق")))
	_ui.add_child(room)
	_bspline_shell(true)

func _leave_bspline_room() -> void:
	if bspline_room == null:
		return
	bspline_room.queue_free()
	bspline_room = null
	_bspline_shell(false)

## The room is the whole screen while it is open, so the shell steps aside
## entirely — the only way out is the one door it puts at the top right.
func _bspline_shell(inside: bool) -> void:
	if rail != null:
		rail.visible = not inside and view.projects.focus_on != null
	if edit_bar != null:
		edit_bar.visible = not inside and view.projects.focus_on != null
	if layer_btn_bar != null:
		layer_btn_bar.visible = not inside
	if coord_bar != null:
		coord_bar.visible = not inside and view.projects.focus_on != null
	if timeline_btn != null and inside:
		timeline_btn.visible = false
	if not inside:
		_sync_shell()
		_refresh_timeline_button()
		_refresh_action_bar()
	_layout()

# ------------------------------------------------------------ puppet warp

## While a layer is being bent there is nothing else the screen should be
## offering, so the bar carries only the three things left to decide: change
## how it bends, put it down, or take it back.
func _build_puppet_bar() -> void:
	puppet_bar = PanelContainer.new()
	puppet_bar.add_theme_stylebox_override("panel", UiKit.rail_style())
	puppet_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	puppet_bar.visible = false
	_ui.add_child(puppet_bar)
	puppet_bar.resized.connect(_layout)

	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", int(UiKit.s(6.0)))
	puppet_bar.add_child(row)

	var tune: Button = UiKit.make_text_button(
		UiKit.label_for("Settings", "الإعدادات"), true)
	tune.custom_minimum_size = Vector2(UiKit.s(108.0), UiKit.s(46.0))
	tune.pressed.connect(func() -> void:
		_close_panel()
		_mount(ToolPanels.puppet_warp(view), "puppet"))
	row.add_child(tune)

	var drop: Button = UiKit.make_text_button(
		UiKit.label_for("Cancel", "إلغاء"), true)
	drop.custom_minimum_size = Vector2(UiKit.s(100.0), UiKit.s(46.0))
	drop.pressed.connect(func() -> void: _finish_puppet(false))
	row.add_child(drop)

	var keep: Button = UiKit.make_text_button(
		UiKit.label_for("Apply", "تطبيق"), true)
	keep.custom_minimum_size = Vector2(UiKit.s(118.0), UiKit.s(46.0))
	keep.pressed.connect(func() -> void: _finish_puppet(true))
	row.add_child(keep)

## While a warp is on, everything that draws or edits pixels steps aside.
##
## The layer being bent has been emptied for the duration, so an undo or a
## brush stroke landing on it now would be acting on a page that is not
## really there. Taking the controls off screen is more honest than leaving
## them where they are and quietly ignoring them.
func _puppet_shell(warping: bool) -> void:
	var inside: bool = view.projects.focus_on != null
	if rail != null:
		rail.visible = inside and not warping
	if edit_bar != null:
		edit_bar.visible = inside and not warping
	if action_bar != null:
		action_bar.visible = not warping
	if coord_bar != null:
		coord_bar.visible = inside and not warping
	if timeline_btn != null and warping:
		timeline_btn.visible = false
	if not warping:
		_sync_shell()
		_refresh_timeline_button()
		_refresh_action_bar()
	_layout()

func start_puppet_warp(_index: int = -1) -> void:
	_close_panel()
	if not view.begin_puppet_warp():
		_flash(UiKit.label_for("Draw something first", "ارسم شيئاً أولاً"))
		return
	if puppet_bar != null:
		puppet_bar.visible = true
	_puppet_shell(true)
	_flash(UiKit.label_for("Pin what should stay, then pull what should move",
		"ثبّت ما يجب أن يبقى، ثم اسحب ما يجب أن يتحرك"))
	_layout()

func _finish_puppet(keep: bool) -> void:
	_close_panel()
	await view.end_puppet_warp(keep)
	if puppet_bar != null:
		puppet_bar.visible = false
	_puppet_shell(false)
	_flash(UiKit.label_for("Puppet warp applied", "طُبّق التحريك بالدبابيس")
		if keep else UiKit.label_for("Puppet warp cancelled", "أُلغي التحريك بالدبابيس"))
	_layout()

# ------------------------------------------------------- symmetry quick exit

func _build_symmetry_cancel() -> void:
	_btn_symmetry_cancel = UiKit.make_text_button(
		UiKit.label_for("Cancel symmetry", "إلغاء التناظر"), true)
	_btn_symmetry_cancel.visible = false
	_btn_symmetry_cancel.custom_minimum_size = Vector2(UiKit.s(172.0), UiKit.s(42.0))
	_btn_symmetry_cancel.pressed.connect(func() -> void:
		view.cancel_lateral_symmetry())
	_ui.add_child(_btn_symmetry_cancel)

func _on_symmetry_mode_changed(enabled: bool) -> void:
	if _btn_symmetry_cancel == null:
		return
	_btn_symmetry_cancel.visible = enabled and view.has_project()
	_layout()

# ------------------------------------------------------------- input event

func _open_input_event() -> void:
	_close_panel()
	var shell: PanelContainer = PanelContainer.new()
	shell.add_theme_stylebox_override("panel", UiKit.panel_style())
	shell.custom_minimum_size = Vector2(UiKit.s(250.0), 0.0)
	var v: TouchScroll = UiKit.scroller(VBoxContainer.new(), UiKit.s(300.0))
	var content: VBoxContainer = v.content as VBoxContainer
	content.add_theme_constant_override("separation", int(UiKit.s(8.0)))
	shell.add_child(v)
	content.add_child(UiKit.make_label(UiKit.label_for("Input event", "حدث الإدخال"), 15.0, UiKit.TEXT))
	var select: Button = UiKit.make_tool_button(ICON % "selection",
		UiKit.label_for("Selection tools", "أدوات التحديد"))
	select.custom_minimum_size = Vector2(UiKit.s(190.0), UiKit.s(52.0))
	select.pressed.connect(func() -> void:
		_close_panel()
		_mount(ToolPanels.selection(view), "select"))
	content.add_child(select)
	var lateral: Button = UiKit.make_tool_button(ICON % "lateral_symmetry",
		UiKit.label_for("Lateral symmetry", "التناظر الجانبي"))
	lateral.custom_minimum_size = Vector2(UiKit.s(190.0), UiKit.s(52.0))
	lateral.pressed.connect(func() -> void:
		_close_panel()
		_mount(ToolPanels.lateral_symmetry(view), "symmetry"))
	content.add_child(lateral)
	_mount(shell, "input_event")


# ------------------------------------------------------------------ panels

func _toggle_panel(id: String) -> void:
	var was: String = open_panel
	_close_panel()
	if was == id:
		return

	var built: PanelContainer = null
	if id == "brush":
		built = ToolPanels.brush(view)
	elif id == "eraser":
		built = ToolPanels.eraser(view)
	elif id == "shapes":
		built = ToolPanels.shapes(view)
	elif id == "select":
		built = ToolPanels.selection(view)
	elif id == "color":
		built = ToolPanels.color(view, false)
	elif id == "fill":
		built = ToolPanels.fill(view)
	elif id == "layers":
		if not view.has_project():
			_flash(UiKit.label_for("Open a project first", "افتح مشروعاً أولاً"))
			return
		layers_panel = LayersPanel.new()
		layers_panel.setup(view)
		layers_panel.solo_requested.connect(_enter_solo)
		layers_panel.import_requested.connect(_ask_for_image)
		layers_panel.puppet_requested.connect(start_puppet_warp)
		layers_panel.animation_layer_requested.connect(enter_animation_layer)
		layers_panel.text_edit_requested.connect(edit_text_layer)
		layers_panel.turn_360_requested.connect(_turn_360_layer)
		built = layers_panel
		_thumb_timer = 0.0
	elif id == "compass":
		if not view.has_project():
			_flash(UiKit.label_for("Open a project first", "افتح مشروعاً أولاً"))
			return
		built = _compass_panel()
	elif id == "settings":
		_settings_page = "menu"
		built = SettingsPanels.menu(self)
	if built == null:
		return

	_show_shade(true)
	panel_host = built
	panel_host.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	_ui.add_child(panel_host)
	panel_host.resized.connect(_layout)
	open_panel = id
	_fit_panel_to_content()
	_layout()
	call_deferred("_fit_panel_to_content")

## The shade sits at the bottom of the interface layer: above the drawing,
## below every button. So a tap on the canvas closes the panel, while the
## tool rail and the bars keep working — switching straight from one panel
## to another without a wasted tap in between.
func _show_shade(on: bool) -> void:
	if _shade == null:
		return
	_shade.visible = on
	if on:
		_ui.move_child(_shade, 0)

## A panel closes when the user taps away from it — press and release both
## outside it, close together. Closing on the press alone was enough while
## every touch stayed where it started, but a finger that scrolls a panel
## and drifts past its edge releases out here, and the panel it was reading
## went away underneath it. So both ends of the tap have to agree.
func _shade_touched(event: InputEvent) -> void:
	if panel_host == null:
		_show_shade(false)
		return
	if event is InputEventScreenTouch:
		var st: InputEventScreenTouch = event as InputEventScreenTouch
		if st.pressed:
			_shade_from = st.position
			_shade_armed = true
		elif _shade_armed:
			_shade_armed = false
			if _shade_from.distance_to(st.position) <= UiKit.s(28.0):
				_close_panel()
	elif event is InputEventMouseButton:
		var mb: InputEventMouseButton = event as InputEventMouseButton
		if mb.button_index != MOUSE_BUTTON_LEFT:
			return
		if mb.pressed:
			_shade_from = mb.position
			_shade_armed = true
		elif _shade_armed:
			_shade_armed = false
			if _shade_from.distance_to(mb.position) <= UiKit.s(28.0):
				_close_panel()

func _fit_panel_to_content() -> void:
	if panel_host == null:
		return
	var room: Vector2 = size - Vector2(UiKit.s(24.0), UiKit.s(24.0))
	var desired: float = 0.0
	if panel_host.has_meta("desired_width"):
		desired = float(panel_host.get_meta("desired_width"))
	var minimum: Vector2 = panel_host.get_combined_minimum_size()
	var width: float = maxf(minimum.x, UiKit.s(240.0))
	if desired > 0.0:
		width = minf(maxf(width, minf(desired, room.x)), room.x)
	width = minf(width, room.x)
	var content_h: float = maxf(minimum.y, UiKit.s(52.0))
	var height: float = minf(content_h, room.y)
	panel_host.custom_minimum_size = Vector2(width, height)
	panel_host.size = Vector2(width, height)

func _close_panel() -> void:
	_shade_armed = false
	if panel_host != null:
		panel_host.queue_free()
		panel_host = null
	layers_panel = null
	open_panel = ""
	_show_shade(false)
	_sync_rail()

# --------------------------------------------------------------- solo view

func _build_solo_bar() -> void:
	solo_bar = PanelContainer.new()
	solo_bar.add_theme_stylebox_override("panel", UiKit.rail_style())
	solo_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	solo_bar.visible = false
	_ui.add_child(solo_bar)
	solo_bar.resized.connect(_layout)

	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", int(UiKit.s(8.0)))
	solo_bar.add_child(row)

	var back: Button = UiKit.make_text_button(UiKit.label_for("Back", "رجوع"))
	back.pressed.connect(_leave_solo)
	row.add_child(back)

	var note: Label = UiKit.make_label(
		UiKit.label_for("This layer only", "هذه الطبقة وحدها"), 12.0, UiKit.ON_RAIL)
	note.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(note)

## Shows one layer by itself, so it can be checked without the rest in the
## way. Nothing is changed — the others are only hidden for the moment.
func _enter_solo(index: int) -> void:
	if index < 0 or index >= view.layers.layers.size():
		return
	solo_index = index
	view.layers.set_active(index)
	view.layers.set_solo(view.layers.layers[index].id)
	_close_panel()
	_sync_rail()
	solo_bar.visible = true
	_layout()

func _leave_solo() -> void:
	solo_index = -1
	view.layers.set_solo(0)
	solo_bar.visible = false

# --------------------------------------------------------- floating pieces

func _build_action_bar() -> void:
	action_bar = PanelContainer.new()
	action_bar.add_theme_stylebox_override("panel", UiKit.rail_style())
	action_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	action_bar.visible = false
	_ui.add_child(action_bar)
	action_bar.resized.connect(_layout)

	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", int(UiKit.s(6.0)))
	action_bar.add_child(row)

	_btn_close_shape = UiKit.make_text_button(
		UiKit.label_for("Close shape", "أغلق الشكل"), true)
	_btn_close_shape.pressed.connect(func() -> void: view.close_selection())
	row.add_child(_btn_close_shape)

	_btn_place = UiKit.make_text_button(UiKit.label_for("Place", "ثبّت"))
	_btn_place.pressed.connect(func() -> void: view.commit_selection())
	row.add_child(_btn_place)

	_btn_cancel = UiKit.make_text_button(UiKit.label_for("Cancel", "إلغاء"))
	_btn_cancel.pressed.connect(func() -> void: view.cancel_selection())
	row.add_child(_btn_cancel)

func _refresh_action_bar() -> void:
	if action_bar == null:
		return
	var floating: bool = view.sel_active
	var marking: bool = view.has_marks() and App.select_shape == App.SelectShape.POLY
	_btn_close_shape.visible = marking and not floating
	_btn_place.visible = floating
	_btn_cancel.visible = floating
	action_bar.visible = floating or marking
	_layout()

# ----------------------------------------------------------- small readouts

func _build_coord_bar() -> void:
	coord_bar = PanelContainer.new()
	coord_bar.add_theme_stylebox_override("panel", UiKit.rail_style())
	coord_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	coord_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui.add_child(coord_bar)
	coord_bar.resized.connect(_layout)

	coord_label = UiKit.make_label("X 0   Y 0", 11.0, UiKit.ON_RAIL)
	coord_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	coord_label.custom_minimum_size = Vector2(UiKit.s(148.0), 0.0)
	coord_bar.add_child(coord_label)

func _build_zoom_badge() -> void:
	zoom_badge = PanelContainer.new()
	zoom_badge.add_theme_stylebox_override("panel", UiKit.rail_style())
	zoom_badge.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	zoom_badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	zoom_badge.visible = false
	_ui.add_child(zoom_badge)
	zoom_badge.resized.connect(_layout)

	zoom_label = UiKit.make_label("100%", 15.0, Color.WHITE)
	zoom_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	zoom_label.custom_minimum_size = Vector2(UiKit.s(96.0), 0.0)
	zoom_badge.add_child(zoom_label)

## Undo now reaches structure as well as pixels, and a layer reappearing at
## the far end of a list is easy to miss. A one-line note says what moved.
func _build_note_badge() -> void:
	note_badge = PanelContainer.new()
	note_badge.add_theme_stylebox_override("panel", UiKit.rail_style())
	note_badge.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	note_badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	note_badge.visible = false
	_ui.add_child(note_badge)
	note_badge.resized.connect(_layout)

	note_label = UiKit.make_label("", 12.0, UiKit.ON_RAIL)
	note_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	note_label.custom_minimum_size = Vector2(UiKit.s(150.0), 0.0)
	note_badge.add_child(note_label)

func _flash(text: String) -> void:
	if note_label == null:
		return
	note_label.text = text
	note_badge.visible = true
	_note_timer = 1.1
	_layout()

## Undo now reaches structure as well as pixels, and a layer reappearing at
## the far end of a list is easy to miss. A one-line note says what moved.
func _on_action(label: String, undone: bool) -> void:
	_flash(("< " if undone else "> ") + label)

## The bar that only exists inside focus: a way out, a way to bring the
## neighbours back, and — for a comic — the page controls, which belong
## here rather than buried in a menu.
## The focus controls live in the project's own menu, reached from the strip
## above it. A permanent bar across the bottom of the screen is a bar across
## the drawing — the one place that has to stay clear.
func _refresh_focus_bar() -> void:
	_refresh_page_bar()
	_refresh_timeline_button()
	if open_panel == "settings" and _options_for != null:
		_show_project_options(_options_for)

## Turning pages is something a reader does constantly, so it belongs under
## the thumb rather than three taps deep in a menu. It appears only while a
## multi-page project is focused, and takes no room at any other time.
func _build_page_bar() -> void:
	page_bar = PanelContainer.new()
	page_bar.add_theme_stylebox_override("panel", UiKit.rail_style())
	page_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	page_bar.visible = false
	_ui.add_child(page_bar)
	page_bar.resized.connect(_layout)

	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", int(UiKit.s(5.0)))
	page_bar.add_child(row)

	var prev: Button = UiKit.make_text_button(UiKit.label_for("Previous", "السابقة"), true)
	prev.custom_minimum_size = Vector2(UiKit.s(96.0), UiKit.s(46.0))
	prev.pressed.connect(func() -> void: page_step(-1))
	row.add_child(prev)

	# The plus sits between them, where a thumb reaching for "one more" will
	# already be, and reads as one mark rather than a word to parse.
	var more: Button = UiKit.make_text_button("+")
	more.custom_minimum_size = Vector2(UiKit.s(58.0), UiKit.s(46.0))
	more.add_theme_font_size_override("font_size", int(UiKit.s(22.0)))
	more.tooltip_text = UiKit.label_for("Add page", "أضف صفحة")
	more.pressed.connect(add_page_here)
	row.add_child(more)

	var next: Button = UiKit.make_text_button(UiKit.label_for("Next", "التالية"), true)
	next.custom_minimum_size = Vector2(UiKit.s(96.0), UiKit.s(46.0))
	next.pressed.connect(func() -> void: page_step(1))
	row.add_child(next)

	_page_label = UiKit.make_label("1/1", 12.0, UiKit.ON_RAIL)
	_page_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_page_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_page_label.custom_minimum_size = Vector2(UiKit.s(52.0), 0.0)
	row.add_child(_page_label)

## Alone in the bottom-left corner, away from everything else, because it
## changes the shape of the whole document rather than the current page.
func _build_layout_bar() -> void:
	layout_bar = PanelContainer.new()
	layout_bar.add_theme_stylebox_override("panel", UiKit.rail_style())
	layout_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	layout_bar.visible = false
	_ui.add_child(layout_bar)
	layout_bar.resized.connect(_layout)

	_layout_btn = UiKit.make_text_button(UiKit.label_for("Side by side", "جنباً إلى جنب"), true)
	_layout_btn.custom_minimum_size = Vector2(UiKit.s(120.0), UiKit.s(46.0))
	_layout_btn.pressed.connect(toggle_layout)
	layout_bar.add_child(_layout_btn)

## Bottom right, and only while an animation project is focused. The
## timeline is the one panel that belongs to a single kind of project, so a
## button for it in the general rail was a button that did nothing most of
## the time.
func _build_timeline_button() -> void:
	timeline_btn = PanelContainer.new()
	timeline_btn.add_theme_stylebox_override("panel", UiKit.rail_style())
	timeline_btn.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	timeline_btn.visible = false
	_ui.add_child(timeline_btn)
	timeline_btn.resized.connect(_layout)

	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", int(UiKit.s(5.0)))
	timeline_btn.add_child(row)

	var b: Button = UiKit.make_text_button(
		UiKit.label_for("Timeline", "التايم لاين"), true)
	b.custom_minimum_size = Vector2(UiKit.s(126.0), UiKit.s(46.0))
	b.pressed.connect(_toggle_timeline)
	row.add_child(b)


func _refresh_timeline_button() -> void:
	if timeline_btn == null:
		return
	var p: ProjectManager.Project = current_project()
	timeline_btn.visible = p != null and p.kind == ProjectManager.Kind.ANIMATION
	_layout()

func _refresh_page_bar() -> void:
	if page_bar == null:
		return
	var p: ProjectManager.Project = view.projects.focus_on
	var wanted: bool = p != null and p.kind == ProjectManager.Kind.COMIC
	page_bar.visible = wanted
	if layout_bar != null:
		layout_bar.visible = wanted
	if wanted:
		_page_label.text = "%d/%d" % [_comic_page + 1, p.pages]
		if _layout_btn != null:
			_layout_btn.text = UiKit.label_for("Side by side", "جنباً إلى جنب") \
				if p.stacked else UiKit.label_for("Stacked", "فوق بعضها")
	_layout()

## The timeline is not a floating panel: it is a band the canvas gives room
## to. So it lives outside the panel system, and the drawing area shrinks to
## meet it rather than being covered by it.
func _toggle_timeline() -> void:
	if timeline != null:
		_close_timeline()
		return
	var p: ProjectManager.Project = current_project()
	if p == null:
		_flash(UiKit.label_for("Open a project first", "افتح مشروعاً أولاً"))
		return
	if p.kind != ProjectManager.Kind.ANIMATION:
		_flash(UiKit.label_for("Animation projects only", "لمشاريع الرسوم المتحركة فقط"))
		return
	timeline = TimelinePanel.new()
	timeline.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	_ui.add_child(timeline)
	timeline.setup(view.player, p.clip, p.stack, view)
	timeline.closed.connect(_close_timeline)
	timeline.resized.connect(_layout)
	_sync_rail()
	_refresh_timeline_button()
	_layout()

## Hidden, not closed: the clip and the playhead stay exactly where they
## were, and the same tap brings the band back.
func _toggle_timeline_visible() -> void:
	if timeline == null:
		_toggle_timeline()
		return
	timeline.visible = not timeline.visible
	_refresh_timeline_button()
	_layout()

func _close_timeline() -> void:
	if timeline == null:
		return
	timeline.queue_free()
	timeline = null
	_sync_rail()
	_refresh_timeline_button()
	_layout()

func _on_pointer(world_pos: Vector2) -> void:
	_last_world = world_pos
	_update_coords()

## Precision tracks the zoom: no fake decimals when far out, three when close.
func _update_coords() -> void:
	if coord_label == null or view == null:
		return
	var step: float = view.grid_step()
	coord_label.text = "X %s   Y %s" % [
		GridBackground.fmt(_last_world.x, step),
		GridBackground.fmt(_last_world.y, step)]

## The zoom badge is not a permanent fixture — it appears while the pinch is
## happening and fades out once the answer stops changing.
func _on_zoom(z: float) -> void:
	if zoom_label == null:
		return
	if not is_equal_approx(z, _last_zoom):
		_last_zoom = z
		_zoom_timer = ZOOM_HOLD
		zoom_badge.visible = true
	if z < 0.1:
		zoom_label.text = "%.1f%%" % (z * 100.0)
	else:
		zoom_label.text = "%d%%" % int(round(z * 100.0))
	_update_coords()
	_layout()

# ---------------------------------------------------------------- settings

## The settings button is a stack of pages rather than a pile of dialogs:
## one panel, one place on screen, and Back always means the same thing.
func open_settings_page(page: String) -> void:
	_settings_page = page
	_close_panel()
	var built: PanelContainer = null
	if page == "new":
		built = SettingsPanels.new_project(self, "drawing")
	elif page == "comic":
		built = SettingsPanels.new_project(self, "comic")
	elif page == "animation_new":
		built = SettingsPanels.new_project(self, "animation")
	elif page == "language":
		built = SettingsPanels.language(self)
	elif page == "frame":
		built = SettingsPanels.frame_colour(self)
	elif page == "export":
		built = SettingsPanels.export_page(self)
	elif page == "share":
		built = SettingsPanels.share_page(self)
	elif page == "animation":
		built = SettingsPanels.animation_page(self)
	elif page == "storage":
		built = SettingsPanels.storage_page(self)
	elif page == "information":
		built = SettingsPanels.information(self)
	else:
		built = SettingsPanels.menu(self)
	_mount(built, "settings")

## Settings pages own their button lifecycle. Navigation buttons rebuild the
## page, while actions such as presets deliberately keep the current page open.
## Do not attach a global close callback here: a deferred close could destroy a
## newly mounted page immediately after its action runs.

func _mount(built: PanelContainer, id: String) -> void:
	if built == null:
		return
	_show_shade(true)
	panel_host = built
	panel_host.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	_ui.add_child(panel_host)
	panel_host.resized.connect(_layout)
	open_panel = id
	_fit_panel_to_content()
	_layout()
	call_deferred("_fit_panel_to_content")
	_sync_rail()

func current_project() -> ProjectManager.Project:
	return view.projects.active

## New sheets appear in the middle of what the user is looking at, whatever
## corner of the endless grid that happens to be.
func spawn_project(title: String, kind: int, page_size: Vector2,
		paper: Color, pages: int, fps: int = 24, frames: int = 24) -> void:
	var centre: Vector2 = view.screen_to_world(view.size * 0.5)
	var p: ProjectManager.Project = view.projects.create(
		title, kind, page_size, paper, pages, centre)
	if p != null and kind == ProjectManager.Kind.ANIMATION:
		p.fps = clampi(fps, 1, 60)
		p.frames = clampi(frames, 1, Anim.CEILING_FRAMES)
		for page in p.sheets:
			(page as ProjectManager.Page).clip.fps = p.fps
			(page as ProjectManager.Page).clip.length = p.frames
	if p == null:
		_flash(UiKit.label_for("Too many projects", "عدد المشاريع بلغ الحد"))
		return
	_close_panel()
	# A newly created project is immediately placed and opened, but its settings
	# stay closed until the user explicitly presses the Settings gear.
	view.projects.place(p)
	view.projects.open(p)
	view.projects.set_focus(p)
	view.frame_project(p)
	_comic_page = 0
	_sync_shell()
	_refresh_timeline_button()
	_refresh_focus_bar()
	_flash(p.title)

func set_language(code: int) -> void:
	Lang.current = code
	_close_panel()
	_rebuild_chrome()
	_flash(Lang.name_of(code))

## The swatch has answered; the sheet has nothing left to say.
func frame_colour_chosen() -> void:
	view.chrome.refresh(view.view_zoom)
	_close_panel()

func set_frame_colour(c: Color) -> void:
	var p: ProjectManager.Project = current_project()
	if p == null:
		return
	p.frame = c
	view.chrome.refresh(view.view_zoom)

func toggle_favourite() -> void:
	toggle_favourite_of(current_project())

func toggle_favourite_of(p: ProjectManager.Project) -> void:
	if p == null:
		return
	p.favourite = not p.favourite
	view.chrome.refresh(view.view_zoom)
	_close_panel()

## Writes the project to disk and leaves it open — the thing you want after
## an hour's work, which "save and close" was never quite.
func save_project() -> void:
	var p: ProjectManager.Project = current_project()
	if p == null:
		return
	if Vault.save(p):
		view.projects.mark_saved(p)
		_close_panel()
		_flash(UiKit.label_for("Saved", "حُفظ"))
	else:
		_flash(UiKit.label_for("Save failed — try again", "فشل الحفظ — حاول مرة أخرى"))

func save_and_close() -> void:
	close_project(current_project())

func close_project(p: ProjectManager.Project) -> void:
	if p == null:
		return
	if Vault.save(p):
		view.projects.mark_saved(p)
	if view.projects.focus_on == p:
		leave_focus()
	view.projects.close(p)
	_close_panel()
	_flash(UiKit.label_for("Save and close", "حفظ وإغلاق"))

func open_project(p: ProjectManager.Project) -> void:
	view.projects.open(p)
	if p != null:
		_comic_page = p.active_page
	_refresh_timeline_button()
	_close_panel()

func duplicate_project(p: ProjectManager.Project) -> void:
	view.projects.duplicate_project(p)
	_close_panel()

## Deleting means gone: from the workspace, from disk, and from anything
## left on disk that no longer answers to a project — which is what used to
## bring a deleted project back on the next launch.
func delete_project(p: ProjectManager.Project) -> void:
	if p == null:
		return
	if view.projects.focus_on == p:
		leave_focus()
	Vault.forget(p.id)
	view.projects.remove(p)
	Vault.purge_orphans(view.projects)
	_sync_shell()
	_refresh_timeline_button()
	_close_panel()
	_flash(UiKit.label_for("Deleted", "حُذف"))

func add_page(p: ProjectManager.Project) -> void:
	view.projects.add_page(p)
	_close_panel()

## Focus fills the screen with one project and takes the neighbours out of
## sight — and out of the render. Zoom and pan stay free inside it.
func focus_project(p: ProjectManager.Project) -> void:
	if p == null:
		return
	view.projects.open(p)
	_comic_page = p.active_page
	view.projects.set_focus(p)
	p.grid_guide = true
	view.frame_project(p)
	_comic_page = 0
	_close_panel()
	_sync_shell()
	_flash(UiKit.label_for("Turn with two fingers", "أدر بإصبعين"))

func leave_focus() -> void:
	var p: ProjectManager.Project = view.projects.focus_on
	if p != null:
		p.grid_guide = false
	view.projects.clear_focus()
	_sync_shell()
	_refresh_focus_bar()

func toggle_neighbours() -> void:
	view.projects.set_focus_shows_others(not view.projects.focus_shows_others)
	_refresh_focus_bar()

func toggle_guide() -> void:
	var p: ProjectManager.Project = current_project()
	if p == null:
		return
	p.grid_guide = not p.grid_guide
	view.projects.move_to(p, p.origin)

func page_step(delta: int) -> void:
	var p: ProjectManager.Project = current_project()
	if p == null:
		return
	_comic_page = clampi(_comic_page + delta, 0, p.pages - 1)
	# Turning the page changes which drawing the tools touch, not just
	# where the camera looks.
	view.projects.set_page(p, _comic_page)
	view.frame_page(p, _comic_page)
	_refresh_focus_bar()

func add_page_here() -> void:
	var p: ProjectManager.Project = current_project()
	if p == null:
		return
	view.projects.add_page(p)
	_comic_page = p.pages - 1
	view.frame_page(p, _comic_page)
	_refresh_focus_bar()

## Across or down. Both read as a strip; which suits depends on the screen.
func toggle_layout() -> void:
	var p: ProjectManager.Project = current_project()
	if p == null:
		return
	view.projects.set_layout_stacked(p, not p.stacked)
	view.frame_page(p, _comic_page)
	_refresh_focus_bar()

func set_fps(value: int) -> void:
	var p: ProjectManager.Project = current_project()
	if p == null:
		return
	p.fps = clampi(value, 1, 60)
	for page in p.sheets:
		(page as ProjectManager.Page).clip.fps = p.fps
	view.projects.mark_dirty(p)

func set_frames(value: int) -> void:
	var p: ProjectManager.Project = current_project()
	if p == null:
		return
	p.frames = clampi(value, 1, 3600)
	for page in p.sheets:
		(page as ProjectManager.Page).clip.length = p.frames
	view.projects.mark_dirty(p)

func run_export(kind: String) -> void:
	var p: ProjectManager.Project = current_project()
	if p == null:
		_flash(UiKit.label_for("Nothing to export yet", "لا يوجد ما يُصدَّر بعد"))
		return
	var out: String = ""
	if kind == "png" or kind == "jpg" or kind == "webp":
		out = Exporters.save_flat(p, kind, false)
	elif kind == "pages":
		out = Exporters.save_flat(p, "png", true)
	elif kind == "psd":
		out = Exporters.save_psd(p)
	elif kind == "cbz":
		out = Exporters.save_cbz(p)
	elif kind == "pdf":
		out = Exporters.save_pdf(p)
	elif kind == "sequence":
		out = Exporters.save_sequence(p)
	elif kind == "sheet":
		out = Exporters.save_sprite_sheet(p)
	elif kind == "gif":
		out = Exporters.save_gif(p, 0)
	elif kind == "gif_small":
		out = Exporters.save_gif(p, 800)
	elif kind == "webp_anim":
		out = Exporters.save_webp_anim(p, 0)
	elif kind == "webp_anim_small":
		out = Exporters.save_webp_anim(p, 960)
	if out == "":
		_flash(UiKit.label_for("Nothing to export yet", "لا يوجد ما يُصدَّر بعد"))
		return
	_flash("%s %s" % [UiKit.label_for("Saved to", "حُفظ في"), out.get_file()])

# ------------------------------------------------------------ placing art

var _picker: FileDialog = null
var _import_into: int = -1
var _last_import_dir: String = ""

## Godot's own browser rather than the system picker: the system picker
## hands back a content URI that this engine cannot open, while the browser
## returns a real path Image.load understands. It starts in the folder the
## camera and the download manager write to, which is where a picture the
## user means to place almost always is.
func _ask_for_image(layer_index: int) -> void:
	if not view.has_project():
		_flash(UiKit.label_for("Open a project first", "افتح مشروعاً أولاً"))
		return
	_import_into = layer_index
	if _picker == null:
		_picker = FileDialog.new()
		_picker.file_mode = FileDialog.FILE_MODE_OPEN_FILE
		_picker.access = FileDialog.ACCESS_FILESYSTEM
		_picker.use_native_dialog = DisplayServer.has_feature(
			DisplayServer.FEATURE_NATIVE_DIALOG_FILE)
		_picker.size = Vector2i(int(UiKit.s(560.0)), int(UiKit.s(520.0)))
		_picker.show_hidden_files = false
		_picker.title = UiKit.label_for("Import image", "استيراد صورة")
		_picker.filters = PackedStringArray([
			"*.png, *.jpg, *.jpeg, *.webp, *.bmp, *.tga, *.svg, *.ktx ; Images",
			"*.png ; PNG", "*.jpg, *.jpeg ; JPEG", "*.webp ; WebP",
			"*.bmp ; BMP", "*.tga ; TGA", "*.svg ; SVG",
		])
		_picker.file_selected.connect(_place_image)
		_ui.add_child(_picker)
	# Where it was left last time, else the camera roll, else downloads.
	# Hunting for the same folder on every import is the whole friction.
	var start: String = _last_import_dir
	if start == "" or not DirAccess.dir_exists_absolute(start):
		start = OS.get_system_dir(OS.SYSTEM_DIR_PICTURES)
	if start == "" or not DirAccess.dir_exists_absolute(start):
		start = OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)
	if start != "" and DirAccess.dir_exists_absolute(start):
		_picker.current_dir = start
	_picker.popup_centered_ratio(0.9)

func _place_image(path: String) -> void:
	_last_import_dir = path.get_base_dir()
	var img: Image = Image.new()
	if img.load(path) != OK:
		_flash(UiKit.label_for("That file could not be read",
			"تعذّرت قراءة هذا الملف"))
		return
	if img.get_format() != Image.FORMAT_RGBA8:
		img.convert(Image.FORMAT_RGBA8)

	var p: ProjectManager.Project = current_project()
	if p == null:
		return
	# Sized to sit inside the page rather than dwarf it, keeping its shape.
	var room: Vector2 = p.page * 0.92
	var factor: float = minf(room.x / maxf(float(img.get_width()), 1.0),
		room.y / maxf(float(img.get_height()), 1.0))
	if factor < 0.999:
		img.resize(maxi(int(float(img.get_width()) * factor), 1),
			maxi(int(float(img.get_height()) * factor), 1),
			Image.INTERPOLATE_LANCZOS)

	# The canvas stores premultiplied pixels; an imported file does not.
	_premultiply(img)

	var stack: LayerStack = p.stack
	var index: int = clampi(_import_into, 0, maxi(stack.layers.size() - 1, 0))
	stack.set_active(index)

	# Centred on the page being looked at, and floating: a picture almost
	# never lands where it is finally wanted, so it arrives as something
	# still movable rather than as a decision already made.
	# Page-local: the floating piece lands in the middle of the page being
	# worked on, whichever page that is.
	view.float_image(img, stack.layers[index].id, p.page * 0.5)
	view.projects.mark_dirty(p)
	_close_panel()
	_flash(UiKit.label_for("Drag it, then Place", "حرّكها ثم ثبّت"))

static func _premultiply(img: Image) -> void:
	var w: int = img.get_width()
	var h: int = img.get_height()
	var d: PackedByteArray = img.get_data()
	for i in range(w * h):
		var o: int = i * 4
		var a: int = d[o + 3]
		if a == 255:
			continue
		if a == 0:
			d[o] = 0
			d[o + 1] = 0
			d[o + 2] = 0
			continue
		d[o] = int(float(d[o]) * float(a) / 255.0)
		d[o + 1] = int(float(d[o + 1]) * float(a) / 255.0)
		d[o + 2] = int(float(d[o + 2]) * float(a) / 255.0)
	img.set_data(w, h, false, Image.FORMAT_RGBA8, d)

func show_project_menu(p: ProjectManager.Project) -> void:
	_show_project_options(p)

## Clears the disk and the workspace together, so nothing can come back.
## Empties everything an open project is holding: the undo history of every
## page, every frame kept in memory, and the tiles the graphics card is
## sitting on. The old clear only reached the history, which is why memory
## came back a moment later.
func free_memory() -> void:
	var p: ProjectManager.Project = current_project()
	if p == null:
		return
	var freed: int = 0
	for page in p.sheets:
		var one: ProjectManager.Page = page
		one.history.clear()
		for l in one.stack.layers:
			freed += l.cels.bytes()
			l.surface.settle()
			l.surface.sleep_all()
	_flash("%s  %.1f MB" % [UiKit.label_for("Freed", "حُرِّر"),
		float(freed) / 1048576.0])

func forget_everything() -> void:
	for p in view.projects.projects.duplicate():
		view.projects.remove(p)
	Vault.forget_all()
	_close_panel()
	_flash(UiKit.label_for("Forget everything saved", "انسَ كل ما هو محفوظ"))

## Touching the strip above a project asks one question and no others: what
## colour should its frame be. A menu of everything was in the way of the
## one thing anyone reaches for there.
func _show_frame_colour(p: ProjectManager.Project) -> void:
	_options_for = p
	_close_panel()
	_mount(SettingsPanels.frame_colour_for(self, p), "settings")

func _show_project_options(p: ProjectManager.Project) -> void:
	_options_for = p
	_close_panel()
	_mount(SettingsPanels.project_options(self, p), "settings")

## Language changes reach into panels that are already on screen, so the
## simplest correct answer is to build them again.
func _rebuild_chrome() -> void:
	view.chrome.refresh(view.view_zoom)

# ------------------------------------------------------------------ export

func share_project() -> void:
	run_export("png")
	var folder: String = ProjectSettings.globalize_path(Exporters.out_dir())
	DisplayServer.clipboard_set(folder)
	OS.shell_open(folder)

# --------------------------------------------------------------- shortcuts

func _unhandled_key_input(event: InputEvent) -> void:
	if not (event is InputEventKey):
		return
	var k: InputEventKey = event as InputEventKey
	if not k.pressed or k.echo:
		return
	if k.ctrl_pressed and k.keycode == KEY_Z:
		if k.shift_pressed:
			view.redo()
		else:
			view.undo()
		get_viewport().set_input_as_handled()
	elif k.ctrl_pressed and k.keycode == KEY_C:
		view.copy_selection()
	elif k.ctrl_pressed and k.keycode == KEY_V:
		view.paste_clipboard()
	elif k.keycode == KEY_B:
		App.set_tool(App.Tool.BRUSH)
	elif k.keycode == KEY_E:
		App.set_tool(App.Tool.ERASER)
	elif k.keycode == KEY_G:
		App.set_tool(App.Tool.FILL)
	elif k.keycode == KEY_S:
		App.set_tool(App.Tool.SELECT)
	elif k.keycode == KEY_ESCAPE:
		if view.sel_active:
			view.cancel_selection()
		else:
			view.clear_marks()
	elif k.keycode == KEY_0:
		view.reset_view()
