class_name CanvasView
extends Control
## The view transform, the touch handling, the stroke engine, the selection
## and the undo history — everything that happens on the canvas itself.
##
## Gestures follow the drawing-app convention:
##   one finger        -> draw
##   two fingers       -> pan and pinch zoom
##   two-finger tap    -> undo
##   three-finger tap  -> redo
## A tap only counts as a tap if it is short and barely moves, so panning
## never triggers an undo by accident.

signal view_changed(zoom: float)
signal history_changed()
signal action_taken(label: String, undone: bool)
## A plain word to the user about what just happened — not an undoable
## action, so it is kept apart from `action_taken`, which is read as history.
signal notice(text: String)
signal puppet_changed()
signal text_restyle_needed(layer_id: int)
signal project_changed()
signal camera_framed(shot: Rect2)
signal project_menu_requested(project: Variant)
signal project_focused(project: Variant)
## Raised when the strip above a project is touched. Its only job now is the
## frame colour, so it says so rather than opening a menu of everything.
signal frame_colour_requested(project: Variant)
signal pointer_moved(world_pos: Vector2)
signal selection_changed()
signal symmetry_mode_changed(enabled: bool)

const MIN_ZOOM: float = 0.02
const MAX_ZOOM: float = 64.0
## Replaced by StrokeSmoother, which varies with speed instead.
const MAX_UNDO: int = 24
const TAP_MS: int = 320
const TAP_SLOP: float = 26.0
const MOVE_START: float = 10.0
const LASSO_STEP: float = 4.0
const HANDLE_HIT: float = 26.0
const MAX_LIFT: int = 2048           # biggest selection we will carry around

enum Grab { NONE, MOVE, SCALE, ROTATE }

var world: Node2D
var projects: ProjectManager
var chrome: ProjectChrome
var player: AnimPlayer
var layers: LayerStack          # the open project's stack, or null
var overlay: Node2D
var grid: GridBackground

## Nothing may be drawn until a project is open. The grid is a workspace,
## not a canvas.
var _project_drag: Variant = null
var _project_grab: Vector2 = Vector2.ZERO
var _tap_ms: int = 0
var _tap_at: Vector2 = Vector2.ZERO
var _opened_ms: int = 0
var _opened: Variant = null

## Moving a sheet around the workspace is a press that is held, then
## dragged — the way a tile is moved on a home screen. Nothing in a menu
## turns it on, and nothing has to be turned off afterwards. A finger that
## starts moving before the hold is complete is doing something else, so
## the candidate is dropped rather than dragged.
const HOLD_TO_DRAG_MS: int = 300
const HOLD_SLOP: float = 14.0
var _hold_project: Variant = null
var _hold_from: Vector2 = Vector2.ZERO
var _hold_screen: Vector2 = Vector2.ZERO
var _hold_ms: int = 0
var _strip_project: Variant = null
var _strip_ms: int = 0
var _strip_at: Vector2 = Vector2.ZERO
var _touch_is_browser: bool = false
var view_offset: Vector2 = Vector2.ZERO
var view_zoom: float = 1.0
## Rotating the whole workspace would make the grid and every other project
## lean over with it, so the turn is only offered where it means something:
## inside focus, on one sheet, the way a hand turns paper on a desk.
var view_angle: float = 0.0
const ROTATE_SNAP: float = 0.06    # how near upright counts as upright

# --- touch bookkeeping ---
var _touches: Dictionary = {}
var _draw_finger: int = -1
var _gesture_active: bool = false
var _g_moving: bool = false
var _g_max_fingers: int = 0
var _g_start_ms: int = 0
var _g_travel: float = 0.0
var _g_last_mid: Vector2 = Vector2.ZERO
var _g_last_dist: float = 0.0
var _g_last_angle: float = 0.0
var _gesture_took_over: bool = false

## Direct camera framing. Drag inside the frame to move the shot, drag a
## corner to widen or tighten it — the whole gesture set, and no numbers.
var camera_edit: bool = false

## Bending a layer by pinning it. It owns the canvas while it is on: the
## drawing it is holding has been taken off the layer, so a brush stroke
## during a warp would land on a layer that is momentarily empty.
var puppet: PuppetWarp = null
var puppet_active: bool = false
var _puppet_pin: int = -1
var _puppet_layer: int = -1
var _puppet_snap: Dictionary = {}
var _puppet_tap_ms: int = 0
var _puppet_tap_pin: int = -1
var _puppet_hold_ms: int = 0
var _puppet_hold_at: Vector2 = Vector2.ZERO

var symmetry_enabled: bool = false
var symmetry_count: int = 2
var symmetry_angle: float = 0.0
var symmetry_center: Vector2 = Vector2.ZERO
var symmetry_center_uv: Vector2 = Vector2(0.5, 0.5)
var _symmetry_drag: int = 0 # 0 none, 1 centre, 2 rotation handle
var _camera_angle: float = 0.0
var _camera_grab: int = -1        # -1 none, 0 body, 1..4 corners
var _camera_from: Rect2 = Rect2()
var _camera_at: Vector2 = Vector2.ZERO

var _has_touch: bool = false

# --- stroke state ---
var _drawing: bool = false
var _smoother: StrokeSmoother = StrokeSmoother.new()
var _last_stamp: Vector2 = Vector2.ZERO
var _leftover: float = 0.0
var _last_dir: float = 0.0
var _speed: float = 0.0
var _pressure: float = 1.0

# --- shape state ---
var _shape_active: bool = false
var _shape_a: Vector2 = Vector2.ZERO
var _shape_b: Vector2 = Vector2.ZERO
var poly_points: PackedVector2Array = PackedVector2Array()

## Where the last tangled line finished, and whether there is one.
##
## Tangled lines are straight lines that arrive already joined. Only the first
## is drawn freely — from then on each new line starts exactly where the last
## one ended, so the hand places one point instead of two and the joins are
## exact rather than nearly exact.
##
## This is why it is not the curve tool wearing a different name. The curve
## gathers points and commits one smoothed run at the end; a chain commits
## each straight segment the moment it is drawn, so what is on the canvas is
## always what you have made so far, and stopping is simply not drawing the
## next one.
var chain_anchor: Vector2 = Vector2.ZERO
var chain_live: bool = false
var _poly_drag: int = -1

# --- selection ---
var _marking: bool = false
var _mark_points: PackedVector2Array = PackedVector2Array()
var sel_active: bool = false
var _sel_tex: ImageTexture = null
var _sel_sprite: Sprite2D = null
var _sel_size: Vector2 = Vector2.ZERO
var _sel_center: Vector2 = Vector2.ZERO
var _sel_rot: float = 0.0
var _sel_scale: float = 1.0
var _sel_layer: int = -1
var _sel_snapshot: Dictionary = {}
var _grab: int = Grab.NONE
var _grab_start: Vector2 = Vector2.ZERO
var _grab_ref: float = 0.0
var _grab_scale: float = 1.0
var _grab_rot: float = 0.0
var _grab_centre: Vector2 = Vector2.ZERO

# --- eyedropper ---
var _loupe: Control = null
var _picking: bool = false
var _pick_screen: Vector2 = Vector2.ZERO
var _pick_color: Color = Color.WHITE
var _pick_tex: ImageTexture = null

# --- history ---
var history: History = null
var _stroke_snap: Dictionary = {}
var _stroke_layer: int = -1
var _eraser_cache: Dictionary = {}
var _settle_in: int = 0

## The app has two speeds. Drawing gets every frame the screen can show;
## a workspace being looked at gets a fraction of that. A drawing program
## sits idle most of the time it is open, and rendering an unchanged picture
## sixty times a second is pure heat and battery for no visible gain.
## Matched to the panel rather than uncapped. Drawing frames the screen
## will never show is heat and battery spent on nothing, and on a phone that
## is felt within a minute.
static var BUSY_FPS: int = 60
const IDLE_FPS: int = 12
const IDLE_AFTER: float = 1.1  # seconds of quiet before easing off
var _busy_for: float = 0.0
var _view_moved: bool = true

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	clip_contents = true

	# A tangled chain belongs to the run of lines being drawn right now.
	# Reaching for the brush, the eraser or the selection ends that run —
	# so coming back to the tool later starts a fresh line rather than
	# springing one out of a corner nobody remembers choosing.
	App.tool_changed.connect(func(_t: int) -> void: break_chain())

	grid = GridBackground.new()
	grid.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(grid)

	world = Node2D.new()
	world.name = "World"
	add_child(world)

	projects = ProjectManager.new()
	projects.name = "Projects"
	world.add_child(projects)
	projects.active_changed.connect(_bind_project)
	projects.projects_changed.connect(func() -> void:
		if chrome != null:
			chrome.refresh(view_zoom)
		_refresh_hint())

	chrome = ProjectChrome.new()
	chrome.name = "Chrome"
	chrome.manager = projects
	world.add_child(chrome)

	player = AnimPlayer.new()
	player.name = "Player"
	player.camera_moved.connect(_follow_camera)
	set_process(true)
	add_child(player)

	# Lifted pixels are premultiplied like everything else on the canvas, so
	# they need a node that blends that way. Drawing them inside the overlay
	# would force the frame and handles to blend the same way too.
	_sel_sprite = Sprite2D.new()
	_sel_sprite.name = "Floating"
	_sel_sprite.centered = false
	_sel_sprite.visible = false
	_sel_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	_sel_sprite.material = PaintSurface.premultiplied_material()

	overlay = Node2D.new()
	overlay.name = "Overlay"
	overlay.draw.connect(_draw_overlay)
	world.add_child(overlay)
	# Both live under the overlay, which is shifted to the open project, so
	# marks and lifted pixels share one space with the layers they came from.
	overlay.add_child(_sel_sprite)

	# In the overlay, so it shares the open page's coordinate space with the
	# layers it is bending — pins are page positions, not screen ones.
	puppet = PuppetWarp.new()
	puppet.name = "PuppetWarp"
	overlay.add_child(puppet)

	# Above the page, inside the overlay, so it shares the page's coordinate
	# space and no exporter ever sees it.
	# Merging and duplicating queue work on the GPU; this makes sure it gets
	# folded back into the layer a couple of frames later.

	_loupe = Control.new()
	_loupe.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_loupe.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_loupe.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_loupe.draw.connect(_draw_loupe)
	add_child(_loupe)

	_ready_pace()
	resized.connect(_apply_view)
	_apply_view()

func _process(dt: float) -> void:
	_tick_hold()
	_tick_puppet_hold()
	Perf.tick(dt)
	_sync_floating()
	# Tile housekeeping only has something to say when the view has moved,
	# and never while a stroke is in flight: the hand is the one thing that
	# must not wait on bookkeeping.
	if _view_moved and not _drawing:
		_view_moved = false
		projects.update_view(view_world_rect(), view_zoom)
	if layers != null:
		layers.flush_all()
		if _settle_in > 0:
			_settle_in -= 1
			if _settle_in == 0:
				layers.settle_all()
	_tick_pace(dt)

## Anything the user does resets the clock; a stretch of quiet lets it run.
func mark_busy() -> void:
	_busy_for = IDLE_AFTER
	if Engine.max_fps != BUSY_FPS:
		Engine.max_fps = BUSY_FPS

func _ready_pace() -> void:
	var hz: float = DisplayServer.screen_get_refresh_rate()
	if hz > 20.0:
		BUSY_FPS = int(round(hz))
	# Applied straight away: leaving it uncapped until the first touch let
	# the opening seconds run as fast as the hardware could manage, which
	# is the one moment a phone has nothing to show for the heat.
	Engine.max_fps = BUSY_FPS

func _tick_pace(dt: float) -> void:
	# Playback is an active interaction even when the user is not touching
	# the screen. Never let the idle battery saver drop animation playback to
	# 8/12 FPS after a second of silence.
	if player != null and player.playing:
		_busy_for = IDLE_AFTER
		if Engine.max_fps != BUSY_FPS:
			Engine.max_fps = BUSY_FPS
		return
	if _drawing:
		_busy_for = IDLE_AFTER
		if Engine.max_fps != BUSY_FPS:
			Engine.max_fps = BUSY_FPS
		return
	if _busy_for <= 0.0:
		return
	_busy_for -= dt
	if _busy_for <= 0.0 and Engine.max_fps != Perf.idle_fps():
		Engine.max_fps = Perf.idle_fps()

func _refresh_hint() -> void:
	if grid == null:
		return
	var text: String = ""
	if projects.projects.is_empty():
		text = UiKit.label_for("Settings, then New project",
			"الإعدادات، ثم مشروع جديد")
	if text != grid.empty_hint:
		grid.empty_hint = text
		grid.queue_redraw()

func active_surface() -> PaintSurface:
	if layers == null:
		return null
	return layers.active_surface()

func has_project() -> bool:
	return layers != null

## Swapping projects swaps the undo stack with them, because a history that
## reached across projects could undo a stroke into a document the user is
## no longer looking at.
func _bind_project(p: Variant) -> void:
	_drop_hold()
	if puppet_active:
		end_puppet_warp(false)
	if history != null:
		if history.changed.is_connected(_on_history_changed):
			history.changed.disconnect(_on_history_changed)
		if history.acted.is_connected(_on_history_acted):
			history.acted.disconnect(_on_history_acted)
	cancel_selection()
	clear_marks()
	if p == null:
		layers = null
		history = null
		if player != null:
			player.bind(null, null)
	else:
		layers = p.stack
		history = p.history
		if player != null:
			player.bind(p.clip, p.stack)
			player.onion = p.onion_skin
			player.onion_back = p.onion_back
			player.onion_forward = p.onion_forward
			player.onion_back_tint = p.onion_back_tint
			player.onion_highlight_tint = p.onion_highlight
			player.onion_forward_tint = p.onion_forward_tint
			player.looping = p.looping
		history.changed.connect(_on_history_changed)
		history.acted.connect(_on_history_acted)
	if chrome != null:
		chrome.refresh(view_zoom)
	if symmetry_enabled:
		_sync_symmetry_from_uv()
	if overlay != null:
		overlay.position = canvas_origin()
		overlay.queue_redraw()
	history_changed.emit()
	project_changed.emit()

func _on_active_layer(_index: int) -> void:
	# Layer selection is consumed by the UI; keeping the hook makes the signal
	# safe even when no additional canvas work is required.
	pass

func _on_history_changed() -> void:
	projects.mark_dirty(projects.active)
	history_changed.emit()

func _on_history_acted(label: String, undone: bool) -> void:
	action_taken.emit(label, undone)

func _sync_floating() -> void:
	if _sel_sprite == null:
		return
	_sel_sprite.visible = sel_active and _sel_tex != null
	if not _sel_sprite.visible:
		return
	_sel_sprite.texture = _sel_tex
	_sel_sprite.transform = selection_transform()

# ------------------------------------------------------------ view helpers

func screen_to_world(s: Vector2) -> Vector2:
	return (s - view_offset).rotated(-view_angle) / view_zoom

func world_to_screen(w: Vector2) -> Vector2:
	return (w * view_zoom).rotated(view_angle) + view_offset

func can_rotate() -> bool:
	return projects.focus_on != null

## Where the open project sits on the grid. Layers live inside that node, so
## a stroke handed world coordinates would land exactly this far from the
## finger — which is precisely what it did.
## Layers now live inside a page, and a page inside a project. Anything
## that touches pixels has to be measured from the page's corner or it
## lands a page-width away from the finger.
## A keyed camera moves the view, not the drawing. Framed on the page being
## worked on so that zero means "the page as you framed it" rather than some
## corner of the endless grid.
func _follow_camera(offset: Vector2, zoom: float, turn: float = 0.0) -> void:
	var p: Variant = projects.active
	if p == null:
		return
	var page: Rect2 = p.page_rect(p.active_page)

	# What the camera keeps: the page shrunk by the zoom and slid by the
	# offset. Marked on the workspace so the shot can be composed while the
	# rest of the drawing stays visible around it.
	var span: Vector2 = page.size / maxf(zoom, 0.05)
	var look: Vector2 = page.get_center() + offset
	if chrome != null:
		chrome.camera_on = true
		chrome.camera_rect = Rect2(look - span * 0.5, span)
		# `rotation` here used to read the control's own rotation rather
		# than the keyed angle handed in — so a camera key that turned the
		# shot played back without ever turning it.
		chrome.camera_angle = turn
		_camera_angle = turn
		view_angle = turn
		_apply_view()
		chrome.refresh(view_zoom)

func canvas_origin() -> Vector2:
	var p: Variant = projects.active
	if p == null:
		return Vector2.ZERO
	return p.origin + p.page_offset(p.active_page)

func screen_to_canvas(s: Vector2) -> Vector2:
	return screen_to_world(s) - canvas_origin()

func canvas_to_screen(p: Vector2) -> Vector2:
	return world_to_screen(p + canvas_origin())

## What the screen covers, in world coordinates. Built from the four
## corners rather than one corner plus a size, because once the view can be
## turned those two are no longer the same rectangle.
func view_world_rect() -> Rect2:
	var a: Vector2 = screen_to_world(Vector2.ZERO)
	var box: Rect2 = Rect2(a, Vector2.ZERO)
	box = box.expand(screen_to_world(Vector2(size.x, 0.0)))
	box = box.expand(screen_to_world(size))
	box = box.expand(screen_to_world(Vector2(0.0, size.y)))
	return box

func grid_step() -> float:
	if grid == null:
		return 1.0
	return grid.current_step()

func _apply_view() -> void:
	if puppet != null:
		puppet.zoom = view_zoom
		if puppet_active:
			puppet.queue_redraw()
	world.transform = Transform2D(view_angle, Vector2(view_zoom, view_zoom),
		0.0, view_offset)
	if grid != null:
		grid.set_view(view_offset, view_zoom, view_angle)
	if overlay != null:
		overlay.queue_redraw()
	if chrome != null:
		chrome.refresh(view_zoom)
	if overlay != null:
		overlay.position = canvas_origin()
	_view_moved = true
	mark_busy()
	view_changed.emit(view_zoom)

func zoom_at(screen_point: Vector2, factor: float) -> void:
	var target: float = clampf(view_zoom * factor, MIN_ZOOM, MAX_ZOOM)
	if is_equal_approx(target, view_zoom):
		return
	var before: Vector2 = screen_to_world(screen_point)
	view_zoom = target
	view_offset = screen_point - before * view_zoom
	_apply_view()

func pan(delta: Vector2) -> void:
	view_offset += delta
	_apply_view()

func reset_view() -> void:
	view_zoom = 1.0
	view_angle = 0.0
	view_offset = size * 0.5
	_apply_view()

## Move, pinch and turn are one motion of two fingers, so they are applied
## as one transform rather than three in a row.
##
## Doing them in sequence — pan, then zoom about a point, then rotate about
## a point — meant each step moved the pivot the next step was measured
## from, and the error came back as the shake. Here the whole change is
## expressed once: the view is scaled and turned about the midpoint the
## fingers held a moment ago, then carried by however far that midpoint
## travelled. Exact, and with nothing left to accumulate.
func _apply_gesture(mid: Vector2, dist: float, turn: float) -> void:
	var factor: float = 1.0
	if _g_last_dist > 4.0 and dist > 4.0:
		factor = dist / _g_last_dist
	var target: float = clampf(view_zoom * factor, MIN_ZOOM, MAX_ZOOM)
	factor = target / maxf(view_zoom, 0.00001)

	var spin: float = 0.0
	# Below this spread the angle between two fingers is mostly noise, and a
	# sheet would tremble while being pinched.
	if can_rotate() and dist > 70.0 * App.ui_scale:
		spin = wrapf(turn - _g_last_angle, -PI, PI)

	var pivot: Vector2 = _g_last_mid
	view_offset = ((view_offset - pivot) * factor).rotated(spin) + pivot \
		+ (mid - pivot)
	view_zoom = target
	view_angle = wrapf(view_angle + spin, -PI, PI)
	_apply_view()

## Turns the view about a screen point. Used by the buttons, not by the
## gesture, which has its own single-step path above.
func rotate_at(screen_point: Vector2, delta: float) -> void:
	if is_zero_approx(delta):
		return
	view_offset = ((view_offset - screen_point)).rotated(delta) + screen_point
	view_angle = wrapf(view_angle + delta, -PI, PI)
	_apply_view()

## Called when the fingers leave, never while they are down. Snapping during
## the turn would fight the hand for the last few degrees, which is the
## other half of what made rotation feel unsteady.
func _settle_angle() -> void:
	if is_zero_approx(view_angle):
		return
	var quarter: float = round(view_angle / (PI * 0.5)) * (PI * 0.5)
	if absf(view_angle - quarter) < ROTATE_SNAP:
		rotate_at(size * 0.5, quarter - view_angle)

func straighten() -> void:
	if is_zero_approx(view_angle):
		return
	rotate_at(size * 0.5, -view_angle)
	view_angle = 0.0
	_apply_view()

## Fits a project to the screen with a little air around it. Zoom and pan
## stay free afterwards — focus is about what is shown, not a cage.
func frame_project(p: Variant, margin: float = 0.90) -> void:
	if p == null or size.x < 8.0 or size.y < 8.0:
		return
	view_angle = 0.0
	var b: Rect2 = p.bounds().grow(ProjectManager.TITLE_LIFT)
	var fit: float = minf(size.x / maxf(b.size.x, 1.0), size.y / maxf(b.size.y, 1.0))
	view_zoom = clampf(fit * margin, MIN_ZOOM, MAX_ZOOM)
	view_offset = size * 0.5 - b.get_center() * view_zoom
	_apply_view()

## Moves the view to one page of a comic without changing the zoom.
func frame_page(p: Variant, index: int) -> void:
	if p == null:
		return
	var r: Rect2 = p.page_rect(clampi(index, 0, p.pages - 1))
	view_offset = size * 0.5 - r.get_center() * view_zoom
	_apply_view()

# ------------------------------------------------------------------ input

func _gui_input(event: InputEvent) -> void:
	mark_busy()
	if event is InputEventScreenTouch:
		_handle_touch(event as InputEventScreenTouch)
		accept_event()
	elif event is InputEventScreenDrag:
		_handle_drag(event as InputEventScreenDrag)
		accept_event()
	elif event is InputEventMouseMotion:
		if _has_touch:
			return
		var mm: InputEventMouseMotion = event as InputEventMouseMotion
		pointer_moved.emit(screen_to_canvas(mm.position))
		if (mm.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
			_move_input(mm.position, mm.relative.length(), 1.0)
			accept_event()
	elif event is InputEventMouseButton:
		if _has_touch:
			return
		var mb: InputEventMouseButton = event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_begin_input(mb.position)
			else:
				_end_input(mb.position)
			accept_event()
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			zoom_at(mb.position, 1.12)
			accept_event()
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			zoom_at(mb.position, 1.0 / 1.12)
			accept_event()

func _handle_touch(e: InputEventScreenTouch) -> void:
	_has_touch = true
	App.touch_mode = true
	if e.pressed:
		_touches[e.index] = e.position
		pointer_moved.emit(screen_to_canvas(e.position))
		var count: int = _touches.size()
		if count == 1:
			_draw_finger = e.index
			_begin_input(e.position)
		elif count >= 2:
			# A second finger is an explicit mode switch.  Drawing and camera
			# gestures must never share the same stroke: ending the stroke at
			# the moment finger two lands prevents the classic Android
			# "spike" that appears when pinch/rotate begins on a live brush.
			if _drawing or _draw_finger != -1:
				_cancel_input()
				_draw_finger = -1
			if not _gesture_active:
				_start_gesture()
		_g_max_fingers = maxi(_g_max_fingers, count)
	else:
		_touches.erase(e.index)
		if _gesture_active:
			if _touches.is_empty():
				_finish_gesture()
		elif e.index == _draw_finger:
			_end_input(e.position)
			_draw_finger = -1
		if _touches.is_empty():
			_gesture_active = false
			_g_moving = false
			_draw_finger = -1

func _handle_drag(e: InputEventScreenDrag) -> void:
	_touches[e.index] = e.position
	if _gesture_active:
		if _touches.size() < 2:
			# A release that never arrived would otherwise leave the view
			# frozen for good; treat the gesture as over and carry on.
			_gesture_active = false
			_g_moving = false
			_gesture_took_over = false
			return
		_g_travel += e.relative.length()
		var mid: Vector2 = _mid()
		var dist: float = _spread()
		var turn: float = _twist()
		if not _g_moving and _g_travel > MOVE_START * App.ui_scale:
			_g_moving = true
			_g_last_mid = mid
			_g_last_dist = dist
			_g_last_angle = turn
		if _g_moving:
			if not _gesture_took_over:
				_gesture_took_over = true
				_cancel_input()
			_apply_gesture(mid, dist, turn)
			_g_last_mid = mid
			_g_last_dist = dist
			_g_last_angle = turn
		return
	# After a multi-touch gesture the remaining finger is not allowed to
	# become a brush stroke mid-gesture.  A fresh touch-down is required.
	if e.index != _draw_finger or _gesture_active:
		return
	pointer_moved.emit(screen_to_canvas(e.position))
	var p: float = 1.0
	if App.pressure_enabled and e.pressure > 0.0:
		p = clampf(e.pressure, 0.05, 1.0)
	_move_input(e.position, e.relative.length(), p)

func _start_gesture() -> void:
	_gesture_active = true
	_gesture_took_over = false
	_g_moving = false
	_g_travel = 0.0
	_g_start_ms = Time.get_ticks_msec()
	_g_last_mid = _mid()
	_g_last_dist = _spread()
	_g_last_angle = _twist()

func _finish_gesture() -> void:
	var duration: int = Time.get_ticks_msec() - _g_start_ms
	var quiet: bool = _g_travel <= TAP_SLOP * App.ui_scale
	var tapped: bool = duration <= TAP_MS and quiet and not _g_moving

	if tapped:
		# The first finger of a tap has already put a dot down. Undoing on
		# top of that left one step taken back and a fresh one added in the
		# same breath — which is why repeated taps went nowhere. The dot is
		# rolled back first, so a tap is only ever a tap.
		_cancel_input()
		if _g_max_fingers == 2:
			undo()
		elif _g_max_fingers >= 3:
			redo()
	elif _g_moving:
		_settle_angle()
	elif _drawing:
		# Fingers came and went without navigating: the stroke was only
		# paused, so it is finished properly rather than lost.
		_end_stroke(_last_stamp)

	_gesture_active = false
	_gesture_took_over = false
	_g_moving = false
	_g_max_fingers = 0
	_draw_finger = -1

func _mid() -> Vector2:
	var keys: Array = _touches.keys()
	if keys.size() < 2:
		return Vector2.ZERO
	var a: Vector2 = _touches[keys[0]]
	var b: Vector2 = _touches[keys[1]]
	return (a + b) * 0.5

## The angle of the line between two fingers, which is what turning a sheet
## of paper actually changes.
func _twist() -> float:
	var keys: Array = _touches.keys()
	if keys.size() < 2:
		return 0.0
	var a: Vector2 = _touches[keys[0]]
	var b: Vector2 = _touches[keys[1]]
	return (b - a).angle()

func _spread() -> float:
	var keys: Array = _touches.keys()
	if keys.size() < 2:
		return 0.0
	var a: Vector2 = _touches[keys[0]]
	var b: Vector2 = _touches[keys[1]]
	return a.distance_to(b)


func set_camera_edit(enabled: bool) -> void:
	camera_edit = enabled
	_camera_grab = -1
	if chrome == null:
		return

	chrome.camera_editing = enabled
	if enabled:
		var p: Variant = projects.active if projects != null else null
		if p == null:
			chrome.camera_on = false
			chrome.queue_redraw()
			return
		var page: Rect2 = p.bounds()
		if not chrome.camera_on or chrome.camera_rect.size.x <= 1.0 or chrome.camera_rect.size.y <= 1.0:
			chrome.camera_rect = page
		chrome.camera_on = true
	chrome.refresh(view_zoom)

func set_lateral_symmetry(enabled: bool) -> void:
	symmetry_enabled = enabled
	_symmetry_drag = 0
	if projects != null and projects.active != null:
		if enabled:
			_sync_symmetry_from_uv()
		else:
			_symmetry_drag = 0
	overlay.queue_redraw()
	symmetry_mode_changed.emit(symmetry_enabled)

func cancel_lateral_symmetry() -> void:
	set_lateral_symmetry(false)

func _sync_symmetry_from_uv() -> void:
	if projects == null or projects.active == null:
		return
	var page: Vector2 = projects.active.page
	if page.x <= 0.0 or page.y <= 0.0:
		return
	symmetry_center = Vector2(clampf(symmetry_center_uv.x, 0.0, 1.0) * page.x,
		clampf(symmetry_center_uv.y, 0.0, 1.0) * page.y)

func set_symmetry_count(count: int) -> void:
	symmetry_count = clampi(count, 2, 12)
	overlay.queue_redraw()

func set_symmetry_angle(angle: float) -> void:
	symmetry_angle = angle
	overlay.queue_redraw()

func camera_values() -> Dictionary:
	if chrome == null or projects == null:
		return {}
	var p: Variant = projects.active
	if p == null or not chrome.camera_on or chrome.camera_rect.size.x <= 1.0:
		return {}
	var page: Rect2 = p.bounds()
	var shot: Rect2 = chrome.camera_rect
	var zoom: float = page.size.x / maxf(shot.size.x, 1.0)
	return {
		"x": shot.get_center().x - page.get_center().x,
		"y": shot.get_center().y - page.get_center().y,
		"zoom": maxf(zoom, 0.05),
		"rotation": _camera_angle,
	}

func _camera_world_from_canvas(w: Vector2) -> Vector2:
	return w + canvas_origin()

func _begin_symmetry(_w: Vector2, screen: Vector2) -> bool:
	var c: Vector2 = symmetry_center
	var handle_canvas: Vector2 = c + Vector2(cos(symmetry_angle), sin(symmetry_angle)) * 70.0
	var center_screen: Vector2 = canvas_to_screen(c)
	var handle_screen: Vector2 = canvas_to_screen(handle_canvas)
	var r: float = maxf(24.0, 26.0 * App.ui_scale)
	if screen.distance_squared_to(handle_screen) <= r * r:
		_symmetry_drag = 2
		return true
	if screen.distance_squared_to(center_screen) <= r * r:
		_symmetry_drag = 1
		return true
	return false

func _move_symmetry(w: Vector2) -> void:
	if _symmetry_drag == 1:
		if projects != null and projects.active != null:
			var page: Vector2 = projects.active.page
			if page.x > 0.0 and page.y > 0.0:
				w.x = clampf(w.x, 0.0, page.x)
				w.y = clampf(w.y, 0.0, page.y)
				symmetry_center = w
				symmetry_center_uv = Vector2(w.x / page.x, w.y / page.y)
		else:
			symmetry_center = w
	elif _symmetry_drag == 2:
		var delta: Vector2 = w - symmetry_center
		if delta.length_squared() > 0.0001:
			symmetry_angle = delta.angle()
	overlay.queue_redraw()

func _begin_camera(w: Vector2) -> bool:
	if chrome == null or projects == null or projects.active == null:
		return false
	if not chrome.camera_on or chrome.camera_rect.size.x <= 1.0 or chrome.camera_rect.size.y <= 1.0:
		return false

	var world_pos: Vector2 = _camera_world_from_canvas(w)
	var shot: Rect2 = chrome.camera_rect
	var hit: float = maxf(24.0 / maxf(view_zoom, 0.0001), 6.0)
	var centre: Vector2 = shot.get_center()
	var ux: Vector2 = Vector2(cos(_camera_angle), sin(_camera_angle))
	var uy: Vector2 = Vector2(-sin(_camera_angle), cos(_camera_angle))
	var hx: Vector2 = ux * shot.size.x * 0.5
	var hy: Vector2 = uy * shot.size.y * 0.5
	var corners: Array[Vector2] = [centre - hx - hy, centre + hx - hy, centre + hx + hy, centre - hx + hy]
	var rotate_handle: Vector2 = centre - uy * maxf(32.0, shot.size.y * 0.12)
	if world_pos.distance_squared_to(rotate_handle) <= hit * hit:
		_camera_grab = 5
		_camera_at = world_pos
		return true
	for i in range(corners.size()):
		if world_pos.distance_squared_to(corners[i]) <= hit * hit:
			_camera_grab = i + 1
			_camera_from = shot
			_camera_at = world_pos
			return true

	var local_hit: Vector2 = (world_pos - centre).rotated(-_camera_angle) + shot.size * 0.5
	if Rect2(Vector2.ZERO, shot.size).grow(hit).has_point(local_hit):
		_camera_grab = 0
		_camera_from = shot
		_camera_at = world_pos
		return true

	return false

func _move_camera(w: Vector2) -> void:
	if _camera_grab < 0 or chrome == null:
		return

	var world_pos: Vector2 = _camera_world_from_canvas(w)
	var delta: Vector2 = world_pos - _camera_at
	var start: Rect2 = _camera_from
	var shot: Rect2 = start
	var min_side: float = 32.0

	if _camera_grab == 5:
		_camera_angle = (world_pos - start.get_center()).angle() + PI * 0.5
		chrome.camera_angle = _camera_angle
		chrome.refresh(view_zoom)
		overlay.queue_redraw()
		return

	if _camera_grab == 0:
		shot.position = start.position + delta
	else:
		var local: Vector2 = (world_pos - start.get_center()).rotated(-_camera_angle)
		var half: Vector2 = start.size * 0.5
		var opposite: Vector2 = Vector2.ZERO
		match _camera_grab:
			1: opposite = Vector2(half.x, half.y)
			2: opposite = Vector2(-half.x, half.y)
			3: opposite = Vector2(-half.x, -half.y)
			4: opposite = Vector2(half.x, -half.y)
		var left: float = minf(local.x, opposite.x)
		var right: float = maxf(local.x, opposite.x)
		var top: float = minf(local.y, opposite.y)
		var bottom: float = maxf(local.y, opposite.y)
		var shot_w: float = maxf(right - left, min_side)
		var shot_h: float = maxf(bottom - top, min_side)
		var local_center: Vector2 = Vector2((left + right) * 0.5, (top + bottom) * 0.5)
		var new_center: Vector2 = start.get_center() + local_center.rotated(_camera_angle)
		shot = Rect2(new_center - Vector2(shot_w, shot_h) * 0.5, Vector2(shot_w, shot_h))

	chrome.camera_rect = shot
	chrome.camera_on = true
	chrome.refresh(view_zoom)
	overlay.queue_redraw()

# ------------------------------------------------------------ tool routing

## Projects come first: a sheet still being placed, or one that is closed,
## owns the touch entirely. Only once a project is open does the finger mean
## a brush.
func _begin_input(screen: Vector2) -> void:
	_touch_is_browser = false
	if _handle_project_touch(screen, screen_to_world(screen)):
		# The browser answered. Nothing that follows this press is a tool,
		# so the rest of the gesture is kept away from the canvas entirely
		# — a fill or a shape must not go off when the finger lifts.
		_touch_is_browser = true
		return
	if layers == null:
		return
	var w: Vector2 = screen_to_canvas(screen)

	# A warp owns the canvas outright while it is on. Nothing below this
	# line can run, because the layer it would draw on is empty until the
	# warp is put down.
	if puppet_active:
		_begin_puppet(w, screen)
		return

	if text_box_layer >= 0 and _begin_text_box(w):
		_touch_is_browser = false
		return

	# Symmetry controls: the centre dot moves the axis, the second dot rotates it.
	if symmetry_enabled and _begin_symmetry(w, screen):
		return

	# The camera frame, while it is being composed.
	if camera_edit and _begin_camera(w):
		return

	# A floating selection owns the canvas until it is placed.
	if sel_active:
		var g: int = _hit_handle(screen)
		if g != Grab.NONE:
			_start_grab(g, screen)
			return
		commit_selection()
		if App.current_tool == App.Tool.SELECT:
			return

	if App.current_tool == App.Tool.SELECT:
		_begin_mark(w)
		return
	if App.current_tool == App.Tool.PICK:
		_picking = true
		_update_pick(screen)
		return
	if App.current_tool == App.Tool.FILL:
		if App.fill_shape != App.FillShape.FLOOD:
			_shape_active = true
			_shape_a = w
			_shape_b = w
			overlay.queue_redraw()
		return
	if layers == null or not layers.can_draw():
		return

	# What happens next is decided by the tool in the hand, not by a setting
	# left behind in another one. Straight lines and boxes belong to Shapes;
	# reading `shape_mode` here meant that drawing one rectangle turned the
	# brush into a rectangle tool for the rest of the session — the brush
	# was still working, it had simply stopped being a brush.
	if App.current_tool == App.Tool.SHAPE and App.shape_mode != App.Shape.FREE:
		_begin_shape(w)
	else:
		_begin_stroke(w)

func _move_input(screen: Vector2, screen_delta: float, pressure: float) -> void:
	if _strip_project != null and _strip_ms != 0 \
			and _strip_at.distance_to(screen) > HOLD_SLOP * App.ui_scale:
		_strip_project = null
		_strip_ms = 0
	if _hold_project != null and _project_drag == null:
		# A finger that sets off before the hold is finished was never
		# asking to move the sheet.
		if _hold_screen.distance_to(screen) > HOLD_SLOP * App.ui_scale:
			_drop_hold()
	if _project_drag != null:
		var moved: Vector2 = screen_to_world(screen)
		projects.move_to(_project_drag, moved - _project_grab)
		if chrome != null:
			chrome.refresh(view_zoom)
		return
	if _touch_is_browser:
		return
	var w: Vector2 = screen_to_canvas(screen)
	if text_box_layer >= 0 and _text_grab >= 0:
		_move_text_box(w)
		return
	if puppet_active:
		if _puppet_hold_ms != 0 \
				and _puppet_hold_at.distance_to(screen) > HOLD_SLOP * App.ui_scale:
			_puppet_hold_ms = 0
		if _puppet_pin >= 0:
			puppet.move_pin(_puppet_pin, w)
		return
	if _symmetry_drag != 0:
		_move_symmetry(w)
		return
	if _camera_grab >= 0:
		_move_camera(w)
		return
	_speed = lerpf(_speed, screen_delta, 0.3)
	_pressure = pressure
	if _grab != Grab.NONE:
		_update_grab(screen)
		return
	if _picking:
		_update_pick(screen)
		return
	if _marking:
		_continue_mark(w)
		return
	if _drawing:
		_continue_stroke(w)
	elif _shape_active:
		_shape_b = w
		if App.shape_mode == App.Shape.POLYLINE and _poly_drag >= 0:
			poly_points[_poly_drag] = w
		overlay.queue_redraw()

func _end_input(screen: Vector2) -> void:
	_drop_hold()
	if _project_drag != null:
		_finish_project_drag()
		_touch_is_browser = false
		return
	if _touch_is_browser:
		_settle_strip()
		_touch_is_browser = false
		return
	var w: Vector2 = screen_to_canvas(screen)
	if text_box_layer >= 0 and _text_grab >= 0:
		_text_grab = -1
		_settle_text()
		return
	if puppet_active:
		_puppet_pin = -1
		_puppet_hold_ms = 0
		return
	if _symmetry_drag != 0:
		_move_symmetry(w)
		_symmetry_drag = 0
		overlay.queue_redraw()
		return
	if _camera_grab >= 0:
		_camera_grab = -1
		camera_framed.emit(chrome.camera_rect)
		return
	if _grab != Grab.NONE:
		_grab = Grab.NONE
		return
	if _picking:
		_finish_pick()
		return
	if _marking:
		_end_mark(w)
		return
	if _drawing:
		_end_stroke(w)
	elif _shape_active:
		_end_shape(w)
	elif App.current_tool == App.Tool.FILL:
		_do_fill(w)

func _cancel_input() -> void:
	_drop_hold()
	_strip_project = null
	_strip_ms = 0
	_puppet_pin = -1
	_puppet_hold_ms = 0
	if _project_drag != null:
		_finish_project_drag()
	_touch_is_browser = false
	if _picking:
		_picking = false
		_loupe.queue_redraw()
	if _marking:
		_marking = false
		if App.select_shape != App.SelectShape.POLY:
			_mark_points.clear()
		overlay.queue_redraw()
	_grab = Grab.NONE
	if _drawing:
		_drawing = false
		_leftover = 0.0
		if not _stroke_snap.is_empty():
			_restore(_stroke_layer, _stroke_snap)
			_stroke_snap = {}
	_shape_active = false
	_poly_drag = -1
	if overlay != null:
		overlay.queue_redraw()

# ----------------------------------------------------------- puppet warp

## Lifts the active layer's drawing off the layer and hands it to the warp.
##
## The drawing is taken away rather than merely covered, because the preview
## and the layer would otherwise both be on screen: one bent, one not, at
## the same place. Cancelling puts the original back exactly; applying puts
## the bent one down in its place.
func begin_puppet_warp() -> bool:
	if puppet_active:
		return true
	if layers == null or not layers.can_draw() or projects.active == null:
		return false
	var surface: PaintSurface = active_surface()
	if surface == null:
		return false
	surface.flush()

	var page: Rect2i = Rect2i(Vector2i.ZERO, Vector2i(projects.active.page))
	var box: Rect2i = surface.content_bounds().intersection(page)
	if box.size.x < 8 or box.size.y < 8:
		notice.emit(Lang.t("Draw something first"))
		return false

	var img: Image = surface.read_region(box)
	if img == null:
		return false

	# `content_bounds` answers in whole tiles, so a small drawing in the
	# corner of a large layer comes back inside a great deal of nothing.
	# The grid is fitted to the ink instead: a mesh spread over empty space
	# wastes vertices on air, and — worse — a pin dropped out there would
	# be pinning nothing while appearing to hold the drawing.
	var ink: Rect2i = img.get_used_rect()
	if ink.size.x < 8 or ink.size.y < 8:
		notice.emit(Lang.t("Draw something first"))
		return false
	if ink.position != Vector2i.ZERO or ink.size != box.size:
		var trimmed: Image = Image.create_empty(ink.size.x, ink.size.y,
			false, Image.FORMAT_RGBA8)
		trimmed.blit_rect(img, ink, Vector2i.ZERO)
		img = trimmed
		box = Rect2i(box.position + ink.position, ink.size)

	_puppet_layer = layers.active().id
	_puppet_snap = {}
	_collect(surface, box, _puppet_snap)
	if not puppet.begin(img, box):
		_puppet_snap = {}
		return false
	# The layer is emptied over the region the warp now owns. Its pixels are
	# not lost — they are in the warp, and in the snapshot behind it.
	surface.erase_masked(box, SelectionMask.full(box.size.x, box.size.y))

	puppet.zoom = view_zoom
	puppet_active = true
	_puppet_pin = -1
	cancel_selection()
	clear_marks()
	overlay.queue_redraw()
	puppet_changed.emit()
	return true

## Puts the drawing back down: bent, if that is what was asked for.
func end_puppet_warp(keep: bool) -> void:
	if not puppet_active:
		return
	var surface: PaintSurface = _surface_of(_puppet_layer)
	var baked: Dictionary = {}
	if keep and not puppet.pins.is_empty():
		baked = await puppet.bake()

	if surface != null:
		if baked.is_empty():
			# Nothing to keep, or the bake came back empty: the original is
			# laid back down untouched and no history entry is made.
			surface.blit_image(puppet.source, Vector2(puppet.rect.position), true)
			_puppet_snap = {}
		else:
			var box: Rect2i = baked["rect"]
			# The bent drawing can reach outside where it started, so the
			# undo snapshot has to cover both boxes before the new pixels
			# land — otherwise taking it back would leave the overspill.
			# Tiles already held are kept as they were: what undo restores
			# is the drawing before the warp, not the emptied layer.
			_collect(surface, box, _puppet_snap)
			# Written straight in rather than blended. What comes back from
			# the bake is already premultiplied — the same form the canvas
			# stores — and blending it would fold the alpha in a second
			# time, which shows up as ink that has gone thin and dark.
			surface.blit_image(baked["image"] as Image,
				Vector2(baked["at"] as Vector2i), true)

	if not _puppet_snap.is_empty():
		_push_undo(_puppet_layer, _puppet_snap,
			UiKit.label_for("Puppet warp", "التحريك بالدبابيس"))
		_puppet_snap = {}

	puppet.finish()
	puppet_active = false
	_puppet_pin = -1
	_puppet_layer = -1
	overlay.queue_redraw()
	puppet_changed.emit()

# ------------------------------------------------------------------- text

## The box around a text layer, for moving and turning it.
##
## Text is not ink here: the words and their angle live on the layer, and the
## pixels are made from them. So the box does not scale a picture — it changes
## two numbers, and the writing is drawn again from scratch at the new place
## and angle. Turn it a hundred times and the letters are exactly as sharp as
## they were, because nothing is ever resampled.
var text_box_layer: int = -1
var _text_grab: int = -1
var _text_from: Vector2 = Vector2.ZERO
var _text_turn_from: float = 0.0
## Where the box has been dragged to since the finger went down. The pixels
## are not moved until it lifts, so a drag costs nothing until it is finished.
var _text_shift: Vector2 = Vector2.ZERO

## One grip turns, the body moves. Two things, so neither needs a mode.
func _begin_text_box(w: Vector2) -> bool:
	var l: LayerStack.Layer = text_layer()
	if l == null:
		return false
	var box: Rect2 = text_bounds()
	if box.size.x < 1.0:
		return false
	var reach: float = 26.0 / maxf(view_zoom, 0.0001)
	var mid: Vector2 = box.get_center()
	var handle: Vector2 = mid + Vector2(0.0, -box.size.y * 0.5 - reach * 1.6) \
		.rotated(l.text_turn)
	if w.distance_to(handle) <= reach:
		_text_grab = 1
		_text_from = w
		_text_turn_from = l.text_turn
		return true
	if box.grow(reach * 0.5).has_point(w):
		_text_grab = 0
		_text_from = w
		return true
	return false

func _move_text_box(w: Vector2) -> void:
	var l: LayerStack.Layer = text_layer()
	if l == null:
		return
	if _text_grab == 1:
		var mid: Vector2 = text_bounds().get_center()
		var was: float = (_text_from - mid).angle()
		var now: float = (w - mid).angle()
		l.text_turn = _text_turn_from + (now - was)
	else:
		# Moved by redrawing at the new place rather than by sliding pixels
		# about: the layer holds the words, so putting them somewhere else is
		# just a different place to draw them.
		var shift: Vector2 = w - _text_from
		_text_from = w
		l.text_at += shift
		_text_shift += shift
	overlay.queue_redraw()

## The turn is only a number until the finger lifts; then the writing is drawn
## again at that angle, so it is never a rotated picture of itself.
func _settle_text() -> void:
	var l: LayerStack.Layer = text_layer()
	if l == null:
		return
	text_restyle_needed.emit(l.id)
	_text_shift = Vector2.ZERO

## The box, drawn at a constant size on screen: a corner stays a corner and
## the turn grip stays thumb-sized at any zoom.
func draw_text_box() -> void:
	var l: LayerStack.Layer = text_layer()
	if l == null:
		return
	var box: Rect2 = text_bounds()
	if box.size.x < 1.0:
		return
	box.position += _text_shift
	var thin: float = 1.0 / maxf(view_zoom, 0.0001)
	var mid: Vector2 = box.get_center()
	var ivory: Color = Color("#FFF8E7")

	var corners: PackedVector2Array = PackedVector2Array()
	for c in [box.position, Vector2(box.end.x, box.position.y), box.end,
			Vector2(box.position.x, box.end.y)]:
		corners.append(mid + ((c as Vector2) - mid).rotated(l.text_turn))
	corners.append(corners[0])
	overlay.draw_polyline(corners, Color(0.05, 0.04, 0.03, 0.45), 3.0 * thin)
	overlay.draw_polyline(corners, ivory, 1.4 * thin)
	for i in 4:
		overlay.draw_circle(corners[i], 4.0 * thin, ivory)

	var grip: Vector2 = mid + Vector2(0.0,
		-box.size.y * 0.5 - 26.0 * thin * 1.6).rotated(l.text_turn)
	overlay.draw_line(mid + Vector2(0.0, -box.size.y * 0.5).rotated(l.text_turn),
		grip, Color(ivory.r, ivory.g, ivory.b, 0.6), 1.4 * thin)
	overlay.draw_circle(grip + Vector2(1, 2) * thin, 10.0 * thin,
		Color(0, 0, 0, 0.3))
	overlay.draw_circle(grip, 9.0 * thin, ivory)
	overlay.draw_arc(grip, 9.0 * thin, 0.0, TAU, 20, Color("#8A7C58"), 2.0 * thin)

func begin_text_box(layer_id: int) -> void:
	text_box_layer = layer_id
	_text_grab = -1
	overlay.queue_redraw()

func end_text_box() -> void:
	text_box_layer = -1
	_text_grab = -1
	overlay.queue_redraw()

func text_layer() -> LayerStack.Layer:
	if layers == null or text_box_layer < 0:
		return null
	for l in layers.layers:
		if l.id == text_box_layer:
			return l if l.is_text else null
	return null

## Where the writing sits on the page, as a box with a turn on it.
func text_bounds() -> Rect2:
	var l: LayerStack.Layer = text_layer()
	if l == null:
		return Rect2()
	var box: Rect2i = l.surface.content_bounds()
	return Rect2(Vector2(box.position), Vector2(box.size))

## Swaps the pixels of a text layer for freshly drawn ones, keeping where it
## sits. One undo step covers the change.
func replace_text_pixels(layer_id: int, img: Image) -> void:
	var l: LayerStack.Layer = null
	for one in layers.layers:
		if one.id == layer_id:
			l = one
			break
	if l == null or img == null:
		return
	var was: Rect2i = l.surface.content_bounds()
	var mid: Vector2 = Vector2(was.position) + Vector2(was.size) * 0.5
	if was.size.x < 2:
		mid = l.text_at
	var at: Vector2i = Vector2i((mid - Vector2(img.get_width(),
		img.get_height()) * 0.5).round())
	l.text_at = Vector2(at)
	var into: Rect2i = Rect2i(at, Vector2i(img.get_width(), img.get_height()))
	stamp_region(layer_id, into, was, img, at,
		UiKit.label_for("Text", "نص"))
	overlay.queue_redraw()

## Puts freshly written text down at a place chosen by the caller, rather
## than centred on where the old pixels happened to be.
func replace_text_at(layer_id: int, img: Image, at: Vector2) -> void:
	var l: LayerStack.Layer = null
	for one in layers.layers:
		if one.id == layer_id:
			l = one
			break
	if l == null or img == null:
		return
	var was: Rect2i = l.surface.content_bounds()
	var mid: Vector2 = at + _text_shift
	var corner: Vector2i = Vector2i(mid.round())
	l.text_at = Vector2(corner)
	_text_shift = Vector2.ZERO
	stamp_region(layer_id,
		Rect2i(corner, Vector2i(img.get_width(), img.get_height())),
		was, img, corner, UiKit.label_for("Text", "نص"))
	overlay.queue_redraw()

## Replaces one patch of a layer with another, as a single undoable act.
##
## Used by the rooms that hand a finished drawing back: they own the pixels for
## as long as they are open, and this is the door they come back through. The
## snapshot covers both the patch being cleared and the patch being written,
## because a posed figure rarely lands inside the box it started in.
func stamp_region(layer_id: int, into: Rect2i, clear: Rect2i, img: Image,
		at: Vector2i, label: String) -> void:
	var surface: PaintSurface = _surface_of(layer_id)
	if surface == null or img == null:
		return
	var snap: Dictionary = {}
	_collect(surface, clear, snap)
	_collect(surface, into, snap)
	surface.erase_masked(clear, SelectionMask.full(clear.size.x, clear.size.y))
	# Written straight in: what comes back is already premultiplied, and
	# blending it would fold the alpha through a second time.
	surface.blit_image(img, Vector2(at), true)
	if not snap.is_empty():
		_push_undo(layer_id, snap, label)
	if projects.active != null:
		projects.mark_dirty(projects.active)
	if layers != null:
		layers.changed.emit()

func _surface_of(layer_id: int) -> PaintSurface:
	if layers == null:
		return null
	for l in layers.layers:
		if l.id == layer_id:
			return l.surface
	return null

## One finger, three meanings, decided by what it lands on: a pin to drag,
## a pin tapped twice to take away, or bare drawing to pin.
func _begin_puppet(w: Vector2, screen: Vector2) -> void:
	var reach: float = 26.0 / maxf(view_zoom, 0.0001)
	var hit: int = puppet.pin_at(w, reach)
	var now: int = Time.get_ticks_msec()

	if hit >= 0:
		var double: bool = now - _puppet_tap_ms <= TAP_MS and _puppet_tap_pin == hit
		_puppet_tap_ms = now
		_puppet_tap_pin = hit
		puppet.selected = hit
		puppet.queue_redraw()
		if double:
			puppet.remove_pin(hit)
			_puppet_pin = -1
			_puppet_tap_pin = -1
			_puppet_hold_ms = 0
			return
		_puppet_pin = hit
		# A press held on a pin, rather than dragged, pins it down for good:
		# the commonest thing to want after placing a pin is for it to stop
		# moving, and reaching for a panel to say so breaks the pose.
		_puppet_hold_ms = now
		_puppet_hold_at = screen
		return

	_puppet_tap_ms = now
	_puppet_tap_pin = -1
	_puppet_hold_ms = 0
	# A pin is grabbed the instant it is made, so one movement both places
	# it and pulls with it. A tap on blank paper makes nothing: a pin off the
	# mesh has no ink to hold, and one that appeared there would look like it
	# was holding something.
	_puppet_pin = puppet.add_pin(w)
	if _puppet_pin < 0:
		notice.emit(Lang.t("Put pins on the drawing"))

# --------------------------------------------------------------- projects

func floating_project() -> Variant:
	return projects.placing

## Returns true when the touch belonged to a project rather than to a tool.
##
## This is the gate every stroke has to pass through, and it used to be shut.
## Any touch landing on any sheet was answered by the browser — selected it,
## brought it forward, and swallowed the event — so once a project existed
## the brush could never receive a single press. The rule now is simple and
## has one line: **the open project belongs to the tools.** Inside its
## bounds the browser does not answer at all.
##
## Everything else keeps the browser's own manners:
##   * the strip above a sheet opens that sheet's frame colour, nothing else
##   * one tap on a closed sheet selects it and does not open it
##   * two taps open it and focus it, which is what puts the tools on screen
##   * a press held on a closed sheet picks it up so it can be dragged
func _handle_project_touch(screen: Vector2, w: Vector2) -> bool:
	var now: int = Time.get_ticks_msec()

	# --- a sheet still looking for its place ---
	var drifting: Variant = floating_project()
	if drifting != null:
		var double_place: bool = now - _tap_ms <= TAP_MS \
			and _tap_at.distance_to(screen) <= 40.0 * App.ui_scale
		_tap_ms = now
		_tap_at = screen
		if double_place and _opened == drifting:
			projects.place(drifting)
			projects.open(drifting)
			projects.set_focus(drifting)
			frame_project(drifting)
			_opened = drifting
			_opened_ms = now
			project_focused.emit(drifting)
		else:
			_project_drag = drifting
			_project_grab = w - drifting.origin
			projects.bring_to_front(drifting)
			projects.select(drifting)
			_opened = drifting
		return true

	# --- the open project is the tools' ground, not the browser's ---
	# Checked before anything else so a brush, a fill or a selection never
	# has to compete with the sheet it is being used on.
	var live: Variant = projects.active
	if live != null and live.bounds().grow(_page_reach()).has_point(w):
		return false

	# --- the title strip ---
	# A tap is the frame colour. Held, it is everything else the project can
	# do. The options menu had a listener waiting for it in the shell and
	# nothing anywhere that ever called for it, so duplicating, renaming,
	# exporting and deleting a project were all unreachable from the
	# workspace — the strip is where they belong, beside the one setting that
	# already lives there.
	var strip: Variant = projects.title_strip_at(w, view_zoom)
	if strip != null:
		projects.select(strip)
		_strip_project = strip
		_strip_ms = now
		_strip_at = screen
		return true

	var hit: Variant = projects.at_point(w)
	if hit == null:
		projects.clear_selection()
		_drop_hold()
		# With a project open, the ground around it is neither canvas nor
		# browser: a stroke started out here would land nowhere, so the
		# touch is simply absorbed.
		return live != null or layers == null

	var double: bool = now - _tap_ms <= TAP_MS \
		and _tap_at.distance_to(screen) <= 40.0 * App.ui_scale
	_tap_ms = now
	_tap_at = screen

	# Two taps open. One tap never does — a sheet under a veil stays under
	# it until it has been asked twice, which is what the door means.
	if double and _opened == hit:
		_drop_hold()
		projects.bring_to_front(hit)
		projects.open(hit)
		projects.set_focus(hit)
		hit.grid_guide = true
		_opened = hit
		_opened_ms = now
		frame_project(hit)
		project_focused.emit(hit)
		return true

	projects.bring_to_front(hit)
	projects.select(hit)
	_opened = hit
	_opened_ms = now

	# The press starts counting here. Held long enough without wandering,
	# it becomes a move; released before that, it was only a selection.
	_hold_project = hit
	_hold_from = w
	_hold_screen = screen
	_hold_ms = now
	return true

## A little room outside the page, so a stroke that begins a hair past the
## edge still belongs to the drawing rather than to the browser.
func _page_reach() -> float:
	return 24.0 / maxf(view_zoom, 0.0001)

## Turns a held press into a drag once it has been held long enough.
func _tick_hold() -> void:
	if _strip_project != null and _strip_ms != 0 \
			and Time.get_ticks_msec() - _strip_ms >= HOLD_TO_DRAG_MS + 120:
		var who: Variant = _strip_project
		_strip_project = null
		_strip_ms = 0
		project_menu_requested.emit(who)
		return
	if _hold_project == null or _project_drag != null:
		return
	if Time.get_ticks_msec() - _hold_ms < HOLD_TO_DRAG_MS:
		return
	_project_drag = _hold_project
	_project_grab = _hold_from - _hold_project.origin
	_hold_project = null
	projects.dragging = _project_drag
	projects.bring_to_front(_project_drag)
	if chrome != null:
		chrome.refresh(view_zoom)
	notice.emit(Lang.t("Drag to move it"))

## A pin held still under the finger becomes an anchor.
func _tick_puppet_hold() -> void:
	if not puppet_active or _puppet_hold_ms == 0 or _puppet_pin < 0:
		return
	if Time.get_ticks_msec() - _puppet_hold_ms < HOLD_TO_DRAG_MS + 160:
		return
	var at: int = _puppet_pin
	_puppet_hold_ms = 0
	_puppet_pin = -1
	puppet.toggle_anchor(at)
	notice.emit(Lang.t("Pin held still") if puppet.is_anchored(at) \
		else Lang.t("Pin released"))

func _drop_hold() -> void:
	_hold_project = null
	_hold_ms = 0

## A press that began on a title strip and ended before it became a hold was
## asking for the frame colour, which is the thing that strip is for.
func _settle_strip() -> void:
	if _strip_project == null:
		return
	var who: Variant = _strip_project
	_strip_project = null
	_strip_ms = 0
	frame_colour_requested.emit(who)

## A sheet that has been carried somewhere keeps where it was put — the
## workspace remembers positions, so the move has to be written down.
func _finish_project_drag() -> void:
	if _project_drag == null:
		return
	projects.mark_dirty(_project_drag)
	_project_drag = null
	projects.dragging = null
	if chrome != null:
		chrome.refresh(view_zoom)

# ------------------------------------------------------------ stroke engine

func _begin_stroke(w: Vector2) -> void:
	if layers == null or player == null:
		return
	if player.clip != null:
		player.ensure_editable_for_stroke()
	var current_layer: LayerStack.Layer = layers.active()
	if current_layer == null:
		return
	_drawing = true
	_smoother.reset(w)
	_last_stamp = w
	_leftover = 0.0
	_speed = 0.0
	_stroke_snap = {}
	_stroke_layer = current_layer.id
	_stamp_at(w, w)

func _continue_stroke(w: Vector2) -> void:
	var target: Vector2 = _smoother.filter(w)
	var seg: float = _last_stamp.distance_to(target)
	if seg <= 0.0001:
		return
	var spacing: float = _spacing()
	var dir: Vector2 = (target - _last_stamp) / seg
	var travelled: float = -_leftover
	var guard: int = 0
	while travelled + spacing <= seg and guard < 4096:
		travelled += spacing
		var p: Vector2 = _last_stamp + dir * travelled
		_stamp_at(p, p - dir)
		spacing = _spacing()
		guard += 1
	_leftover = seg - travelled
	_last_stamp = target

func _end_stroke(w: Vector2) -> void:
	if not _drawing:
		return
	_continue_stroke(w)
	_drawing = false
	_settle_in = 2
	_push_undo(_stroke_layer, _stroke_snap)
	_stroke_snap = {}

func _spacing() -> float:
	if App.current_tool == App.Tool.ERASER:
		return maxf(App.eraser_size * 0.08, 0.6)
	var p: BrushLibrary.Preset = App.current_preset()
	var gap: float = 0.1
	if p != null:
		gap = p.spacing
	return maxf(App.brush_size * gap, 0.5)

func _stamp_symmetry(pos: Vector2, from: Vector2) -> void:
	if not symmetry_enabled:
		_stamp_single(pos, from)
		return
	var count: int = maxi(symmetry_count, 2)
	var centre: Vector2 = symmetry_center
	if count == 2:
		_stamp_single(pos, from)
		_stamp_reflected(pos, from)
		return
	var rel_pos: Vector2 = pos - centre
	var rel_from: Vector2 = from - centre
	for i in range(count):
		var a: float = symmetry_angle + TAU * float(i) / float(count)
		var rot: Transform2D = Transform2D(a, Vector2.ZERO)
		var a_pos: Vector2 = centre + rot * rel_pos
		var a_from: Vector2 = centre + rot * rel_from
		_stamp_single(a_pos, a_from)

func _stamp_reflected(pos: Vector2, from: Vector2) -> void:
	var d: Vector2 = pos - symmetry_center
	var n: Vector2 = Vector2(-sin(symmetry_angle), cos(symmetry_angle))
	var reflected: Vector2 = pos - 2.0 * n * d.dot(n)
	var df: Vector2 = from - symmetry_center
	var reflected_from: Vector2 = from - 2.0 * n * df.dot(n)
	_stamp_single(reflected, reflected_from)

func _stamp_single(pos: Vector2, from: Vector2) -> void:
	_stamp_impl(pos, from)

func _stamp_at(pos: Vector2, from: Vector2) -> void:
	if not symmetry_enabled:
		_stamp_impl(pos, from)
		return
	# Lateral symmetry uses the requested axis plus its repeated rotations.
	# For two-way symmetry this is a true mirror; higher counts are rotational.
	_stamp_symmetry(pos, from)

func _stamp_impl(pos: Vector2, from: Vector2) -> void:
	var surface: PaintSurface = active_surface()
	if surface == null:
		return
	var erasing: bool = App.current_tool == App.Tool.ERASER
	var tex: Texture2D = null
	var dab_size: float = 1.0
	var col: Color = Color.BLACK
	var angle: float = 0.0
	var place: Vector2 = pos

	if erasing:
		tex = _eraser_texture()
		dab_size = App.eraser_size
		col = Color(1.0, 1.0, 1.0, App.eraser_opacity)
	else:
		var preset: BrushLibrary.Preset = App.current_preset()
		if preset == null:
			return
		dab_size = App.brush_size
		tex = App.library.texture_for(App.brush_index, dab_size)
		col = App.ink
		col.a = App.brush_opacity

		if preset.follow_direction:
			var d: Vector2 = pos - from
			if d.length_squared() > 0.0001:
				_last_dir = d.angle()
			angle = _last_dir
		if preset.angle_jitter > 0.0:
			angle += randf_range(-preset.angle_jitter, preset.angle_jitter)
		if preset.size_jitter > 0.0:
			dab_size *= 1.0 + randf_range(-preset.size_jitter, preset.size_jitter)
		if preset.scatter > 0.0:
			var r: float = App.brush_size * preset.scatter
			place += Vector2(randf_range(-r, r), randf_range(-r, r))
		if preset.speed_thin > 0.0:
			var fast: float = clampf(_speed / 40.0, 0.0, 1.0)
			dab_size *= 1.0 - preset.speed_thin * fast
		# Eased rather than linear: light pressure should thin the mark
		# quickly and heavy pressure should saturate, which is how a real
		# nib behaves and how tapered ends appear.
		var shaped: float = _pressure * _pressure * (3.0 - 2.0 * _pressure)
		dab_size *= lerpf(0.35, 1.0, shaped)

	if tex == null:
		return
	dab_size = maxf(dab_size, 0.5)
	_snapshot_for(surface, place, dab_size)
	surface.stamp(place, dab_size, angle, col, tex, erasing)

func _eraser_texture() -> Texture2D:
	var key: int = App.eraser_shape
	if _eraser_cache.has(key):
		return _eraser_cache[key]
	var lib: BrushLibrary = App.library
	var tex: Texture2D = null
	if key == App.EraserShape.HARD:
		tex = lib.make_texture(lib.round_buffer(0.94))
	elif key == App.EraserShape.SQUARE:
		tex = lib.make_texture(lib.solid_buffer())
	else:
		tex = lib.make_texture(lib.round_buffer(0.35))
	_eraser_cache[key] = tex
	return tex

# ----------------------------------------------------------------- shapes

func _begin_shape(w: Vector2) -> void:
	if App.shape_mode == App.Shape.CHAIN:
		# The free one, and then every one after it.
		_shape_a = chain_anchor if chain_live else w
		_shape_b = w
		_shape_active = true
		overlay.queue_redraw()
		return
	if App.shape_mode == App.Shape.POLYLINE:
		_poly_drag = _nearest_point(w)
		if _poly_drag < 0:
			poly_points.append(w)
			_poly_drag = poly_points.size() - 1
		_shape_active = true
		overlay.queue_redraw()
		return
	_shape_active = true
	_shape_a = w
	_shape_b = w
	overlay.queue_redraw()

func _end_shape(w: Vector2) -> void:
	if App.current_tool == App.Tool.FILL:
		_shape_b = w
		_shape_active = false
		_commit_fill_shape()
		return
	if App.shape_mode == App.Shape.POLYLINE:
		_poly_drag = -1
		_shape_active = false
		overlay.queue_redraw()
		return
	if App.shape_mode == App.Shape.CHAIN:
		_shape_b = w
		_shape_active = false
		# A tap that went nowhere is a tap, not a line. Without this a
		# stray touch would lay a zero-length segment and move the anchor
		# on top of itself, which looks like the chain has stopped working.
		if _shape_a.distance_to(_shape_b) < 0.75:
			overlay.queue_redraw()
			return
		commit_shape()
		chain_anchor = _shape_b
		chain_live = true
		overlay.queue_redraw()
		return
	_shape_b = w
	_shape_active = false
	commit_shape()

## Lets go of the chain, so the next line is free again.
##
## Called from the panel's own button, and whenever the tool or the layer
## changes — a chain that survived a change of layer would start the next
## line from a point on a drawing that is no longer in front of you.
func break_chain() -> void:
	if not chain_live:
		return
	chain_live = false
	if overlay != null and is_instance_valid(overlay):
		overlay.queue_redraw()

func commit_shape() -> void:
	if layers == null or not layers.can_draw():
		return
	var pts: PackedVector2Array = _shape_points()
	if pts.size() < 2:
		return
	_stroke_snap = {}
	_stroke_layer = layers.active().id
	_speed = 0.0
	_pressure = 1.0
	_stroke_along(pts)
	_settle_in = 2
	_push_undo(_stroke_layer, _stroke_snap)
	_stroke_snap = {}
	if App.shape_mode == App.Shape.POLYLINE:
		poly_points.clear()
	overlay.queue_redraw()

func _shape_points() -> PackedVector2Array:
	return _outline(App.shape_mode == App.Shape.RECT,
		App.shape_mode == App.Shape.ELLIPSE,
		App.shape_mode == App.Shape.LINE or App.shape_mode == App.Shape.CHAIN,
		App.shape_mode == App.Shape.POLYLINE,
		_shape_a, _shape_b, poly_points)

func _outline(is_rect: bool, is_ellipse: bool, is_line: bool, is_poly: bool,
		a: Vector2, b: Vector2, pts: PackedVector2Array) -> PackedVector2Array:
	var out: PackedVector2Array = PackedVector2Array()
	if is_line:
		out.append(a)
		out.append(b)
	elif is_rect:
		var r: Rect2 = Rect2(a, b - a).abs()
		out.append(r.position)
		out.append(r.position + Vector2(r.size.x, 0.0))
		out.append(r.position + r.size)
		out.append(r.position + Vector2(0.0, r.size.y))
		out.append(r.position)
	elif is_ellipse:
		var rr: Rect2 = Rect2(a, b - a).abs()
		var c: Vector2 = rr.position + rr.size * 0.5
		var rad: Vector2 = rr.size * 0.5
		var steps: int = clampi(int(rr.size.length() * 0.7), 32, 256)
		for i in range(steps + 1):
			var t: float = TAU * float(i) / float(steps)
			out.append(c + Vector2(cos(t) * rad.x, sin(t) * rad.y))
	elif is_poly:
		out = _smooth_polyline(pts)
	return out

func _smooth_polyline(src: PackedVector2Array) -> PackedVector2Array:
	if src.size() < 3:
		return src
	var out: PackedVector2Array = PackedVector2Array()
	var n: int = src.size()
	for i in range(n - 1):
		var p0: Vector2 = src[maxi(i - 1, 0)]
		var p1: Vector2 = src[i]
		var p2: Vector2 = src[i + 1]
		var p3: Vector2 = src[mini(i + 2, n - 1)]
		for s in range(16):
			var t: float = float(s) / 16.0
			out.append(_catmull(p0, p1, p2, p3, t))
	out.append(src[n - 1])
	return out

func _catmull(p0: Vector2, p1: Vector2, p2: Vector2, p3: Vector2, t: float) -> Vector2:
	var t2: float = t * t
	var t3: float = t2 * t
	return 0.5 * ((2.0 * p1) + (-p0 + p2) * t +
		(2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2 +
		(-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3)

func _stroke_along(pts: PackedVector2Array) -> void:
	var carry: float = 0.0
	for i in range(pts.size() - 1):
		var a: Vector2 = pts[i]
		var b: Vector2 = pts[i + 1]
		var seg: float = a.distance_to(b)
		if seg <= 0.0001:
			continue
		var dir: Vector2 = (b - a) / seg
		var t: float = -carry
		var spacing: float = _spacing()
		var guard: int = 0
		while t + spacing <= seg and guard < 4096:
			t += spacing
			var p: Vector2 = a + dir * t
			_stamp_at(p, p - dir)
			spacing = _spacing()
			guard += 1
		carry = seg - t

func _nearest_point(w: Vector2) -> int:
	var best: int = -1
	var best_d: float = 18.0 / maxf(view_zoom, 0.0001)
	for i in poly_points.size():
		var d: float = poly_points[i].distance_to(w)
		if d < best_d:
			best_d = d
			best = i
	return best

# --------------------------------------------------------------- selection

func _begin_mark(w: Vector2) -> void:
	if App.select_shape == App.SelectShape.POLY:
		_mark_points.append(w)
		_marking = true
		overlay.queue_redraw()
		return
	_marking = true
	_mark_points = PackedVector2Array()
	_mark_points.append(w)
	_mark_points.append(w)
	overlay.queue_redraw()

func _continue_mark(w: Vector2) -> void:
	if App.select_shape == App.SelectShape.LASSO:
		if _mark_points.is_empty() or _mark_points[_mark_points.size() - 1].distance_to(w) \
				> LASSO_STEP / maxf(view_zoom, 0.0001):
			_mark_points.append(w)
	elif App.select_shape == App.SelectShape.POLY:
		if _mark_points.size() > 0:
			_mark_points[_mark_points.size() - 1] = w
	else:
		if _mark_points.size() >= 2:
			_mark_points[1] = w
	overlay.queue_redraw()

func _end_mark(_w: Vector2) -> void:
	_marking = false
	if App.select_shape == App.SelectShape.POLY:
		overlay.queue_redraw()
		selection_changed.emit()
		return
	lift_selection()

## Closes a dotted selection and lifts whatever it contains.
func close_selection() -> void:
	if App.select_shape == App.SelectShape.POLY and _mark_points.size() >= 3:
		lift_selection()

func clear_marks() -> void:
	_mark_points.clear()
	_marking = false
	overlay.queue_redraw()
	selection_changed.emit()

func has_marks() -> bool:
	return _mark_points.size() >= 2

## Cuts the marked pixels out of the active layer and holds them as a
## floating piece the user can move, scale and turn.
func lift_selection(keep_original: bool = false) -> bool:
	var surface: PaintSurface = active_surface()
	if surface == null or layers == null or _mark_points.size() < 2:
		return false
	var shape: int = App.select_shape
	var box: Rect2i = SelectionMask.bounds_of(_mark_points)
	if shape == App.SelectShape.RECT or shape == App.SelectShape.ELLIPSE:
		box = Rect2i(
			Vector2i(int(floor(minf(_mark_points[0].x, _mark_points[1].x))),
				int(floor(minf(_mark_points[0].y, _mark_points[1].y)))),
			Vector2i(int(absf(_mark_points[1].x - _mark_points[0].x)),
				int(absf(_mark_points[1].y - _mark_points[0].y))))
	if box.size.x < 2 or box.size.y < 2:
		clear_marks()
		return false
	if box.size.x > MAX_LIFT or box.size.y > MAX_LIFT:
		clear_marks()
		return false

	var img: Image = surface.read_region(box)
	if img == null:
		clear_marks()
		return false

	var mask: PackedByteArray
	if shape == App.SelectShape.RECT:
		mask = SelectionMask.full(box.size.x, box.size.y)
	elif shape == App.SelectShape.ELLIPSE:
		mask = SelectionMask.ellipse(box.size.x, box.size.y)
	else:
		mask = SelectionMask.polygon(_mark_points, box.position, box.size.x, box.size.y)

	if not SelectionMask.apply(img, mask):
		clear_marks()
		return false

	_sel_snapshot = {}
	_sel_layer = layers.active().id
	if not keep_original:
		_snapshot_rect(surface, box)
		surface.erase_masked(box, mask)

	_sel_tex = ImageTexture.create_from_image(img)
	_sel_size = Vector2(float(box.size.x), float(box.size.y))
	_sel_center = Vector2(box.position) + _sel_size * 0.5
	_sel_rot = 0.0
	_sel_scale = 1.0
	sel_active = true
	_mark_points.clear()
	overlay.queue_redraw()
	selection_changed.emit()
	return true

func selection_transform() -> Transform2D:
	var cs: float = cos(_sel_rot) * _sel_scale
	var sn: float = sin(_sel_rot) * _sel_scale
	var xf: Transform2D = Transform2D(Vector2(cs, sn), Vector2(-sn, cs), _sel_center)
	return xf.translated_local(-_sel_size * 0.5)

func _sel_corners() -> Array:
	var xf: Transform2D = selection_transform()
	return [
		xf * Vector2.ZERO,
		xf * Vector2(_sel_size.x, 0.0),
		xf * _sel_size,
		xf * Vector2(0.0, _sel_size.y),
	]

func _rotate_handle() -> Vector2:
	var c: Array = _sel_corners()
	var top: Vector2 = ((c[0] as Vector2) + (c[1] as Vector2)) * 0.5
	var up: Vector2 = Vector2(sin(_sel_rot), -cos(_sel_rot))
	return top + up * (34.0 / maxf(view_zoom, 0.0001))

func _hit_handle(screen: Vector2) -> int:
	if not sel_active:
		return Grab.NONE
	var reach: float = HANDLE_HIT * App.ui_scale
	if canvas_to_screen(_rotate_handle()).distance_to(screen) <= reach:
		return Grab.ROTATE
	for c in _sel_corners():
		if canvas_to_screen(c).distance_to(screen) <= reach:
			return Grab.SCALE
	# inside the box?
	var local: Vector2 = selection_transform().affine_inverse() * screen_to_canvas(screen)
	if local.x >= 0.0 and local.y >= 0.0 and local.x <= _sel_size.x and local.y <= _sel_size.y:
		return Grab.MOVE
	return Grab.NONE

func _start_grab(kind: int, screen: Vector2) -> void:
	_grab = kind
	_grab_start = screen_to_canvas(screen)
	_grab_centre = _sel_center
	_grab_scale = _sel_scale
	_grab_rot = _sel_rot
	if kind == Grab.ROTATE:
		_grab_ref = (_grab_start - _sel_center).angle() - _sel_rot
	elif kind == Grab.SCALE:
		_grab_ref = maxf(_grab_start.distance_to(_sel_center), 0.001)

func _update_grab(screen: Vector2) -> void:
	var w: Vector2 = screen_to_canvas(screen)
	if _grab == Grab.MOVE:
		_sel_center = _grab_centre + (w - _grab_start)
	elif _grab == Grab.ROTATE:
		_sel_rot = (w - _sel_center).angle() - _grab_ref
	elif _grab == Grab.SCALE:
		var now: float = maxf(w.distance_to(_sel_center), 0.001)
		_sel_scale = clampf(_grab_scale * (now / _grab_ref), 0.02, 40.0)
	overlay.queue_redraw()

## Drops the floating piece onto its layer for good.
func commit_selection() -> void:
	if not sel_active:
		return
	var surface: PaintSurface = layers.surface_by_id(_sel_layer)
	if surface == null:
		surface = active_surface()
	if surface != null and _sel_tex != null:
		var corners: Array = _sel_corners()
		var lo: Vector2 = corners[0]
		var hi: Vector2 = corners[0]
		for c in corners:
			lo.x = minf(lo.x, (c as Vector2).x)
			lo.y = minf(lo.y, (c as Vector2).y)
			hi.x = maxf(hi.x, (c as Vector2).x)
			hi.y = maxf(hi.y, (c as Vector2).y)
		_snapshot_rect(surface, Rect2i(
			Vector2i(int(floor(lo.x)) - 2, int(floor(lo.y)) - 2),
			Vector2i(int(hi.x - lo.x) + 4, int(hi.y - lo.y) + 4)))
		surface.blit_transformed(_sel_tex, selection_transform(), _sel_size)
		_settle_in = 3
	history.push_pixels(UiKit.label_for("Place selection", "تثبيت تحديد"),
		_sel_layer, _sel_snapshot)
	_sel_snapshot = {}
	_drop_floating()

## Throws the floating piece away and puts the pixels back where they were.
func cancel_selection() -> void:
	if not sel_active:
		return
	if not _sel_snapshot.is_empty():
		_restore(_sel_layer, _sel_snapshot)
	_sel_snapshot = {}
	_drop_floating()

func _drop_floating() -> void:
	sel_active = false
	_sel_tex = null
	_grab = Grab.NONE
	overlay.queue_redraw()
	selection_changed.emit()

## Hands an image to the selection machinery instead of stamping it down.
## A picture almost never lands where it is finally wanted, and arriving as
## a floating piece means it can be moved, turned and scaled before it
## becomes part of the layer — with Cancel still meaning cancel.
func float_image(img: Image, layer_id: int, centre: Vector2) -> bool:
	if img == null or layers == null:
		return false
	if sel_active:
		commit_selection()
	var copy: Image = Image.create_empty(img.get_width(), img.get_height(),
		false, Image.FORMAT_RGBA8)
	copy.copy_from(img)
	_sel_tex = ImageTexture.create_from_image(copy)
	_sel_size = Vector2(float(copy.get_width()), float(copy.get_height()))
	_sel_center = centre
	_sel_rot = 0.0
	_sel_scale = 1.0
	_sel_layer = layer_id
	_sel_snapshot = {}
	sel_active = true
	overlay.queue_redraw()
	selection_changed.emit()
	return true

# --------------------------------------------------------------- clipboard

func copy_selection() -> bool:
	if layers == null:
		return false
	if sel_active and _sel_tex != null:
		App.clipboard = _sel_tex.get_image()
		return true
	if has_marks() and lift_selection(true):
		App.clipboard = _sel_tex.get_image()
		_drop_floating()
		return true
	# nothing marked: take the whole layer
	var surface: PaintSurface = active_surface()
	if surface == null:
		return false
	var box: Rect2i = surface.content_bounds()
	if box.size.x <= 0 or box.size.y <= 0:
		return false
	if box.size.x > MAX_LIFT or box.size.y > MAX_LIFT:
		var centre: Vector2i = box.position + Vector2i(box.size.x >> 1, box.size.y >> 1)
		var half: int = int(float(MAX_LIFT) * 0.5)
		box = Rect2i(centre - Vector2i(half, half), Vector2i(MAX_LIFT, MAX_LIFT))
	var img: Image = surface.read_region(box)
	if img == null:
		return false
	App.clipboard = img
	return true

func paste_clipboard() -> bool:
	if App.clipboard == null or layers == null:
		return false
	if sel_active:
		commit_selection()
	var img: Image = Image.create_empty(App.clipboard.get_width(),
		App.clipboard.get_height(), false, Image.FORMAT_RGBA8)
	img.copy_from(App.clipboard)
	_sel_tex = ImageTexture.create_from_image(img)
	_sel_size = Vector2(float(img.get_width()), float(img.get_height()))
	_sel_center = screen_to_canvas(size * 0.5)
	_sel_rot = 0.0
	_sel_scale = 1.0
	_sel_layer = layers.active().id
	_sel_snapshot = {}
	sel_active = true
	overlay.queue_redraw()
	selection_changed.emit()
	return true

## Lays down a solid shape in the bucket's colour. Not a stroke that happens
## to close: the interior is filled outright, which is what anyone reaching
## for a bucket and a rectangle is asking for.
func _commit_fill_shape() -> void:
	var surface: PaintSurface = active_surface()
	if surface == null or layers == null or not layers.can_draw():
		return
	var r: Rect2 = Rect2(_shape_a, _shape_b - _shape_a).abs()
	if r.size.x < 2.0 or r.size.y < 2.0:
		return
	var box: Rect2i = Rect2i(Vector2i(r.position.floor()), Vector2i(r.size.ceil()))
	if box.size.x > 4096 or box.size.y > 4096:
		return

	var mask: PackedByteArray = _fill_mask(box.size.x, box.size.y)
	var bytes: PackedByteArray = PackedByteArray()
	bytes.resize(box.size.x * box.size.y * 4)
	var ink: Color = App.fill_ink
	var a: int = int(clampf(ink.a, 0.0, 1.0) * 255.0)
	# Premultiplied, like everything else the canvas holds.
	var cr: int = int(clampf(ink.r, 0.0, 1.0) * float(a))
	var cg: int = int(clampf(ink.g, 0.0, 1.0) * float(a))
	var cb: int = int(clampf(ink.b, 0.0, 1.0) * float(a))
	for i in range(box.size.x * box.size.y):
		if mask[i] == 0:
			continue
		var o: int = i * 4
		bytes[o] = cr
		bytes[o + 1] = cg
		bytes[o + 2] = cb
		bytes[o + 3] = a
	var img: Image = Image.create_empty(box.size.x, box.size.y, false, Image.FORMAT_RGBA8)
	img.set_data(box.size.x, box.size.y, false, Image.FORMAT_RGBA8, bytes)

	var snap: Dictionary = {}
	_collect(surface, box, snap)
	surface.blit_image(img, Vector2(box.position))
	history.push_pixels(UiKit.label_for("Fill", "ملء"), layers.active().id, snap)

func _fill_mask(w: int, h: int) -> PackedByteArray:
	if App.fill_shape == App.FillShape.ELLIPSE:
		return SelectionMask.ellipse(w, h)
	if App.fill_shape == App.FillShape.RECT:
		return SelectionMask.full(w, h)
	var pts: PackedVector2Array = PackedVector2Array()
	var fw: float = float(w)
	var fh: float = float(h)
	if App.fill_shape == App.FillShape.TRIANGLE:
		pts.append(Vector2(fw * 0.5, 0.0))
		pts.append(Vector2(fw, fh))
		pts.append(Vector2(0.0, fh))
	elif App.fill_shape == App.FillShape.DIAMOND:
		pts.append(Vector2(fw * 0.5, 0.0))
		pts.append(Vector2(fw, fh * 0.5))
		pts.append(Vector2(fw * 0.5, fh))
		pts.append(Vector2(0.0, fh * 0.5))
	else:
		var c: Vector2 = Vector2(fw * 0.5, fh * 0.5)
		for i in range(10):
			var t: float = TAU * float(i) / 10.0 - PI * 0.5
			var reach: float = 0.5 if i % 2 == 0 else 0.21
			pts.append(c + Vector2(cos(t) * fw * reach, sin(t) * fh * reach))
	return SelectionMask.polygon(pts, Vector2i.ZERO, w, h)

# ------------------------------------------------------------------- fill

func _do_fill(w: Vector2) -> void:
	var surface: PaintSurface = active_surface()
	if surface == null or layers == null or not layers.can_draw():
		return
	var page: Vector2 = Vector2.ZERO
	if projects.active != null:
		page = projects.active.page
	var res: Variant = FloodFill.run(layers, w, App.fill_ink, size, view_zoom, page)
	if res == null:
		return
	var data: Dictionary = res
	var origin: Vector2i = data["origin"]
	var img: Image = data["image"]
	var snap: Dictionary = {}
	_collect(surface, Rect2i(origin, Vector2i(img.get_width(), img.get_height())), snap)
	surface.blit_image(img, Vector2(origin))
	history.push_pixels(UiKit.label_for("Fill", "ملء"), layers.active().id, snap)

# -------------------------------------------------------------- eyedropper

func _update_pick(screen: Vector2) -> void:
	var w: Vector2 = screen_to_canvas(screen)
	_pick_screen = screen
	if layers == null:
		return
	_pick_color = layers.sample(w)
	# A handful of pixels, so turning them back into ordinary colours for
	# the magnifier costs nothing worth measuring.
	var patch: Image = layers.read_region(Rect2i(
		Vector2i(int(floor(w.x)) - 7, int(floor(w.y)) - 7), Vector2i(15, 15)))
	if patch != null:
		for py in range(patch.get_height()):
			for px in range(patch.get_width()):
				patch.set_pixel(px, py,
					PaintSurface.to_straight(patch.get_pixel(px, py)))
		_pick_tex = ImageTexture.create_from_image(patch)
	pointer_moved.emit(w)
	_loupe.queue_redraw()

func _finish_pick() -> void:
	_picking = false
	_loupe.queue_redraw()
	if _pick_color.a < 0.02:
		App.end_pick()
		return
	var c: Color = _pick_color
	c.a = 1.0
	App.apply_picked(c)
	App.end_pick()

func _draw_loupe() -> void:
	if not _picking:
		return
	var side: float = UiKit.s(112.0)
	var lift: float = UiKit.s(96.0)
	var centre: Vector2 = Vector2(
		clampf(_pick_screen.x, side * 0.5 + 4.0, maxf(size.x - side * 0.5 - 4.0, side)),
		clampf(_pick_screen.y - lift, side * 0.5 + 4.0, maxf(size.y - side * 0.5 - 4.0, side)))
	var box: Rect2 = Rect2(centre - Vector2(side, side) * 0.5, Vector2(side, side))

	_loupe.draw_rect(box.grow(UiKit.s(3.0)), Color(1.0, 1.0, 1.0, 0.95), true)
	if _pick_tex != null:
		_loupe.draw_texture_rect(_pick_tex, box, false)
	else:
		_loupe.draw_rect(box, Color(0.98, 0.97, 0.95, 1.0), true)

	var cell: float = side / 15.0
	var mid: Rect2 = Rect2(centre - Vector2(cell, cell) * 0.5, Vector2(cell, cell))
	_loupe.draw_rect(mid, Color(0.0, 0.0, 0.0, 0.85), false, UiKit.s(1.5))
	_loupe.draw_rect(mid.grow(UiKit.s(1.5)), Color(1.0, 1.0, 1.0, 0.85), false, UiKit.s(1.0))

	var chip: Rect2 = Rect2(box.position.x, box.position.y + box.size.y + UiKit.s(6.0),
		box.size.x, UiKit.s(24.0))
	_loupe.draw_rect(chip, Color(0.11, 0.11, 0.13, 0.92), true)
	_loupe.draw_rect(Rect2(chip.position + Vector2(UiKit.s(4.0), UiKit.s(4.0)),
		Vector2(UiKit.s(16.0), UiKit.s(16.0))), _pick_color, true)
	var f: Font = ThemeDB.fallback_font
	if f != null:
		_loupe.draw_string(f, chip.position + Vector2(UiKit.s(26.0), UiKit.s(17.0)),
			"#" + _pick_color.to_html(false).to_upper(),
			HORIZONTAL_ALIGNMENT_LEFT, -1, int(UiKit.s(12.0)), Color(0.85, 0.83, 0.78))
	_loupe.draw_line(Vector2(centre.x, box.position.y + box.size.y),
		_pick_screen, Color(1.0, 1.0, 1.0, 0.5), UiKit.s(1.5))

# ---------------------------------------------------------------- history

func _snapshot_for(surface: PaintSurface, pos: Vector2, dab_size: float) -> void:
	var reach: float = dab_size * 0.75 + 2.0
	_collect(surface, Rect2i(
		Vector2i(int(floor(pos.x - reach)), int(floor(pos.y - reach))),
		Vector2i(int(reach * 2.0) + 2, int(reach * 2.0) + 2)), _stroke_snap)

func _snapshot_rect(surface: PaintSurface, rect: Rect2i) -> void:
	_collect(surface, rect, _sel_snapshot)

func _collect(surface: PaintSurface, rect: Rect2i, into: Dictionary) -> void:
	var c0: Vector2i = surface.tile_coord(Vector2(rect.position))
	var c1: Vector2i = surface.tile_coord(Vector2(rect.position + rect.size))
	for ty in range(c0.y, c1.y + 1):
		for tx in range(c0.x, c1.x + 1):
			var c: Vector2i = Vector2i(tx, ty)
			if into.has(c):
				continue
			into[c] = surface.snapshot_tile(c)

func _push_undo(layer_id: int, snap: Dictionary, label: String = "") -> void:
	if history == null:
		return
	if label == "":
		label = UiKit.label_for("Stroke", "خط")
	history.push_pixels(label, layer_id, snap)

func _restore(layer_id: int, snap: Dictionary) -> void:
	if layers == null:
		return
	var surface: PaintSurface = layers.surface_by_id(layer_id)
	if surface == null:
		return
	for c in snap.keys():
		surface.restore_tile(c, snap[c])

func can_undo() -> bool:
	return history != null and history.can_undo()

func can_redo() -> bool:
	return history != null and history.can_redo()

func undo() -> void:
	# A floating selection is a change in progress, not a finished one, so
	# the first undo puts it back rather than reaching past it.
	if sel_active:
		cancel_selection()
		return
	if history != null:
		history.undo()

func redo() -> void:
	if history != null:
		history.redo()

func clear_active_layer() -> void:
	var surface: PaintSurface = active_surface()
	if surface == null or layers == null:
		return
	var snap: Dictionary = {}
	for c in surface.get_tile_coords():
		snap[c] = surface.snapshot_tile(c)
	surface.clear_all()
	history.push_pixels(UiKit.label_for("Erase layer", "مسح طبقة"), layers.active().id, snap)

# ----------------------------------------------------------------- overlay

func _draw_overlay() -> void:
	if text_box_layer >= 0:
		draw_text_box()
	if symmetry_enabled:
		var c_screen: Vector2 = canvas_to_screen(symmetry_center)
		var dir: Vector2 = Vector2(cos(symmetry_angle), sin(symmetry_angle))
		var axis_len: float = maxf(size.x, size.y) * 0.8
		overlay.draw_line(c_screen - dir * axis_len, c_screen + dir * axis_len,
			Color(0.3, 0.75, 1.0, 0.82), maxf(2.0, 2.0 * App.ui_scale / maxf(view_zoom, 0.001)))
		var handle: Vector2 = c_screen + dir * (44.0 * App.ui_scale)
		overlay.draw_circle(c_screen, 10.0 * App.ui_scale, Color(1.0, 0.8, 0.25, 0.95))
		overlay.draw_circle(handle, 8.0 * App.ui_scale, Color(0.4, 0.9, 1.0, 0.95))

	var accent: Color = Color(0.15, 0.45, 0.9, 0.9)
	var w: float = 1.5 / maxf(view_zoom, 0.0001)

	if _shape_active and App.current_tool == App.Tool.FILL:
		var shape_rect: Rect2 = Rect2(_shape_a, _shape_b - _shape_a).abs()
		overlay.draw_rect(shape_rect, App.fill_ink, false, w * 1.5)
	elif _shape_active and App.shape_mode != App.Shape.FREE \
			and App.shape_mode != App.Shape.POLYLINE:
		var pts: PackedVector2Array = _shape_points()
		if pts.size() >= 2:
			overlay.draw_polyline(pts, accent, w)
	if App.shape_mode == App.Shape.POLYLINE and poly_points.size() > 0:
		if poly_points.size() >= 2:
			overlay.draw_polyline(_smooth_polyline(poly_points), accent, w)
		var point_radius: float = 6.0 / maxf(view_zoom, 0.0001)
		for point in poly_points:
			overlay.draw_circle(point, point_radius, Color(1.0, 1.0, 1.0, 0.95))
			overlay.draw_arc(point, point_radius, 0.0, TAU, 20, accent, w)

	# The live end of a chain, so you can see where the next line will start
	# from before you commit to drawing it. Without this the tool is guesswork
	# after the first line — you know a chain is running, but not from which
	# corner, and the two ends of a short segment are a thumb's width apart.
	if App.shape_mode == App.Shape.CHAIN and chain_live \
			and App.current_tool == App.Tool.SHAPE:
		var hold: float = 7.0 / maxf(view_zoom, 0.0001)
		overlay.draw_circle(chain_anchor, hold, Color(1.0, 1.0, 1.0, 0.92))
		overlay.draw_arc(chain_anchor, hold, 0.0, TAU, 22, accent, w * 1.4)

	_draw_marks(w)
	_draw_floating(w)

func _draw_marks(w: float) -> void:
	if _mark_points.size() < 2:
		return
	var mark: Color = Color(0.1, 0.1, 0.12, 0.9)
	var shape: int = App.select_shape
	var pts: PackedVector2Array = PackedVector2Array()
	if shape == App.SelectShape.RECT or shape == App.SelectShape.ELLIPSE:
		pts = _outline(shape == App.SelectShape.RECT, shape == App.SelectShape.ELLIPSE,
			false, false, _mark_points[0], _mark_points[1], PackedVector2Array())
	else:
		pts = _mark_points.duplicate()
		if pts.size() >= 3:
			pts.append(pts[0])
	if pts.size() >= 2:
		overlay.draw_polyline(pts, mark, w * 1.4)
		overlay.draw_polyline(pts, Color(1.0, 1.0, 1.0, 0.85), w * 0.6)
	if shape == App.SelectShape.POLY:
		var r: float = 5.0 / maxf(view_zoom, 0.0001)
		for p in _mark_points:
			overlay.draw_circle(p, r, Color(1.0, 1.0, 1.0, 0.95))
			overlay.draw_arc(p, r, 0.0, TAU, 16, mark, w)

func _draw_floating(w: float) -> void:
	if not sel_active or _sel_tex == null:
		return
	var c: Array = _sel_corners()
	var ring: PackedVector2Array = PackedVector2Array()
	for corner in c:
		ring.append(corner)
	ring.append(c[0])
	overlay.draw_polyline(ring, Color(0.1, 0.1, 0.12, 0.9), w * 1.4)
	overlay.draw_polyline(ring, Color(1.0, 1.0, 1.0, 0.9), w * 0.6)

	var hr: float = 9.0 / maxf(view_zoom, 0.0001)
	for corner in c:
		overlay.draw_circle(corner, hr, Color(1.0, 1.0, 1.0, 0.97))
		overlay.draw_arc(corner, hr, 0.0, TAU, 20, UiKit.ACCENT, w * 1.6)

	var rot: Vector2 = _rotate_handle()
	var top: Vector2 = ((c[0] as Vector2) + (c[1] as Vector2)) * 0.5
	overlay.draw_line(top, rot, Color(1.0, 1.0, 1.0, 0.8), w)
	overlay.draw_circle(rot, hr, Color(1.0, 1.0, 1.0, 0.97))
	overlay.draw_arc(rot, hr, 0.0, TAU, 20, UiKit.ACCENT, w * 1.6)
