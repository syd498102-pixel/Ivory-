class_name Vault
extends RefCounted
## Keeps work on disk so closing the app is not the same as losing it.
##
## Each project is a folder: one small text file describing the document —
## its size, colours, layers, folders, order — and one PNG per layer holding
## that layer's pixels, cropped to whatever it actually contains.
##
## Storing layers as ordinary PNGs rather than one private blob is a
## deliberate choice. It means the work is recoverable with a file browser
## even if this app is gone, which is the kind of promise a drawing program
## should be able to make.
##
## Saving happens on a timer, on closing a project, and when the app is
## about to quit. The timer only fires when something has actually changed,
## so a workspace being looked at rather than drawn on costs nothing.

const ROOT: String = "user://projects"
const MANIFEST: String = "project.json"
const INTERVAL: float = 25.0

static func _dir_of(id: int) -> String:
	return "%s/p%d" % [ROOT, id]

# ------------------------------------------------------------------ saving

## A project still being positioned is not yet a project. Writing one meant
## that a sheet conjured by opening the dialog and then abandoned came back
## on the next launch as something the user never made and could not place.
static func save(p: ProjectManager.Project) -> bool:
	if p == null or p.state == ProjectManager.State.FLOATING:
		return false
	var dir: String = _dir_of(p.id)
	DirAccess.make_dir_recursive_absolute(dir)

	var pages_out: Array = []
	for i in p.sheets.size():
		pages_out.append(_page_doc(p.sheets[i] as ProjectManager.Page, dir, i))

	var doc: Dictionary = {
		"version": 2,
		"id": p.id,
		"title": p.title,
		"kind": p.kind,
		"created": p.created,
		"origin_x": p.origin.x, "origin_y": p.origin.y,
		"page_w": p.page.x, "page_h": p.page.y,
		"pages": p.pages,
		"paper": p.paper.to_html(true),
		"frame": p.frame.to_html(true),
		"favourite": p.favourite,
		"grid_guide": p.grid_guide,
		"fps": p.fps, "frames": p.frames, "onion": p.onion_skin,
		"onion_back": p.onion_back, "onion_forward": p.onion_forward,
		"onion_back_tint": p.onion_back_tint.to_html(true),
		"onion_highlight": p.onion_highlight.to_html(true),
		"onion_forward_tint": p.onion_forward_tint.to_html(true),
		"looping": p.looping,
		"stacked": p.stacked,
		"active_page": p.active_page,
		"pages_data": pages_out,
	}

	# The manifest is the commit point. Keep the previous manifest as a recovery
	# copy, and only write it after every page/layer image has succeeded. If a
	# save is interrupted, the last known-good document can still be restored.
	var manifest_path: String = "%s/%s" % [dir, MANIFEST]
	var backup_path: String = "%s/%s.bak" % [dir, MANIFEST]
	if FileAccess.file_exists(manifest_path):
		var old: FileAccess = FileAccess.open(manifest_path, FileAccess.READ)
		if old != null:
			var old_bytes: PackedByteArray = old.get_buffer(old.get_length())
			old.close()
			var backup: FileAccess = FileAccess.open(backup_path, FileAccess.WRITE)
			if backup != null:
				backup.store_buffer(old_bytes)
				backup.close()

	var f: FileAccess = FileAccess.open(manifest_path, FileAccess.WRITE)
	if f == null:
		return false
	f.store_string(JSON.stringify(doc, "\t"))
	f.flush()
	f.close()
	return true

## One page written out: its layers as PNGs, its folders, its order.
static func _page_doc(page: ProjectManager.Page, dir: String, index: int) -> Dictionary:
	var rows: Array = []
	for l in page.stack.layers:
		var box: Rect2i = l.surface.content_bounds()
		var file: String = ""
		var at: Vector2i = Vector2i.ZERO
		if box.size.x > 0 and box.size.y > 0:
			var img: Image = l.surface.read_region(box)
			if img != null:
				file = "page%d_layer_%d.png" % [index, l.id]
				if img.save_png("%s/%s" % [dir, file]) != OK:
					file = ""
				else:
					at = box.position
		var row: Dictionary = {
			"id": l.id, "title": l.title, "group": l.group_id,
			"opacity": l.opacity, "visible": l.visible, "locked": l.locked,
			"background": l.is_background, "file": file, "glow": l.glow,
			"is_360": l.is_360, "turn_360": l.turn_360,
			"rig_360": l.rig_360.to_dict() if l.rig_360 != null else {},
			"x": at.x, "y": at.y,
		}
		if not l.cels.is_empty():
			row["cels"] = l.cels.to_dict()
		# The skeleton and the writing are part of the layer, not decoration
		# on top of it — a figure that has been rigged should still be rigged
		# tomorrow, and text should still be text rather than ink.
		if not l.rig.is_empty():
			row["rig"] = l.rig
		# The poses that rig takes over time. Written only when there are
		# any, so a file for an unrigged drawing carries no empty block —
		# and so a project made before this existed reads back unchanged.
		if l.poses != null and not l.poses.is_empty():
			row["poses"] = l.poses.to_dict()
		# The turnaround itself. Until now the file recorded that a layer
		# *was* a 360 layer and recorded which way it was facing, and threw
		# away the eight drawings that made it one — so the layer came back
		# flagged and empty, which is worse than not coming back at all.
		# The sync ring is thirty-two numbers and a centre. It is drawn once
		# by hand and would be tedious to draw again, so it is kept.
		if l.mouth_ring != null and l.mouth_ring.is_ready():
			row["mouth_ring"] = l.mouth_ring.to_dict()
		if l.character != null and l.character.count() > 0:
			var turn_doc: Dictionary = l.character.to_dict(dir,
				"page%d_char_%d" % [index, l.id])
			if not turn_doc.is_empty():
				row["character"] = turn_doc
		if l.is_text:
			row["text"] = true
			row["text_state"] = _text_to_doc(l.text_state)
		rows.append(row)
	var folders: Array = []
	for g in page.stack.groups:
		folders.append({
			"id": g.id, "title": g.title, "opacity": g.opacity,
			"visible": g.visible, "collapsed": g.collapsed,
			"animation": g.is_animation,
			"switch": g.is_switch, "switch_index": g.switch_index,
		})
	return {
		"layers": rows, "groups": folders,
		"active": page.stack.active_index,
		"clip": Anim.to_dict(page.clip),
	}

static func save_all(manager: ProjectManager) -> int:
	var n: int = 0
	for p in manager.projects:
		if save(p):
			n += 1
	return n

## Wipes every saved project. The way out when something on disk is not
## wanted and no amount of tapping will remove it.
static func forget_all() -> void:
	var root: DirAccess = DirAccess.open(ROOT)
	if root == null:
		return
	for folder in root.get_directories():
		_wipe("%s/%s" % [ROOT, folder])

## Folders on disk with no project in the workspace to match them. They are
## what a crash between writing and loading leaves behind.
static func orphan_count(manager: ProjectManager) -> int:
	var root: DirAccess = DirAccess.open(ROOT)
	if root == null:
		return 0
	var live: Dictionary = {}
	for p in manager.projects:
		live["p%d" % p.id] = true
	var n: int = 0
	for folder in root.get_directories():
		if not live.has(folder):
			n += 1
	return n

static func forget(id: int) -> void:
	var dir: String = _dir_of(id)
	var d: DirAccess = DirAccess.open(dir)
	if d == null:
		return
	for file in d.get_files():
		d.remove(file)
	DirAccess.remove_absolute(dir)

# ----------------------------------------------------------------- loading

## Folders whose project is not in the workspace. Left behind by the id
## renumbering above, and by any crash between writing and loading.
static func purge_orphans(manager: ProjectManager) -> int:
	var root: DirAccess = DirAccess.open(ROOT)
	if root == null:
		return 0
	var live: Dictionary = {}
	for p in manager.projects:
		live["p%d" % p.id] = true
	var gone: int = 0
	for folder in root.get_directories():
		if live.has(folder):
			continue
		# Never destroy an orphan automatically. A crash, interrupted copy, or
		# an older IVORY version can leave a perfectly recoverable project here.
		# Storage can report it and the user can explicitly forget it.
		gone += 1
	return gone

static func load_all(manager: ProjectManager) -> int:
	var root: DirAccess = DirAccess.open(ROOT)
	if root == null:
		return 0
	var count: int = 0
	for folder in root.get_directories():
		var dir: String = "%s/%s" % [ROOT, folder]
		# Loading is read-only. A malformed or interrupted project must never be
		# destroyed just because the app could not parse it on this launch.
		if _load_one(manager, dir):
			count += 1
	return count

static func _wipe(dir: String) -> void:
	var d: DirAccess = DirAccess.open(dir)
	if d == null:
		return
	for file in d.get_files():
		d.remove(file)
	DirAccess.remove_absolute(dir)

static func _load_one(manager: ProjectManager, dir: String) -> bool:
	var manifest_path: String = "%s/%s" % [dir, MANIFEST]
	var f: FileAccess = FileAccess.open(manifest_path, FileAccess.READ)
	var parsed: Variant = null
	if f != null:
		parsed = JSON.parse_string(f.get_as_text())
		f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		var backup_path: String = "%s/%s.bak" % [dir, MANIFEST]
		if FileAccess.file_exists(backup_path):
			var bf: FileAccess = FileAccess.open(backup_path, FileAccess.READ)
			if bf != null:
				parsed = JSON.parse_string(bf.get_as_text())
				bf.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return false
	var doc: Dictionary = parsed
	# A folder that does not describe a whole project is a leftover from an
	# interrupted write. Showing it as an empty sheet nobody can open is
	# worse than never showing it at all.
	var is_current: bool = doc.has("pages_data") and doc.has("page_w") and doc.has("page_h")
	var is_legacy: bool = doc.has("layers") and doc.has("page_w") and doc.has("page_h")
	if not is_current and not is_legacy:
		# If the live manifest is damaged, try the recovery copy before giving up.
		var bak_path: String = "%s/%s.bak" % [dir, MANIFEST]
		if FileAccess.file_exists(bak_path):
			var bf: FileAccess = FileAccess.open(bak_path, FileAccess.READ)
			if bf != null:
				var recovered: Variant = JSON.parse_string(bf.get_as_text())
				bf.close()
				if typeof(recovered) == TYPE_DICTIONARY:
					doc = recovered
					is_current = doc.has("pages_data") and doc.has("page_w") and doc.has("page_h")
					is_legacy = doc.has("layers") and doc.has("page_w") and doc.has("page_h")
		if not is_current and not is_legacy:
			return false
	if float(doc.get("page_w", 0.0)) < 8.0 or float(doc.get("page_h", 0.0)) < 8.0:
		return false

	# The saved id comes back with the project. Without this, `create` handed
	# out a fresh one on every launch: the folder on disk kept its old name,
	# the next save wrote a *new* folder beside it, and the workspace filled
	# with copies until it hit its ceiling and refused to make anything.
	# Deleting removed the new folder and left the original, so the project
	# came back the next time. One line, and all three symptoms.
	var saved_id: int = int(doc.get("id", 0))
	if saved_id > 0 and manager.holds_id(saved_id):
		return false

	var p: ProjectManager.Project = manager.create(
		String(doc.get("title", "")),
		int(doc.get("kind", 0)),
		Vector2(float(doc.get("page_w", 1600.0)), float(doc.get("page_h", 1200.0))),
		Color(String(doc.get("paper", "#ffffffff"))),
		int(doc.get("pages", 1)),
		Vector2.ZERO)
	if p == null:
		return false

	if saved_id > 0:
		manager.reclaim_id(p, saved_id)
	p.created = String(doc.get("created", p.created))
	# Straight from the file, deliberately bypassing the tidy-up that
	# placing a new project does: a saved sheet belongs exactly where it was
	# left, even if that happens to be beside another one.
	p.origin = Vector2(float(doc.get("origin_x", 0.0)), float(doc.get("origin_y", 0.0)))
	p.frame = Color(String(doc.get("frame", "#1b1c22ff")))
	p.favourite = bool(doc.get("favourite", false))
	p.grid_guide = bool(doc.get("grid_guide", false))
	p.fps = int(doc.get("fps", 24))
	p.frames = int(doc.get("frames", 24))
	p.onion_skin = bool(doc.get("onion", true))
	p.onion_back = clampi(int(doc.get("onion_back", 2)), 0, 8)
	p.onion_forward = clampi(int(doc.get("onion_forward", 1)), 0, 8)
	var onion_back_hex: String = String(doc.get("onion_back_tint", "e65a5a56"))
	var onion_mid_hex: String = String(doc.get("onion_highlight", "ffcc5556"))
	var onion_forward_hex: String = String(doc.get("onion_forward_tint", "598ce04d"))
	p.onion_back_tint = Color(onion_back_hex if onion_back_hex.begins_with("#") else "#" + onion_back_hex)
	p.onion_highlight = Color(onion_mid_hex if onion_mid_hex.begins_with("#") else "#" + onion_mid_hex)
	p.onion_forward_tint = Color(onion_forward_hex if onion_forward_hex.begins_with("#") else "#" + onion_forward_hex)
	p.looping = bool(doc.get("looping", true))

	p.stacked = bool(doc.get("stacked", false))
	var pages_in: Array = doc.get("pages_data", [])
	if pages_in.is_empty():
		# Written before pages had their own layers: the one stack it holds
		# belongs to page one, and the rest come back blank.
		_fill_page(p.page_at(0), dir, doc)
	else:
		for i in mini(pages_in.size(), p.sheets.size()):
			_fill_page(p.page_at(i), dir, pages_in[i])
	manager.set_page(p, int(doc.get("active_page", 0)))

	# Everything comes back closed. Waking every project at startup would
	# hand the graphics card a workspace's worth of tiles before the user
	# has decided which one they want.
	p.state = ProjectManager.State.CLOSED
	if manager.placing == p:
		manager.placing = null
	for page in p.sheets:
		for l in (page as ProjectManager.Page).stack.layers:
			l.surface.sleep_all()
	manager.move_to(p, p.origin)
	return true

static func _fill_page(page: ProjectManager.Page, dir: String,
		doc: Dictionary) -> void:
	if page == null:
		return
	var rows: Array = doc.get("layers", [])
	if rows.is_empty():
		return

	# The stack always starts with a background and one empty layer; grow or
	# trim it to the saved count before filling anything in.
	while page.stack.layers.size() < rows.size():
		if page.stack.add_layer() == null:
			break
	while page.stack.layers.size() > rows.size() and page.stack.layers.size() > 1:
		page.stack.remove_layer(page.stack.layers.size() - 1)

	for i in rows.size():
		if i >= page.stack.layers.size():
			break
		var row: Dictionary = rows[i]
		var l: LayerStack.Layer = page.stack.layers[i]
		l.title = String(row.get("title", l.title))
		l.opacity = float(row.get("opacity", 1.0))
		l.visible = bool(row.get("visible", true))
		l.locked = bool(row.get("locked", false))
		l.is_background = bool(row.get("background", i == 0))
		l.glow = bool(row.get("glow", false))
		l.is_360 = bool(row.get("is_360", false))
		l.turn_360 = float(row.get("turn_360", 0.0))
		if row.has("mouth_ring"):
			l.mouth_ring = MouthRing.from_dict(row["mouth_ring"])
		if row.has("character"):
			l.character = Character360.from_dict(row["character"], dir)
		var rig_doc: Dictionary = row.get("rig_360", {})
		if not rig_doc.is_empty():
			l.rig_360 = Rig360.from_dict(rig_doc)
		l.rig = row.get("rig", {})
		if row.has("poses"):
			l.poses = RigTrack.from_dict(row["poses"])
		l.is_text = bool(row.get("text", false))
		l.text_state = _text_from_doc(row.get("text_state", {}))

		if row.has("cels"):
			l.cels.from_dict(row["cels"])

		var file: String = String(row.get("file", ""))
		if file == "":
			continue
		var img: Image = Image.new()
		if img.load("%s/%s" % [dir, file]) != OK:
			continue
		if img.get_format() != Image.FORMAT_RGBA8:
			img.convert(Image.FORMAT_RGBA8)
		# Written premultiplied, restored premultiplied, copied rather than
		# blended — so the trip through disk changes nothing at all.
		l.surface.blit_image(img,
			Vector2(float(row.get("x", 0)), float(row.get("y", 0))), true)

	# Folders last: each is rebuilt around its lowest saved member, then the
	# rest are pointed at the folder that member created.
	for row in doc.get("groups", []):
		var gid: int = int(row["id"])
		var first: int = -1
		for i in rows.size():
			if int(rows[i].get("group", 0)) == gid and i < page.stack.layers.size():
				first = i
				break
		if first < 0:
			continue
		var g: LayerStack.Group = page.stack.group_layer(first)
		if g == null:
			continue
		g.title = String(row.get("title", g.title))
		g.opacity = float(row.get("opacity", 1.0))
		g.visible = bool(row.get("visible", true))
		g.collapsed = bool(row.get("collapsed", false))
		# Defaulted, never required. A project saved before charts existed
		# has no such key, and every folder in it is an ordinary folder —
		# which is exactly what `false` says.
		g.is_switch = bool(row.get("switch", false))
		g.switch_index = maxi(int(row.get("switch_index", 0)), 0)
		g.is_animation = bool(row.get("animation", false))
		for i in rows.size():
			if i < page.stack.layers.size() and int(rows[i].get("group", 0)) == gid:
				page.stack.layers[i].group_id = g.id

	if doc.has("clip"):
		page.clip = Anim.from_dict(doc["clip"])
	page.stack.apply_arrangement(page.stack.capture_arrangement())
	page.stack.set_active(clampi(int(doc.get("active", 1)), 0,
		maxi(page.stack.layers.size() - 1, 0)))
	page.history.clear()


## Colours do not survive a trip through JSON as colours, so the two in a text
## layer's settings are written as strings and read back as colours. Anything
## else in there is already a number or a word and passes through untouched.
static func _text_to_doc(state: Dictionary) -> Dictionary:
	var out: Dictionary = {}
	for key in state.keys():
		var value: Variant = state[key]
		if value is Color:
			out[key] = (value as Color).to_html(true)
		else:
			out[key] = value
	return out

static func _text_from_doc(doc: Dictionary) -> Dictionary:
	var out: Dictionary = {}
	for key in doc.keys():
		var value: Variant = doc[key]
		if (key == "colour" or key == "halo_colour") and value is String:
			out[key] = Color(String(value))
		else:
			out[key] = value
	return out
