class_name StrokeSmoother
extends RefCounted
## Takes the shake out of a stroke without letting it trail the finger.
##
## A plain averaging filter has one dial, and that dial trades one fault for
## the other: smooth enough to kill the jitter of a slow line is also slow
## enough to lag a fast one. Which is exactly what "the line does not sit
## under my finger" feels like.
##
## The one-euro filter fixes that by making the smoothing depend on speed.
## Move slowly — where jitter is visible and lag is not — and it smooths
## hard. Move quickly — where lag is glaring and jitter invisible — and it
## almost stops filtering. The result follows the finger and still draws a
## clean line, instead of choosing between the two.

const MIN_CUTOFF: float = 1.4    # Hz — smoothing when the hand is still
const BETA: float = 0.028        # how fast speed loosens the filter
const D_CUTOFF: float = 1.0      # smoothing applied to the speed estimate

var _ready_yet: bool = false
var _prev: Vector2 = Vector2.ZERO
var _speed: Vector2 = Vector2.ZERO
var _last_ms: int = 0

func reset(at: Vector2) -> void:
	_ready_yet = true
	_prev = at
	_speed = Vector2.ZERO
	_last_ms = Time.get_ticks_msec()

func filter(raw: Vector2) -> Vector2:
	if not _ready_yet:
		reset(raw)
		return raw

	var now: int = Time.get_ticks_msec()
	var dt: float = float(now - _last_ms) / 1000.0
	_last_ms = now
	# A stalled or duplicated event must not divide by nothing.
	dt = clampf(dt, 1.0 / 240.0, 1.0 / 20.0)

	var raw_speed: Vector2 = (raw - _prev) / dt
	_speed = _lerp_to(_speed, raw_speed, _alpha(D_CUTOFF, dt))

	var pace: float = _speed.length()
	var cutoff: float = MIN_CUTOFF + BETA * pace
	_prev = _lerp_to(_prev, raw, _alpha(cutoff, dt))
	return _prev

## Turns a cutoff frequency and a time step into a blend weight.
func _alpha(cutoff: float, dt: float) -> float:
	var tau: float = 1.0 / (TAU * maxf(cutoff, 0.001))
	return clampf(1.0 / (1.0 + tau / dt), 0.0, 1.0)

func _lerp_to(from: Vector2, to: Vector2, a: float) -> Vector2:
	return from + (to - from) * a
