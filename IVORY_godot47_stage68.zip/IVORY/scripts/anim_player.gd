class_name AnimPlayer
extends Node
## Drives the animation clock independently from the render clock.
##
## The playhead is continuous so camera keys can interpolate smoothly, while
## raster cels are sampled only when the displayed frame actually changes.
## This avoids reloading/compressing the same cel on every rendered frame.

signal frame_changed(frame: float)
signal frame_index_changed(frame: int)
signal playing_changed(on: bool)
signal camera_moved(offset: Vector2, zoom: float, rotation: float)
## A layer's rig wants putting into a new pose. Emitted with the blended pose
## rather than with a frame number, so whoever is holding that layer's mesh —
## the B-Spline room, the 360 room, or the canvas — does the skinning, and
## this class stays what it says it is: a clock, not a renderer.
signal rig_posed(layer_id: int, pose: Dictionary)

## Strong, flat, and opposite each other on the wheel. A ghost has to be
## told apart from the ink underneath it at a glance and from the ghost on
## the other side of the playhead just as fast, so the two defaults are a
## complementary pair rather than two tints of the same idea.
const ONION_BACK: Color = Color(0.94, 0.16, 0.26, 0.52)
const ONION_FORWARD: Color = Color(0.10, 0.72, 0.94, 0.50)
const FRAME_EPSILON: float = 0.000001

var clip: Anim.Clip = null
var stack: LayerStack = null

var frame: float = 0.0
var playing: bool = false
var looping: bool = true

var onion: bool = false
var onion_back: int = 2
var onion_forward: int = 1
var onion_back_tint: Color = ONION_BACK
var onion_forward_tint: Color = ONION_FORWARD
## Kept so older saved projects still load and still round-trip, but no
## longer painted with: the two chosen colours are the whole scheme.
var onion_highlight_tint: Color = Color(1.0, 0.78, 0.22, 0.42)

var _ghosts: Node2D = null
var _shown_frame: int = -1
var _onion_signature: int = 0
var _last_camera_offset: Vector2 = Vector2.INF
var _last_camera_zoom: float = -1.0
var _last_camera_rotation: float = 999.0
## Counts frames so the mesh solve can be rationed on a slow device without
## rationing the clock. See `_pose_rigs`.
var _solve_beat: int = 0

func _last_frame() -> int:
	return maxi((clip.length if clip != null else 1) - 1, 0)

func _ready() -> void:
	set_process(true)

func bind(new_clip: Anim.Clip, new_stack: LayerStack) -> void:
	stop()
	clip = new_clip
	stack = new_stack
	frame = 0.0
	_shown_frame = -1
	_onion_signature = 0
	_last_camera_offset = Vector2.INF
	_last_camera_zoom = -1.0
	_last_camera_rotation = 999.0
	_clear_ghosts()
	apply(true, true)

func refresh_visuals() -> void:
	if clip == null or stack == null:
		return
	_onion_signature = 0
	apply(true, false)

func _process(delta: float) -> void:
	if not playing or clip == null:
		return

	var fps: float = float(maxi(clip.fps, 1))
	# Playback runs inside the chosen range, not from nought to the end of
	# everything. Watching a six-frame action in the middle of a long scene
	# should not mean sitting through everything in front of it first.
	var span: Vector2i = clip.play_span(stack)
	var start: float = float(span.x)
	var end: float = float(span.y) + 1.0
	if frame < start - 0.001 or frame > end:
		frame = start
	frame += delta * fps

	if frame >= end:
		if looping:
			var run: float = maxf(end - start, 0.001)
			frame = start + fmod(frame - start, run)
		else:
			frame = maxf(end - 1.0, start)
			playing = false
			playing_changed.emit(false)

	# During playback the current cel was committed before play started.
	# Switching cels therefore never performs a CPU readback/compression pass.
	apply(false, false)
	frame_changed.emit(frame)

# ------------------------------------------------------------- transport

func play() -> void:
	if clip == null or playing:
		return
	if stack != null:
		stack.commit_all_cels()
	playing = true
	playing_changed.emit(true)
	apply(false, false)

func stop() -> void:
	if not playing:
		return
	playing = false
	playing_changed.emit(false)

func toggle() -> void:
	if playing:
		stop()
	else:
		play()

func seek(to: float) -> void:
	if clip == null:
		return
	var end: float = float(_last_frame())
	frame = clampf(to, 0.0, end)
	# A manual seek can happen immediately after drawing, so write the current
	# cel back before replacing the live surface.
	apply(true, true)
	frame_changed.emit(frame)

func step(by: int) -> void:
	if clip == null or stack == null:
		return
	var current: int = clampi(int(floor(frame + FRAME_EPSILON)), 0, maxi(clip.length - 1, 0))
	if by == 0:
		return

	if by > 0:
		# Next moves. It only makes a frame when there is nothing ahead to
		# move to.
		#
		# It used to ask whether the destination held a cel of its own, and
		# make a blank one whenever it did not — so walking forward through a
		# scene laid a trail of empty frames between the drawings already
		# there. Two things count as "something ahead": a drawing holding
		# through the destination, and any drawing further along the layer.
		# Only past the last of them is Next also the thing that adds one.
		var target: int = current + 1
		if target >= clip.length:
			clip.grow_to_fit(stack, target)
		# A rigged layer is animated by posing, so Next only ever walks here.
		var waiting: bool = _something_ahead(current) \
			or (stack != null and stack.active_frames_locked())
		if not waiting:
			_ensure_editable_frame(target)
			# Entering a newly made blank frame shows the drawing before it
			# through onion skin. The drawing itself is never copied.
			if _has_editable_frame(current):
				onion = true
				onion_back = maxi(onion_back, 1)
		_onion_signature = 0
		seek(float(target))
		return

	# Previous never invents, inserts, or duplicates a cel. It simply moves to
	# the existing previous frame position.
	var target_back: int = maxi(current - 1, 0)
	if target_back != current:
		seek(float(target_back))

## Whether the layer still has drawing after this moment — either one holding
## through the next frame, or one waiting further along.
func _something_ahead(current: int) -> bool:
	if stack == null or stack.layers.is_empty():
		return false
	var index: int = clampi(stack.active_index, 0, stack.layers.size() - 1)
	var track: CelTrack = stack.layers[index].cels
	if track.is_empty():
		return false
	if track.frame_showing(current + 1) >= 0:
		return true
	for f in track.frames():
		if int(f) > current:
			return true
	return false

func _has_editable_frame(at: int) -> bool:
	if stack == null or stack.layers.is_empty():
		return false
	var index: int = clampi(stack.active_index, 0, stack.layers.size() - 1)
	return stack.layers[index].cels.has_frame(at)

func _ensure_editable_frame(at: int) -> void:
	if stack == null or stack.layers.is_empty():
		return
	var index: int = clampi(stack.active_index, 0, stack.layers.size() - 1)
	var layer: LayerStack.Layer = stack.layers[index]
	if layer.cels.has_frame(at):
		if layer.cels.loaded != at:
			layer.cels.load_into(layer.surface, at)
		return
	if layer.cels.is_empty():
		layer.cels.capture_surface(layer.surface, 0)
		if at == 0:
			layer.cels.load_into(layer.surface, 0)
			return
	layer.cels.add_frame(layer.surface, at, false)

func ensure_editable_for_stroke() -> void:
	if clip == null or stack == null:
		return
	var at: int = clampi(int(floor(frame + FRAME_EPSILON)), 0, _last_frame())
	_ensure_editable_frame(at)
	if at > 0 and stack.active() != null and stack.active().cels.frame_showing(at - 1) >= 0:
		onion = true
		_onion_signature = 0
		_update_onion(at)

## Lands on the nearest actual drawing rather than walking through holds.
func step_to_drawing(way: int) -> void:
	if stack == null:
		return
	var here: int = int(floor(frame + FRAME_EPSILON))
	var best: int = -1
	for l in stack.layers:
		for f in l.cels.frames():
			var one: int = int(f)
			if way > 0 and one > here and (best < 0 or one < best):
				best = one
			elif way < 0 and one < here and (best < 0 or one > best):
				best = one
	if best >= 0:
		seek(float(best))

# ---------------------------------------------------------------- showing

## Updates raster content only when the integer display frame changes, while
## camera interpolation remains continuous at the render rate.
func apply(force: bool = false, write_back: bool = true) -> void:
	if clip == null or stack == null:
		return

	var shown: int = clampi(int(floor(frame + FRAME_EPSILON)), 0,
		_last_frame())
	if force or shown != _shown_frame:
		stack.show_frame(shown, write_back)
		_shown_frame = shown
		_update_onion(shown)
		frame_index_changed.emit(shown)

	_pose_rigs(shown, force)

	var eye: Dictionary = clip.camera_at(frame)
	if not eye.is_empty():
		var offset: Vector2 = eye["offset"]
		var zoom: float = float(eye["zoom"])
		var rotation: float = float(eye.get("rotation", 0.0))
		if force or offset.distance_squared_to(_last_camera_offset) > 0.000001 \
				or absf(zoom - _last_camera_zoom) > 0.000001 \
				or absf(rotation - _last_camera_rotation) > 0.000001:
			_last_camera_offset = offset
			_last_camera_zoom = zoom
			_last_camera_rotation = rotation
			camera_moved.emit(offset, zoom, rotation)

## Puts every rigged layer into the pose its own track asks for, and every
## switch folder onto the member the clip asks for.
##
## Two different costs, handled differently, and the difference is the whole
## reason this reads the way it does.
##
## **Switching is free.** It is one integer compare per folder and a
## visibility flag. It runs on every frame on every device, always, because a
## mouth that changes shape a frame late is a mouth that is out of sync — and
## there is nothing to gain by delaying something this cheap.
##
## **Posing is not free.** Reading the pose is: a handful of floats blended,
## and that also runs every frame everywhere, so the *timing* of an animation
## is identical on every device and a scene checked on a tablet plays at the
## same speed on a phone. But pushing that pose through a mesh — every vertex
## re-weighted and re-uploaded — is the expensive half, and on a slow device
## it is emitted only every second or third frame.
##
## The result is an animation that holds a pose for a frame at a time rather
## than one that plays slowly. That is the right way round: a viewer forgives
## a held pose and does not forgive a scene running at half speed.
func _pose_rigs(shown: int, force: bool) -> void:
	# --- charts, every frame ---
	for g in stack.groups:
		var folder: LayerStack.Group = g
		if not folder.is_switch:
			continue
		var want: int = clip.swap_at(folder.id, shown, folder.switch_index)
		if want != folder.switch_index:
			# Quietly while playing: the drawing changes, the layers panel is
			# not rebuilt several times a second to redraw rows nobody is
			# watching during playback.
			stack.set_switch_index(folder.id, want, not playing)

	# --- poses, rationed ---
	_solve_beat += 1
	var stride: int = maxi(Perf.rig_solve_stride(), 1)
	if not force and playing and _solve_beat % stride != 0:
		return
	for l in stack.layers:
		var one: LayerStack.Layer = l
		if one.poses == null or one.poses.is_empty():
			continue
		var pose: Dictionary = one.poses.pose_at(frame)
		if pose.is_empty():
			continue
		# A turnaround can be posed from here without anybody else being
		# involved: the angle lives on the layer and the room reads it.
		if pose.has("turn"):
			one.turn_360 = float(pose["turn"])
		if one.rig_360 != null and pose.has("along"):
			RigTrack.lay_rig360(one.rig_360, pose["along"])
		rig_posed.emit(one.id, pose)

func _update_onion(shown: int) -> void:
	var back: int = clampi(onion_back, 0, 8)
	var ahead: int = clampi(onion_forward, 0, 8)
	var signature: int = hash([onion, back, ahead,
		onion_back_tint, onion_forward_tint, onion_highlight_tint, shown])
	if signature == _onion_signature:
		return
	_onion_signature = signature
	_lay_onion(shown)

func _clear_ghosts() -> void:
	if _ghosts != null:
		_ghosts.queue_free()
		_ghosts = null

func _lay_onion(here: int) -> void:
	_clear_ghosts()
	if not onion or stack == null:
		return
	var back: int = clampi(onion_back, 0, 8)
	var ahead: int = clampi(onion_forward, 0, 8)
	if back == 0 and ahead == 0:
		return

	_ghosts = Node2D.new()
	_ghosts.name = "Onion"
	_ghosts.z_index = 5
	stack.add_child(_ghosts)

	# Behind is one colour and ahead is another, all the way out. The
	# nearest drawing on each side is the strongest, not a third colour:
	# a hue that appeared only on the closest frame meant the two colours
	# the user actually chose were the two they could never see.
	for step_back in range(1, back + 1):
		_ghost_at(here - step_back, onion_back_tint, step_back, back, here)
	for step_on in range(1, ahead + 1):
		_ghost_at(here + step_on, onion_forward_tint, step_on, ahead, here)

func _ghost_at(at: int, tint: Color, step_away: int, span: int,
		home: int) -> void:
	if at < 0 or _ghosts == null:
		return
	# The nearest drawing is at full strength and each one further out is
	# weaker, so a run of ghosts reads as a direction rather than a smudge.
	var fade: float = 1.0 - (float(step_away - 1) /
		float(maxi(span, 1))) * 0.62
	fade = clampf(fade, 0.22, 1.0)
	for l in stack.layers:
		if not l.visible or l.cels.is_empty():
			continue
		var which: int = l.cels.frame_showing(at)
		var current: int = l.cels.frame_showing(home)
		if which < 0 or which == current:
			continue
		var img: Image = l.cels.image_of(which)
		if img == null:
			continue
		var ghost: Sprite2D = Sprite2D.new()
		ghost.centered = false
		ghost.position = Vector2(l.cels.origin_of(which))
		ghost.texture = ImageTexture.create_from_image(img)
		ghost.material = PaintSurface.premultiplied_material()
		var ink: Color = Color(tint.r, tint.g, tint.b, tint.a * fade)
		ghost.modulate = Color(ink.r * ink.a, ink.g * ink.a, ink.b * ink.a, ink.a)
		_ghosts.add_child(ghost)
