class_name Rig360
extends RefCounted
## The rig that lives on a turnaround: joints, bones, rings and movement bars.

## ## The three kinds of joint
##
## They are a family, and the words are the relationship rather than a
## decoration:
##
##   * **child** (amber) — a bend. Knuckles, a knee, the middle of a tail.
##     It never moves anything itself; it is what gets moved.
##   * **parent** (red) — the one a hand actually drags. It carries the
##     children joined below it, and it is the only kind that owns a movement
##     bar, because it is the only kind anybody pulls.
##   * **grandparent** (green) — the strongest. It does not move the drawing
##     directly; it moves the *parents* hanging from it. Pull a green and the
##     reds go with it, and their children follow them.
##
## So a finger is three ambers and a red at the tip; an arm is a green at the
## shoulder with reds down it. The chain is built by joining them in Connect,
## and the line drawn between two joined joints is a guide and nothing else —
## it says where the bend is, it is never exported, and it is not a bone.
##
## ## Why a movement bar
##
## A joint that simply follows the finger gives every part of a figure the
## same loose, floating feel. Real motion has a *shape*: a finger curls along
## an arc, an elbow swings through one plane, a jaw opens on a hinge. The bar
## is the user drawing that shape once, and afterwards the finger is measured
## **along** it rather than followed. Drag anywhere and the part moves the way
## it was told it moves — which is why a rig built here holds up when somebody
## other than its author animates with it.
##
## The inverse bar is the same gesture read backwards, so one joint can carry
## both directions of a movement without a second joint fighting it.

enum Kind { CHILD, PARENT, GRANDPARENT }
enum RingKind { PURPLE, TIFFANY, WHITE }
enum Axis { VERTICAL, HORIZONTAL }

const AMBER: Color = Color("#E8A33C")
const RED: Color = Color("#D8453C")
const GREEN: Color = Color("#3FBF6A")
const PURPLE: Color = Color("#9B5FD0")
const TIFFANY: Color = Color("#3FC8C0")
const WHITE_RING: Color = Color("#F4EFE4")
## Ivory. Warm, near-white, and the only thing in the room drawn in it — a
## bone should be recognisable at a glance across a busy figure.
const BONE_INK: Color = Color("#F3E4C0")
const BONE_CORE: Color = Color("#FFF8E7")
const BONE_EDGE: Color = Color("#8A7C58")

class Joint extends RefCounted:
	var kind: int = Kind.CHILD
	var rest: Vector2 = Vector2.ZERO
	var now: Vector2 = Vector2.ZERO
	## The joint this one hangs from — set in Connect, never guessed.
	var parent: int = -1
	## Only a red carries these. `bar` is the shape of the movement; `mirror`
	## is the same movement read the other way.
	var bar: PackedVector2Array = PackedVector2Array()
	var mirror: PackedVector2Array = PackedVector2Array()
	## How far along its bar this joint currently is, -1 to 1.
	var along: float = 0.0

## The big joints: an elbow, a knee, an ankle, a shoulder.
##
## These are not points. A knuckle is a place where a line bends and a point
## describes it exactly; an elbow is a *limb* with a length that must not
## change, and the thing that keeps a length is a bone. Using points for both
## would mean either forearms that stretch or fingers that need a bone each.
##
## A bone carries a grip at both ends, because either end can be the one that
## stays: swing the forearm from the wrist and the elbow holds; swing it from
## the elbow and the wrist holds.
class Bone extends RefCounted:
	var rest_a: Vector2 = Vector2.ZERO
	var rest_b: Vector2 = Vector2.ZERO
	var a: Vector2 = Vector2.ZERO
	var b: Vector2 = Vector2.ZERO
	## How each end bends. Set in Connect by tapping the end itself.
	##   FREE   turns wherever it is taken
	##   RIGHT  quarter turns only — an elbow reaching its stop
	var bend_a: int = Bend.FREE
	var bend_b: int = Bend.FREE
	## Which pose this bone was laid on, and how tall the figure was then.
	## A turnaround is eight drawings and they do not all put the shoulder at
	## the same height; keeping this lets the bone ride with the figure as it
	## turns instead of hanging in the air where it was drawn.
	var built_on: int = 0
	var built_height: float = 0.0
	## Where the bone currently sits relative to where it was laid, once the
	## turn has been taken into account.
	var carry: Vector2 = Vector2.ZERO

enum Bend { FREE, RIGHT }

class Ring extends RefCounted:
	var kind: int = RingKind.PURPLE
	var centre: Vector2 = Vector2.ZERO
	var radius: float = 40.0
	var axis: int = Axis.VERTICAL
	## A dead ring holds and never turns. It disappears once it is marked so,
	## because a pin that is doing its job silently should not be in the way —
	## but its hold is still in force, and it can be brought back to be seen
	## or removed.
	var live: bool = true
	var turn: float = 0.0

var joints: Array = []
var bones: Array = []
var rings: Array = []

# ------------------------------------------------------------------ joints

func add_joint(kind: int, at: Vector2) -> int:
	var j: Joint = Joint.new()
	j.kind = kind
	j.rest = at
	j.now = at
	joints.append(j)
	return joints.size() - 1

func joint_at(at: Vector2, reach: float) -> int:
	var best: int = -1
	var best_d: float = reach * reach
	for i in joints.size():
		var d: float = at.distance_squared_to((joints[i] as Joint).now)
		if d <= best_d:
			best_d = d
			best = i
	return best

## Joining two joints.
##
## The rule is the family: a child hangs from a parent, a parent hangs from a
## grandparent. Joining the other way round would let a knuckle drag a
## shoulder, so it is refused rather than quietly reversed — a rig that
## silently rearranges what it was told is a rig nobody can reason about.
func connect_joints(lower: int, upper: int) -> bool:
	if lower < 0 or upper < 0 or lower == upper:
		return false
	if lower >= joints.size() or upper >= joints.size():
		return false
	var a: Joint = joints[lower] as Joint
	var b: Joint = joints[upper] as Joint
	if b.kind <= a.kind:
		return false
	if _would_loop(lower, upper):
		return false
	a.parent = upper
	return true

## A chain that eventually reaches back to itself has no top, and solving it
## would run forever.
func _would_loop(lower: int, upper: int) -> bool:
	var walk: int = upper
	var guard: int = 0
	while walk >= 0 and guard < joints.size() + 2:
		if walk == lower:
			return true
		walk = (joints[walk] as Joint).parent
		guard += 1
	return false

func children_of(index: int) -> Array:
	var out: Array = []
	for i in joints.size():
		if (joints[i] as Joint).parent == index:
			out.append(i)
	return out

func remove_joint(index: int) -> void:
	if index < 0 or index >= joints.size():
		return
	joints.remove_at(index)
	for j in joints:
		var one: Joint = j as Joint
		if one.parent == index:
			one.parent = -1
		elif one.parent > index:
			one.parent -= 1

# ------------------------------------------------------------ movement bars

## The shape a joint's movement follows, in the joint's own space.
func set_bar(index: int, path: PackedVector2Array, inverse: bool) -> void:
	if index < 0 or index >= joints.size():
		return
	var j: Joint = joints[index] as Joint
	if j.kind != Kind.PARENT:
		return
	var local: PackedVector2Array = PackedVector2Array()
	for p in path:
		local.append(p - j.rest)
	if inverse:
		j.mirror = local
	else:
		j.bar = local

func has_bar(index: int) -> bool:
	if index < 0 or index >= joints.size():
		return false
	return not (joints[index] as Joint).bar.is_empty()

## How far along its bar a finger has reached, -1 to 1.
##
## The finger is projected onto the bar rather than followed. The nearest
## point on the shape is found, and how far along the shape that point sits is
## the answer — so a hand that wanders off the line still drives the movement
## cleanly, and a hand that follows the line exactly drives it precisely.
func read_bar(index: int, finger: Vector2) -> float:
	if index < 0 or index >= joints.size():
		return 0.0
	var j: Joint = joints[index] as Joint
	var pick: float = _walk_bar(j.bar, j.rest, finger)
	if j.mirror.is_empty():
		return pick
	var back: float = _walk_bar(j.mirror, j.rest, finger)
	# Whichever bar the finger is nearer is the one it means.
	var d_bar: float = _away_from_bar(j.bar, j.rest, finger)
	var d_mirror: float = _away_from_bar(j.mirror, j.rest, finger)
	if d_mirror < d_bar:
		return -back
	return pick

func _walk_bar(bar: PackedVector2Array, origin: Vector2,
		finger: Vector2) -> float:
	if bar.size() < 2:
		return 0.0
	var run: float = 0.0
	var lengths: PackedFloat32Array = PackedFloat32Array()
	lengths.append(0.0)
	for i in range(1, bar.size()):
		run += bar[i].distance_to(bar[i - 1])
		lengths.append(run)
	if run <= 0.001:
		return 0.0
	var best: float = 0.0
	var best_d: float = INF
	for i in range(1, bar.size()):
		var a: Vector2 = origin + bar[i - 1]
		var b: Vector2 = origin + bar[i]
		var ab: Vector2 = b - a
		var len2: float = ab.length_squared()
		var t: float = 0.0 if len2 < 0.000001 \
			else clampf((finger - a).dot(ab) / len2, 0.0, 1.0)
		var on: Vector2 = a + ab * t
		var d: float = finger.distance_squared_to(on)
		if d < best_d:
			best_d = d
			best = (lengths[i - 1] + ab.length() * t) / run
	return clampf(best, 0.0, 1.0)

func _away_from_bar(bar: PackedVector2Array, origin: Vector2,
		finger: Vector2) -> float:
	if bar.size() < 2:
		return INF
	var best: float = INF
	for i in range(1, bar.size()):
		var a: Vector2 = origin + bar[i - 1]
		var b: Vector2 = origin + bar[i]
		var ab: Vector2 = b - a
		var len2: float = ab.length_squared()
		var t: float = 0.0 if len2 < 0.000001 \
			else clampf((finger - a).dot(ab) / len2, 0.0, 1.0)
		best = minf(best, finger.distance_squared_to(a + ab * t))
	return best

# ------------------------------------------------------------------- posing

## Bends a chain by however far along its bar it has been taken.
##
## The chain turns about the joint above it, and each joint further down turns
## a little more — which is what a finger curling does, and what a joint that
## simply translated could never look like. Lengths never change: the distance
## between two joined joints is fixed at rest and kept, so a limb driven here
## cannot stretch.
func drive(index: int, amount: float) -> void:
	if index < 0 or index >= joints.size():
		return
	var j: Joint = joints[index] as Joint
	j.along = clampf(amount, -1.0, 1.0)
	_settle()

## Works the whole figure out from the `along` values it currently holds.
##
## Public because playback writes `along` straight onto the joints — that is
## the entire content of a Rig360 key — and then needs the rest of the figure
## brought into agreement with it.
func settle() -> void:
	_settle()

## Everything worked out from rest, every time. Absolute rather than
## incremental, so returning a joint to nought returns the figure exactly.
func _settle() -> void:
	# Tops first, so a chain is solved from the shoulder down and a child is
	# never placed against a parent that has not moved yet.
	for i in joints.size():
		if (joints[i] as Joint).parent < 0:
			_settle_from(i, 0.0, Vector2.ZERO, Vector2.ZERO, false)

## Each joint is placed **relative to its parent**, by taking the offset it
## had at rest and turning it.
##
## The first attempt rotated each joint's rest position about wherever its
## parent had moved to, and that quietly stretched the chain: the further
## down a finger you went, the longer the segments became — the last one grew
## from forty units to a hundred and twelve on a single bend. Turning the
## *offset* and adding it to the parent's new position keeps every segment at
## exactly the length it was drawn at, however far the chain is bent and
## however many joints deep it runs.
func _settle_from(index: int, carried: float, parent_now: Vector2,
		parent_rest: Vector2, has_parent: bool) -> void:
	var j: Joint = joints[index] as Joint
	if has_parent:
		j.now = parent_now + (j.rest - parent_rest).rotated(carried)
	else:
		j.now = j.rest
	# A red bends its own chain; a green passes what it is carrying along and
	# lets the reds under it do the bending.
	var mine: float = 0.0
	if j.kind == Kind.PARENT:
		mine = j.along * PI * 0.72
	for kid in children_of(index):
		_settle_from(kid, carried + mine, j.now, j.rest, true)

func rest_pose() -> void:
	for j in joints:
		(j as Joint).along = 0.0
	for r in rings:
		(r as Ring).turn = 0.0
	for b in bones:
		(b as Bone).a = (b as Bone).rest_a
		(b as Bone).b = (b as Bone).rest_b
	_settle()

# -------------------------------------------------------------------- rings

func add_ring(kind: int, centre: Vector2, radius: float, axis: int) -> int:
	var r: Ring = Ring.new()
	r.kind = kind
	r.centre = centre
	r.radius = maxf(radius, 8.0)
	r.axis = axis
	rings.append(r)
	return rings.size() - 1

func ring_at(at: Vector2, only_live: bool = true) -> int:
	var best: int = -1
	var best_d: float = INF
	for i in rings.size():
		var r: Ring = rings[i] as Ring
		if only_live and not r.live:
			continue
		# On the band of the ring, not inside it — the middle of a big ring
		# is where the drawing is, and grabbing the ring there would mean
		# never being able to touch the figure.
		var d: float = absf(at.distance_to(r.centre) - r.radius)
		if d < best_d and d <= r.radius * 0.45 + 26.0:
			best_d = d
			best = i
	return best

func dead_rings() -> Array:
	var out: Array = []
	for i in rings.size():
		if not (rings[i] as Ring).live:
			out.append(i)
	return out

func remove_ring(index: int) -> void:
	if index >= 0 and index < rings.size():
		rings.remove_at(index)

## What a ring covers, and therefore what it turns.
##
## Purple reaches as far as the next ring along and no further — that is what
## makes it a section rather than a whole limb. Tiffany is the parent and
## carries everything inside it up to the next tiffany. White takes the whole
## figure.
func reach_of(index: int) -> float:
	if index < 0 or index >= rings.size():
		return 0.0
	var r: Ring = rings[index] as Ring
	if r.kind == RingKind.WHITE:
		return INF
	var nearest: float = INF
	for i in rings.size():
		if i == index:
			continue
		var other: Ring = rings[i] as Ring
		if r.kind == RingKind.PURPLE or other.kind == r.kind:
			nearest = minf(nearest, r.centre.distance_to(other.centre))
	if nearest == INF:
		return r.radius * 3.0
	return nearest

# -------------------------------------------------------------------- bones

func add_bone(a: Vector2, b: Vector2, on_pose: int = 0,
		height: float = 0.0) -> void:
	var bone: Bone = Bone.new()
	bone.rest_a = a
	bone.rest_b = b
	bone.a = a
	bone.b = b
	bone.built_on = on_pose
	bone.built_height = height
	bones.append(bone)

## Which way an end bends, cycled by tapping it in Connect.
func cycle_bend(index: int, which: int) -> int:
	if index < 0 or index >= bones.size():
		return Bend.FREE
	var b: Bone = bones[index] as Bone
	if which == 0:
		b.bend_a = Bend.RIGHT if b.bend_a == Bend.FREE else Bend.FREE
		return b.bend_a
	b.bend_b = Bend.RIGHT if b.bend_b == Bend.FREE else Bend.FREE
	return b.bend_b

func bend_of(index: int, which: int) -> int:
	if index < 0 or index >= bones.size():
		return Bend.FREE
	var b: Bone = bones[index] as Bone
	return b.bend_a if which == 0 else b.bend_b

## Bones ride with the figure as it turns.
##
## The eight drawings of a turnaround do not agree about where anything sits —
## a shoulder is higher in the back view than the front, because the artist
## drew them on different days. A bone left at the coordinates it was laid on
## would drift off the limb it belongs to the moment the figure turned. So it
## is carried by however much the figure itself moved between the pose it was
## built on and the pose now on screen.
func carry_to(pose_index: int, ground_shift: float, scale: float) -> void:
	for b in bones:
		var bone: Bone = b as Bone
		if bone.built_on == pose_index:
			bone.carry = Vector2.ZERO
			continue
		bone.carry = Vector2(0.0, ground_shift)
		if scale > 0.001 and absf(scale - 1.0) > 0.002:
			# Height differences are a scale about the ground, not a slide:
			# a figure drawn a little shorter has every part of it a little
			# lower, and the feet not at all.
			bone.carry.y += (bone.rest_a.y + bone.rest_b.y) * 0.5 * (scale - 1.0)

func bone_joint_at(at: Vector2, reach: float) -> Array:
	var best: Array = []
	var best_d: float = reach * reach
	for i in bones.size():
		var b: Bone = bones[i] as Bone
		if at.distance_squared_to(b.a) <= best_d:
			best_d = at.distance_squared_to(b.a)
			best = [i, 0]
		if at.distance_squared_to(b.b) <= best_d:
			best_d = at.distance_squared_to(b.b)
			best = [i, 1]
	return best

## A bone turns about its far end and keeps its length — the reason to use a
## bone at all rather than dragging the drawing.
##
## An end set to a right-angle bend snaps to quarter turns. An elbow does not
## stop wherever it likes; it reaches a stop, and this is that stop made
## honest rather than left to a steady hand.
func swing_bone(index: int, which: int, to: Vector2) -> void:
	if index < 0 or index >= bones.size():
		return
	var b: Bone = bones[index] as Bone
	var pivot: Vector2 = b.b if which == 0 else b.a
	var span: float = b.rest_a.distance_to(b.rest_b)
	var dir: Vector2 = to - pivot
	if dir.length_squared() < 0.000001:
		return
	var bend: int = b.bend_a if which == 0 else b.bend_b
	if bend == Bend.RIGHT:
		var step: float = TAU / 4.0
		dir = Vector2.RIGHT.rotated(round(dir.angle() / step) * step)
	dir = dir.normalized() * span
	if which == 0:
		b.a = pivot + dir
	else:
		b.b = pivot + dir

# ---------------------------------------------------------------- writing

func to_dict() -> Dictionary:
	var js: Array = []
	for j in joints:
		var one: Joint = j as Joint
		var bar: Array = []
		for p in one.bar:
			bar.append([p.x, p.y])
		var mirror: Array = []
		for p in one.mirror:
			mirror.append([p.x, p.y])
		js.append({"kind": one.kind, "x": one.rest.x, "y": one.rest.y,
			"parent": one.parent, "bar": bar, "mirror": mirror})
	var bs: Array = []
	for b in bones:
		var one_b: Bone = b as Bone
		bs.append({"ax": one_b.rest_a.x, "ay": one_b.rest_a.y,
			"bx": one_b.rest_b.x, "by": one_b.rest_b.y,
			"bend_a": one_b.bend_a, "bend_b": one_b.bend_b,
			"on": one_b.built_on, "height": one_b.built_height})
	var rs: Array = []
	for r in rings:
		var one_r: Ring = r as Ring
		rs.append({"kind": one_r.kind, "x": one_r.centre.x, "y": one_r.centre.y,
			"radius": one_r.radius, "axis": one_r.axis, "live": one_r.live})
	return {"joints": js, "bones": bs, "rings": rs}

static func from_dict(doc: Dictionary) -> Rig360:
	var rig: Rig360 = Rig360.new()
	for row in doc.get("joints", []):
		var j: Joint = Joint.new()
		j.kind = int(row.get("kind", Kind.CHILD))
		j.rest = Vector2(float(row.get("x", 0.0)), float(row.get("y", 0.0)))
		j.now = j.rest
		j.parent = int(row.get("parent", -1))
		for p in row.get("bar", []):
			j.bar.append(Vector2(float(p[0]), float(p[1])))
		for p in row.get("mirror", []):
			j.mirror.append(Vector2(float(p[0]), float(p[1])))
		rig.joints.append(j)
	for row in doc.get("bones", []):
		rig.add_bone(
			Vector2(float(row.get("ax", 0.0)), float(row.get("ay", 0.0))),
			Vector2(float(row.get("bx", 0.0)), float(row.get("by", 0.0))),
			int(row.get("on", 0)), float(row.get("height", 0.0)))
		var made: Bone = rig.bones[rig.bones.size() - 1] as Bone
		made.bend_a = int(row.get("bend_a", Bend.FREE))
		made.bend_b = int(row.get("bend_b", Bend.FREE))
	for row in doc.get("rings", []):
		var index: int = rig.add_ring(int(row.get("kind", RingKind.PURPLE)),
			Vector2(float(row.get("x", 0.0)), float(row.get("y", 0.0))),
			float(row.get("radius", 40.0)), int(row.get("axis", Axis.VERTICAL)))
		(rig.rings[index] as Ring).live = bool(row.get("live", true))
	rig._settle()
	return rig
