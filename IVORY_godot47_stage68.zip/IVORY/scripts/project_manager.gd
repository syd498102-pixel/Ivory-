class_name ProjectManager
extends Node2D
## Projects live on the infinite grid as sheets of paper.
##
## Each one is a world of its own: its own layers, its own undo history, its
## own paper size and colour. Nothing is shared, so opening a second project
## can never disturb the first.
##
## Only the open project keeps its pixels on the graphics card. A closed one
## folds every tile down into compressed memory and shows a single flat
## picture instead, which is what makes a workspace full of projects cost
## about as much as a workspace with one.

signal projects_changed()
signal active_changed(project: Project)

enum Kind { DRAWING, ANIMATION, COMIC }
enum State { FLOATING, CLOSED, OPEN }

const TITLE_LIFT: float = 34.0
const MAX_PROJECTS: int = 1000
const MAX_PAGES: int = 12

## One page: its own sheet, its own layers, its own undo history. A comic
## page is a drawing in its own right, not a region of a longer one, and
## giving each its own stack is what makes "add a page" cost nothing and
## "work on page three" mean only page three.
class Page:
	var sheet: ProjectSheet = null
	var stack: LayerStack = null
	var history: History = null
	## Its own clip, for the same reason it has its own layers: a page is a
	## drawing in its own right, and a timeline that spanned pages would
	## have to explain what page two means at frame ten of page one.
	var clip: Anim.Clip = null

class Project:
	## An inner class cannot see the enclosing script's constants, so the
	## page gap lives here and the outer code reads it back through the
	## class. One definition, no chance of the two drifting apart.
	const PAGE_GAP: float = 60.0

	var id: int = 0
	var title: String = ""
	var kind: int = 0                       # ProjectManager.Kind
	var created: String = ""
	var origin: Vector2 = Vector2.ZERO      # top-left of page one, in world
	var page: Vector2 = Vector2(1600, 1200)
	var pages: int = 1
	var paper: Color = Color("#ffffff")
	var frame: Color = Color("#1b1c22")
	var favourite: bool = false
	var state: int = 0                      # ProjectManager.State
	## Graph paper under the ink. A guide, never part of the artwork, so it
	## is drawn by the sheet and skipped by every exporter.
	var grid_guide: bool = false

	# --- animation only ---
	var fps: int = 24
	var frames: int = 24
	var onion_skin: bool = true
	var onion_back: int = 2
	var onion_forward: int = 1
	var onion_back_tint: Color = Color(0.90, 0.35, 0.35, 0.34)
	var onion_highlight: Color = Color(1.0, 0.78, 0.22, 0.34)
	var onion_forward_tint: Color = Color(0.35, 0.55, 0.95, 0.30)
	var looping: bool = true

	## Pages laid out downwards instead of across. A comic reads as a strip
	## either way; which one suits depends on the screen in front of you.
	var stacked: bool = false
	var active_page: int = 0

	var root: Node2D = null
	var sheets: Array = []          # of Page

	## The active page's stack and history. Kept as plain references so the
	## rest of the app can go on saying `project.stack` without caring that
	## there are now several.
	var stack: LayerStack = null
	var history: History = null
	var clip: Anim.Clip = null

	func page_at(i: int) -> Page:
		if sheets.is_empty():
			return null
		return sheets[clampi(i, 0, sheets.size() - 1)]

	## Where a page sits inside the project, measured from its corner.
	func page_offset(i: int) -> Vector2:
		if stacked:
			return Vector2(0.0, (page.y + PAGE_GAP) * float(i))
		return Vector2((page.x + PAGE_GAP) * float(i), 0.0)

	## The whole spread, pages and gaps together.
	func bounds() -> Rect2:
		var last: Vector2 = page_offset(maxi(pages - 1, 0))
		return Rect2(origin, last + page)

	func page_rect(i: int) -> Rect2:
		return Rect2(origin + page_offset(i), page)

var projects: Array[Project] = []
var active: Project = null
var selected: Project = null

## Focus hides everything except the project being worked on, which buys
## both a clear field to draw in and less to render. `focus_shows_others`
## lets someone keep the neighbours in sight when they are working from
## them — the point is to remove clutter, not to remove the choice.
## The sheet the user is placing right now, and only that one. Reading the
## state flag instead let a project left FLOATING by a failed load swallow
## every touch in the app — nothing else could be opened, moved or deleted.
var placing: Project = null

var focus_on: Project = null
var focus_shows_others: bool = false

## Set by anything that changes a document. The autosave timer reads it and
## clears it, so a workspace being looked at rather than drawn on never
## writes a byte.
var dirty: Dictionary = {}

## The sheet currently being carried across the workspace, so the frame can
## say so while it is in the air.
var dragging: Project = null

var _next_id: int = 1
var render_rect: Rect2 = Rect2()

func _ready() -> void:
	y_sort_enabled = false

# ------------------------------------------------------------------ create

func create(title: String, kind: int, page_size: Vector2, paper: Color,
		pages: int, at: Vector2) -> Project:
	if projects.size() >= MAX_PROJECTS:
		return null
	var p: Project = Project.new()
	p.id = _next_id
	_next_id += 1
	p.title = title.strip_edges()
	if p.title == "":
		# Numbered by how many are actually here, not by how many have ever
		# existed. Delete your first project and the next one is number one
		# again, which is what anyone counting sheets on a desk would expect.
		p.title = "%s %d" % [_kind_word(kind), _next_number(kind)]
	p.kind = kind
	p.page = Vector2(maxf(page_size.x, 64.0), maxf(page_size.y, 64.0))
	p.pages = maxi(pages, 1)
	if kind == Kind.COMIC:
		p.pages = maxi(p.pages, 2)   # a comic is a spread, never one sheet
	p.paper = paper
	p.created = Time.get_date_string_from_system()
	p.state = State.FLOATING

	p.root = Node2D.new()
	p.root.name = "Project_%d" % p.id
	add_child(p.root)

	for i in p.pages:
		_add_page_node(p)
	_bind_page(p, 0)

	p.origin = _free_spot(at - p.bounds().size * 0.5, p.bounds().size, p)
	_sync(p)
	projects.append(p)
	placing = p
	projects_changed.emit()
	return p

## Slides a new sheet along until it is clear of the ones already there.
## Two projects born at the middle of the same view would otherwise sit
## exactly on top of each other, and stay stacked for good once saved.
func _free_spot(wanted: Vector2, span: Vector2, ignore: Project) -> Vector2:
	var gap: float = Project.PAGE_GAP * 2.0
	var at: Vector2 = wanted
	for _try in 40:
		var clash: bool = false
		for other in projects:
			if other == ignore:
				continue
			if Rect2(at, span).grow(gap * 0.5).intersects(other.bounds()):
				clash = true
				break
		if not clash:
			return at
		at.x += span.x + gap
		# Wrapped onto a new row rather than marching off in a straight
		# line, so a workspace stays something the eye can scan.
		if at.x > wanted.x + (span.x + gap) * 4.0:
			at.x = wanted.x
			at.y += span.y + gap
	return at

## Builds one more page and everything that belongs to it.
func _add_page_node(p: Project) -> Page:
	var page: Page = Page.new()
	page.sheet = ProjectSheet.new()
	page.sheet.name = "Page_%d" % (p.sheets.size() + 1)
	page.sheet.page_size = p.page
	page.sheet.paper = p.paper
	page.sheet.grid_guide = p.grid_guide
	p.root.add_child(page.sheet)

	page.stack = LayerStack.new()
	page.stack.name = "Layers"
	page.sheet.add_child(page.stack)

	page.history = History.new(page.stack)
	page.stack.history = page.history

	page.clip = Anim.Clip.new()
	page.clip.fps = clampi(p.fps, 1, 60)
	page.clip.length = maxi(p.frames, 1)

	p.sheets.append(page)
	page.sheet.position = p.page_offset(p.sheets.size() - 1)
	return page

## Points the project's `stack` and `history` at one page.
func _bind_page(p: Project, index: int) -> void:
	var page: Page = p.page_at(index)
	if page == null:
		return
	p.active_page = clampi(index, 0, p.sheets.size() - 1)
	p.stack = page.stack
	p.history = page.history
	p.clip = page.clip
	_sync_pages(p)

func set_page(p: Project, index: int) -> void:
	if p == null or index == p.active_page:
		return
	_bind_page(p, index)
	if p == active:
		active_changed.emit(p)
	projects_changed.emit()

func add_page(p: Project) -> void:
	if p == null or p.pages >= MAX_PAGES:
		return
	p.pages += 1
	_add_page_node(p)
	_bind_page(p, p.pages - 1)
	_sync(p)
	projects_changed.emit()

## Lays the pages out and decides which one is allowed to clip.
func _sync_pages(p: Project) -> void:
	for i in p.sheets.size():
		var page: Page = p.sheets[i]
		page.sheet.position = p.page_offset(i)
		page.sheet.page_size = p.page
		page.sheet.paper = p.paper
		page.sheet.grid_guide = p.grid_guide
		# Every page clips, always. Reserving it for the page being painted
		# meant a closed project drew whatever had once run past its edge,
		# and a sheet that shows more than its own paper is not a sheet.
		# The cost is bounded elsewhere: pages off screen do not draw at all.
		page.sheet.set_clipping(true)
		page.sheet.queue_redraw()

func set_layout_stacked(p: Project, on: bool) -> void:
	if p == null or p.stacked == on:
		return
	p.stacked = on
	_sync(p)
	projects_changed.emit()

func _kind_word(kind: int) -> String:
	if kind == Kind.ANIMATION:
		return Lang.t("Animation")
	if kind == Kind.COMIC:
		return Lang.t("Comic")
	return Lang.t("Drawing")

func _next_number(kind: int) -> int:
	var taken: Dictionary = {}
	var word: String = _kind_word(kind)
	for other in projects:
		if other.kind != kind:
			continue
		var tail: String = other.title.replace(word, "").strip_edges()
		if tail.is_valid_int():
			taken[int(tail)] = true
	var n: int = 1
	while taken.has(n):
		n += 1
	return n

func duplicate_project(src: Project) -> Project:
	if src == null:
		return null
	var copy: Project = create(src.title + " copy", src.kind, src.page,
		src.paper, src.pages, src.bounds().get_center())
	if copy == null:
		return null
	copy.frame = src.frame
	copy.favourite = src.favourite
	copy.fps = src.fps
	copy.frames = src.frames
	copy.onion_skin = src.onion_skin
	copy.onion_back = src.onion_back
	copy.onion_forward = src.onion_forward
	copy.onion_back_tint = src.onion_back_tint
	copy.onion_highlight = src.onion_highlight
	copy.onion_forward_tint = src.onion_forward_tint
	copy.looping = src.looping
	copy.stacked = src.stacked
	copy.active_page = src.active_page
	copy.origin = src.origin + Vector2(src.bounds().size.x + Project.PAGE_GAP * 2.0, 0.0)
	copy.state = State.CLOSED
	# A professional duplicate is a document duplicate, not a screenshot.
	# Preserve every page's cels, camera keys, layer properties and folders.
	for i in mini(src.sheets.size(), copy.sheets.size()):
		var from_page: Page = src.sheets[i]
		var into_page: Page = copy.sheets[i]
		into_page.clip = Anim.from_dict(Anim.to_dict(from_page.clip))
		into_page.history.clear()

		var from_stack: LayerStack = from_page.stack
		var into_stack: LayerStack = into_page.stack
		while into_stack.layers.size() < from_stack.layers.size():
			if into_stack.add_layer() == null:
				break
		while into_stack.layers.size() > from_stack.layers.size() and into_stack.layers.size() > 1:
			into_stack.remove_layer(into_stack.layers.size() - 1)

		for k in mini(from_stack.layers.size(), into_stack.layers.size()):
			var src_layer: LayerStack.Layer = from_stack.layers[k]
			var dst_layer: LayerStack.Layer = into_stack.layers[k]
			dst_layer.title = src_layer.title
			dst_layer.opacity = src_layer.opacity
			dst_layer.visible = src_layer.visible
			dst_layer.locked = src_layer.locked
			dst_layer.is_background = src_layer.is_background
			dst_layer.cels.from_dict(src_layer.cels.to_dict())
			dst_layer.surface.blend_from(src_layer.surface, 1.0)

		# Recreate folders with fresh IDs, then restore their visual state.
		for g in from_stack.groups:
			var first_index: int = -1
			for k in from_stack.layers.size():
				if from_stack.layers[k].group_id == g.id:
					first_index = k
					break
			if first_index < 0 or first_index >= into_stack.layers.size():
				continue
			var new_group: LayerStack.Group = into_stack.group_layer(first_index)
			if new_group == null:
				continue
			new_group.title = g.title
			new_group.opacity = g.opacity
			new_group.visible = g.visible
			new_group.collapsed = g.collapsed
			for k in into_stack.layers.size():
				if k < from_stack.layers.size() and from_stack.layers[k].group_id == g.id:
					into_stack.layers[k].group_id = new_group.id
		into_stack._rebuild()
		into_page.history.clear()

	_bind_page(copy, clampi(src.active_page, 0, maxi(copy.sheets.size() - 1, 0)))
	_sync(copy)
	projects_changed.emit()
	return copy

func select(p: Project) -> void:
	if p == null:
		return
	selected = p
	projects_changed.emit()

func clear_selection() -> void:
	if selected == null:
		return
	selected = null
	projects_changed.emit()

func remove(p: Project) -> void:
	if p == null:
		return
	var was_active: bool = p == active
	if placing == p:
		placing = null
	if dragging == p:
		dragging = null
	if focus_on == p:
		focus_on = null
	if selected == p:
		selected = null
	projects.erase(p)
	p.root.queue_free()
	if was_active:
		active = null
		active_changed.emit(null)
	projects_changed.emit()

# ------------------------------------------------------------------- state

func open(p: Project) -> void:
	if p == null or p == active:
		return
	if p.state == State.FLOATING:
		place(p)
	if active != null and active != p:
		close(active)
	p.state = State.OPEN
	selected = p
	_wake(p)
	active = p
	_sync(p)
	active_changed.emit(p)
	projects_changed.emit()

## Closing is what keeps a crowded workspace cheap: every tile is squeezed
## into compressed memory and every render target handed back.
func close(p: Project) -> void:
	if p == null or p.state == State.FLOATING:
		return
	p.state = State.CLOSED
	# Trimmed once, here, so the sheet can stop clipping for good. Doing it
	# at closing time means the cost is paid on an action the user already
	# expects to take a moment, not on every frame of every project.
	var page_span: Rect2 = Rect2(Vector2.ZERO, p.page)
	for page in p.sheets:
		for l in (page as Page).stack.layers:
			l.surface.settle()
			l.surface.trim_to(page_span)
			l.surface.sleep_all()

	if p == active:
		active = null
		active_changed.emit(null)
	_sync(p)
	projects_changed.emit()

func place(p: Project) -> void:
	if p == null or p.state != State.FLOATING:
		return
	p.state = State.CLOSED
	if placing == p:
		placing = null
	_sync(p)
	projects_changed.emit()

func _wake(p: Project) -> void:
	for page in p.sheets:
		for l in (page as Page).stack.layers:
			l.surface.update_view(Rect2(Vector2.ZERO, p.page).grow(p.page.x), 1.0)

func mark_dirty(p: Project) -> void:
	if p != null:
		dirty[p.id] = true

func take_dirty() -> Array:
	# Snapshot only. A failed disk write must remain dirty so the next autosave
	# can retry it instead of silently declaring unsaved work clean.
	var out: Array = []
	for p in projects:
		if dirty.has(p.id):
			out.append(p)
	return out

func mark_saved(p: Project) -> void:
	if p != null:
		dirty.erase(p.id)

func _sync(p: Project) -> void:
	p.root.position = p.origin
	_sync_pages(p)
	_apply_focus()

func set_focus(p: Project) -> void:
	focus_on = p
	_apply_focus()
	projects_changed.emit()

func clear_focus() -> void:
	focus_on = null
	_apply_focus()
	projects_changed.emit()

func set_focus_shows_others(on: bool) -> void:
	focus_shows_others = on
	_apply_focus()
	projects_changed.emit()

func is_hidden(p: Project) -> bool:
	if focus_on == null or focus_shows_others:
		return false
	return p != focus_on

func _apply_focus() -> void:
	for p in projects:
		if p.root != null:
			p.root.visible = not is_hidden(p)

## Where a sheet sits is part of the document, so moving it makes the
## project unsaved rather than quietly losing the new place on exit.
func move_to(p: Project, origin: Vector2) -> void:
	if p == null:
		return
	p.origin = origin
	mark_dirty(p)
	_sync(p)

# ------------------------------------------------------------------ lookup

## Whether a project with this id is already here, so a folder read twice
## cannot produce two of the same project.
func holds_id(id: int) -> bool:
	for p in projects:
		if p.id == id:
			return true
	return false

## Gives a restored project the id it was saved under, and keeps the counter
## above it so a new project can never collide with one on disk.
func reclaim_id(p: Project, id: int) -> void:
	if p == null or id <= 0:
		return
	p.id = id
	p.root.name = "Project_%d" % id
	_next_id = maxi(_next_id, id + 1)

## Topmost first, so a project laid over another answers for the tap. A
## project hidden by focus is not on screen, and something the user cannot
## see must not be what their finger lands on.
func at_point(world: Vector2) -> Project:
	for i in range(projects.size() - 1, -1, -1):
		if is_hidden(projects[i]):
			continue
		if projects[i].bounds().has_point(world):
			return projects[i]
	return null

func title_strip_at(world: Vector2, zoom: float) -> Project:
	var lift: float = TITLE_LIFT / maxf(zoom, 0.0001)
	for i in range(projects.size() - 1, -1, -1):
		if is_hidden(projects[i]):
			continue
		var b: Rect2 = projects[i].bounds()
		var strip: Rect2 = Rect2(b.position - Vector2(0.0, lift),
			Vector2(b.size.x, lift))
		if strip.has_point(world):
			return projects[i]
	return null

func bring_to_front(p: Project) -> void:
	if p == null:
		return
	projects.erase(p)
	projects.append(p)
	move_child(p.root, get_child_count() - 1)

## Keeps closed projects out of the way of the drawing hand.
## A project's layers live inside the project's own node, so their tiles are
## measured from the project's corner, not from the world origin. Handing
## them a world rectangle meant every tile on screen was judged to be far
## away — hidden, and put to sleep — which is why drawing appeared to do
## nothing at all.
## Runs for every project, not only the open one: a closed project still
## draws, and its pages still need to know whether anyone can see them.
func update_view(view_world: Rect2, zoom: float) -> void:
	# Keep a generous culling rectangle for chrome/project cards. This lets
	# workspaces hold hundreds of projects without drawing every card every frame.
	render_rect = view_world.grow(maxf(view_world.size.x, view_world.size.y) * 0.85)
	for p in projects:
		if is_hidden(p):
			for hidden_page in p.sheets:
				(hidden_page as Page).sheet.visible = false
			continue
		for i in p.sheets.size():
			var page: Page = p.sheets[i]
			var corner: Vector2 = p.origin + p.page_offset(i)
			var candidate: Rect2 = Rect2(corner, p.page)
			var seen: bool = view_world.intersects(candidate)
			# Clipping costs a framebuffer copy per page that draws, so a
			# page off screen is hidden rather than merely quiet.
			if page.sheet.visible != seen:
				page.sheet.visible = seen
			if not seen:
				continue
			page.stack.update_view(
				Rect2(view_world.position - corner, view_world.size), zoom)
