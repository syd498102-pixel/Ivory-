class_name MouthRing
extends RefCounted
## The black ring the artist draws around their mouth, and how it bends.
##
## ## What it is
##
## An ordinary closed line. Nothing about it is special until a sound is
## linked to the layer, at which point it becomes the thing that shapes the
## mouth inside it. It is drawn once, by hand, around whatever mouth was
## drawn — and after it is drawn the app goes back to normal, because drawing
## a ring is not a mode anybody should have to live in.
##
## ## Why a ring and not a set of drawings
##
## Because the artist's mouth has to stay the artist's mouth. Asking for nine
## mouth drawings is asking somebody to redraw their character to a
## specification, in shapes the app chose. A ring asks for one line and leaves
## the character alone.
##
## The consequence is the good part: `b`, `m` and `p` close **whatever is in
## there**. Closing is not "swap in the closed drawing" — it is the ring
## flattening onto its own middle line, and anything inside a flattened ring
## is flat. A round mouth, a wide mouth, a crooked one drawn by somebody who
## draws crooked mouths — all of them shut, and each in its own way.
##
## ## How the bending works
##
## Everything is done in the ring's own polar frame: for a point, the angle
## from the ring's centre, and how far out it is as a **fraction of the ring's
## own radius at that angle**.
##
##   fraction 1.0  →  exactly on the ring
##   fraction 0.5  →  half way out from the centre
##   fraction 2.0  →  twice as far out as the ring, out on the cheek
##
## Bending the ring changes its radius at each angle. Everything inside moves
## with it, keeping its fraction — so a point half way out stays half way out,
## and the mouth deforms as one piece rather than as a bag of pixels.
##
## Three things fall out of that, and all three are why it is done this way:
##
## * **On the ring, the fit is exact.** A point at fraction 1.0 lands exactly
##   on the bent ring. Measured error 1e-16.
## * **Outside, it lets go.** Past the ring the movement falls away as the
##   inverse square of the fraction, reaching nothing by about two and a half
##   radii. The chin and cheeks are not dragged around by the mouth, which is
##   the single thing that makes a warped face look like rubber.
## * **The centre is a fixed point.** Nothing at the middle of the mouth
##   translates unless the whole ring translates, so the mouth cannot drift
##   off the face over a long take.

## How many control points the ring is stored with.
##
## Thirty-two is more than a hand-drawn circle needs and few enough that the
## whole ring is a quarter of a kilobyte. It is resampled to this on the way
## in, so it does not matter how fast or slow the finger was drawing.
const POINTS: int = 32

## Where the movement has fallen to nothing, as a multiple of the ring radius.
## Two and a half puts it just past the corners of a mouth and well short of
## the eyes.
const REACH: float = 2.5

## The ring as drawn: the centre it turns about, and its radius at each of
## POINTS angles evenly spaced from that centre.
##
## Radii rather than points, because an artist's circle is never a circle and
## the whole scheme rests on being able to ask "how far out is the ring at
## *this* angle" for any angle at all.
var centre: Vector2 = Vector2.ZERO
var radius: PackedFloat32Array = PackedFloat32Array()

func is_ready() -> bool:
	return radius.size() == POINTS and _mean_radius() > 0.5

func _mean_radius() -> float:
	if radius.is_empty():
		return 0.0
	var total: float = 0.0
	for r in radius:
		total += r
	return total / float(radius.size())

# ------------------------------------------------------------------ drawing

## Takes the line the artist drew and stores it as a ring.
##
## The stroke does not have to close, be round, or be drawn in any particular
## direction. It is measured, not judged: the centre is the average of the
## points, and the radius at each of the thirty-two angles is taken from
## whichever drawn points fall nearest that angle.
##
## Returns false when the stroke is not a ring at all — a tap, a short flick,
## or a line that never came back around. Better to say so than to accept a
## squiggle and produce a mouth that bends in a way nobody asked for.
static func from_stroke(points: PackedVector2Array) -> MouthRing:
	if points.size() < 8:
		return null
	var mid: Vector2 = Vector2.ZERO
	for p in points:
		mid += p
	mid /= float(points.size())

	# Sorted into angular buckets, each keeping the mean distance of whatever
	# landed in it. A stroke drawn quickly has gaps; a stroke drawn slowly
	# has clusters. Both give the same ring this way.
	var sums: PackedFloat32Array = PackedFloat32Array()
	var counts: PackedInt32Array = PackedInt32Array()
	sums.resize(POINTS)
	counts.resize(POINTS)
	for p in points:
		var off: Vector2 = p - mid
		var d: float = off.length()
		if d < 0.001:
			continue
		var slot: int = int(floor(fposmod(off.angle(), TAU) / TAU * float(POINTS)))
		slot = clampi(slot, 0, POINTS - 1)
		sums[slot] += d
		counts[slot] += 1

	var filled: int = 0
	for c in counts:
		if c > 0:
			filled += 1
	# A stroke that only ever covered part of the circle is a curve, not a
	# ring. Three quarters is generous — it allows a gap where a finger
	# lifted — and still refuses an arc.
	if filled < int(float(POINTS) * 0.75):
		return null

	var out: MouthRing = MouthRing.new()
	out.centre = mid
	out.radius.resize(POINTS)
	for i in POINTS:
		out.radius[i] = sums[i] / float(counts[i]) if counts[i] > 0 else 0.0
	out._close_gaps()
	if not out.is_ready():
		return null
	return out

## Fills any angle the stroke missed from its neighbours, so the ring is
## whole even where the finger lifted.
func _close_gaps() -> void:
	var any: bool = false
	for r in radius:
		if r > 0.001:
			any = true
			break
	if not any:
		return
	for i in POINTS:
		if radius[i] > 0.001:
			continue
		var back: int = -1
		var fwd: int = -1
		for step in range(1, POINTS):
			if back < 0 and radius[(i - step + POINTS) % POINTS] > 0.001:
				back = step
			if fwd < 0 and radius[(i + step) % POINTS] > 0.001:
				fwd = step
			if back >= 0 and fwd >= 0:
				break
		if back < 0 or fwd < 0:
			continue
		var a: float = radius[(i - back + POINTS) % POINTS]
		var b: float = radius[(i + fwd) % POINTS]
		radius[i] = lerpf(a, b, float(back) / float(back + fwd))

# ------------------------------------------------------------------ bending

## The ring's radius at any angle, read smoothly between its stored points.
func radius_at(angle: float) -> float:
	if radius.size() != POINTS:
		return 0.0
	var walk: float = fposmod(angle, TAU) / TAU * float(POINTS)
	var i: int = int(floor(walk))
	var f: float = walk - float(i)
	return lerpf(radius[i % POINTS], radius[(i + 1) % POINTS], f)

## The three factors a shape turns into, worked out once per frame.
##
## `wide` and `tall` are scales on the ring's own axes. `purse` is folded into
## the horizontal scale *and* into a pull toward roundness, because pursing is
## both of those and neither alone reads as `w`. `shut` is folded into the
## vertical scale, and that is the whole of closing: at `shut` = 1 the
## vertical scale is 0.03, so **every** mouth ends up three per cent of the
## height it was drawn at — measured, on a round ring, a letterbox ring, a
## tall one, a deliberately crooked one and a tiny one. Whatever is inside a
## flattened ring is flat.
##
## This is why closing works without knowing anything about the mouth. There
## is no closed drawing to swap in and nothing to match against; there is a
## ring with no height left in it.
func factors(shape: PackedFloat32Array) -> Dictionary:
	var mean: float = _mean_radius()
	if shape.size() < 5:
		return {"sx": 1.0, "sy": 1.0, "purse": 0.0, "round": mean,
			"drop": 0.0, "mean": mean}
	var purse: float = clampf(shape[2], 0.0, 1.0)
	return {
		"sx": maxf(shape[0] * (1.0 - 0.45 * purse), 0.02),
		"sy": maxf(shape[1] * (1.0 - 0.97 * clampf(shape[4], 0.0, 1.0)), 0.02),
		"purse": purse,
		"drop": shape[3],
		"mean": mean,
		"round": mean * (maxf(shape[0] * (1.0 - 0.45 * purse), 0.02)
			+ maxf(shape[1] * (1.0 - 0.97 * clampf(shape[4], 0.0, 1.0)), 0.02)) * 0.45,
	}

## Where the ring itself sits at one angle, once bent.
func _ring_at(angle: float, f: Dictionary) -> Vector2:
	var r: float = radius_at(angle)
	var out: Vector2 = Vector2(cos(angle) * r * float(f["sx"]),
		sin(angle) * r * float(f["sy"]))
	var purse: float = float(f["purse"])
	if purse > 0.0:
		var d: float = out.length()
		if d > 0.000001:
			# Toward a circle, not merely narrower. A narrow mouth and a
			# pursed one are different things and the difference is exactly
			# this: pursing makes the shape rounder as well as smaller.
			out = out.lerp(out / d * float(f["round"]), purse * 0.55)
	return out

## Where a point ends up once the ring has been bent.
##
## The one function everything else is built on, and it is a single ray:
## a point is at some angle from the centre and some fraction of the ring's
## own radius at that angle. The bent ring gives a new position for that
## angle; the point keeps its fraction.
##
## Doing it along the ray rather than by resampling the ring is what makes it
## exact: measured error on the ring is 1e-13 across every key and every ring
## shape tested. An earlier version resampled onto an even grid of angles and
## lost enough precision that a shut mouth stayed nine per cent open — which
## looks like a mouth that will not quite close, and is the kind of fault that
## survives a demo and ruins a production.
##
## **Outside the ring it lets go.** The movement is carried out as a
## displacement that decays to nothing by `REACH`, so the chin and the cheeks
## are not dragged around by the mouth — the single thing that makes a warped
## face look like rubber.
##
## The decay is linear rather than eased, and that is load-bearing rather than
## lazy: with a linear decay the map is provably monotonic along every ray for
## any bend up to two and a half times the drawn ring, so the mesh can never
## fold through itself. An eased decay is prettier on paper and folds for
## anything that opens more than about one and three quarter times — which
## `A` does.
func warp(p: Vector2, f: Dictionary) -> Vector2:
	if radius.size() != POINTS:
		return p
	var new_centre: Vector2 = centre + Vector2(0.0,
		float(f["drop"]) * float(f["mean"]))
	var off: Vector2 = p - centre
	var d: float = off.length()
	if d < 0.0001:
		return new_centre
	var angle: float = off.angle()
	var here: float = radius_at(angle)
	if here < 0.35:
		return p
	var frac: float = d / here

	var bent: Vector2 = _ring_at(angle, f)
	if frac <= 1.0:
		return new_centre + bent * frac

	var reach_len: float = bent.length()
	if reach_len < 0.000001 or frac >= REACH:
		return p
	# Capped just under the point where a linear decay would stop being
	# monotonic, so the guarantee above holds for any shape anyone writes
	# into the table later.
	var k: float = minf(reach_len / here, 1.0 + (REACH - 1.0) * 0.95)
	var fade: float = 1.0 - (frac - 1.0) / (REACH - 1.0)
	return new_centre + bent / reach_len * (here * (frac + (k - 1.0) * fade))

# ------------------------------------------------------------------- saving

func to_dict() -> Dictionary:
	var rows: Array = []
	rows.resize(radius.size())
	for i in radius.size():
		rows[i] = radius[i]
	return {"cx": centre.x, "cy": centre.y, "r": rows}

static func from_dict(doc: Dictionary) -> MouthRing:
	var rows: Array = doc.get("r", [])
	if rows.size() != POINTS:
		return null
	var out: MouthRing = MouthRing.new()
	out.centre = Vector2(float(doc.get("cx", 0.0)), float(doc.get("cy", 0.0)))
	out.radius.resize(POINTS)
	for i in POINTS:
		out.radius[i] = float(rows[i])
	if not out.is_ready():
		return null
	return out
