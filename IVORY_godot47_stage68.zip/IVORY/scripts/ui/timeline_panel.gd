class_name TimelinePanel
extends PanelContainer
## The timeline, built to the shape you drew.
##
## One band at the foot of the screen: a row of controls, a ruler, and one
## line per layer with a dot on every frame that holds a drawing. The camera
## is a line among them — it behaves like a layer and is told apart by its
## colour rather than by living somewhere else.
##
## There are exactly two ways to add a frame, because those are the two
## things an animator does: **new frame** starts blank, and **duplicate
## after** starts from the drawing before it so the last pose can be traced.
## Everything else was taken out.
##
## Everything below the head bar is drawn by hand in one `_draw`. A grid of
## six hundred cells built from nodes would spend longer laying itself out
## than the drawing does.

signal closed()

const TREE_W: float = 150.0
## Folder headers are shallower than layer rows, the way they are in the
## layers panel — the band is short and a folder is a label, not a track.
const GROUP_H: float = 30.0
const ROW_H: float = 30.0
const RULER_H: float = 26.0
const MIN_FRAME_W: float = 7.0
const MAX_FRAME_W: float = 56.0
const HOLD_MS: int = 340
const SLOP: float = 11.0

enum Mode { IDLE, WAITING, SCRUB, SCROLL, PAN, DRAG }

var player: AnimPlayer = null
var clip: Anim.Clip = null
var stack: LayerStack = null
var view: CanvasView = null

var frame_w: float = 13.0
var scroll_y: float = 0.0
## How far along the clip the grid is looking. Without it a long scene had
## an end nobody could reach: zooming out far enough to see frame six
## hundred left every dot too small to touch.
var scroll_x: float = 0.0

var _rows: Array = []          # {kind, layer, y}
var _content_h: float = 0.0
var _body: Control = null
var _head: HBoxContainer = null
var _play_btn: Button = null
var _onion_btn: Button = null
var _camera_btn: Button = null
var _layer_btn: Button = null

# --- one touch, one state machine ---
var _mode: int = Mode.IDLE
var _press_at: Vector2 = Vector2.ZERO
var _press_ms: int = 0
var _scroll_from: float = 0.0
var _touches: Dictionary = {}
var _pinch_from: float = 0.0
var _pinch_span: float = 0.0
var _drag_layer: LayerStack.Layer = null
var _drag_frame: int = -1
var _drag_camera: bool = false
var _drag_edge: bool = false
var _hold_action: Callable = Callable()
var _hold_ms: int = 0
## The key most recently made or touched, so the band can point at it.
var _last_key_frame: int = -1
## The curve a new key is born with. Changed from the Curves sheet, which
## is also where every existing key can be set at once.
var _default_ease: int = Anim.Ease.SMOOTH
var _readout: Label = null
var _pan_from: float = 0.0
var _body_hold_ms: int = 0
var _drag_focus: Variant = null
var _drag_focus_end: int = 1
var _tap_key: int = -1
## Two taps close together on the same point. Kept here rather than shared
## with the frame gestures, so a quick tap on a drawing and then on a focus
## point is never read as one double tap across the two.
var _tap_ms: int = 0
## How close together two taps have to be to count as one double tap. The
## focus gestures were written against a constant that lives in another
## script and does not exist here, so the whole panel refused to compile.
const DOUBLE_TAP_MS: int = 320
var _last_head_x: float = -99999.0

const ICON: String = "res://assets/icons/%s.png"
const TL_ICON: Dictionary = {
	"anim_play": "res://assets/timeline_supplied/start animation/icons8-play-64 (1).png",
	"anim_stop": "res://assets/timeline_supplied/stop animation/icons8-stop-64.png",
	"anim_prev": "res://assets/timeline_supplied/back frame/icons8-double-left-64.png",
	"anim_next": "res://assets/timeline_supplied/to frame/icons8-double-right-64.png",
	"depth_focus": "res://assets/icons/depth_focus.png",
	"add_frame": "res://assets/timeline_supplied/add frame or dublicet after/icons8-keyframes-64.png",
	"anim_camera": "res://assets/timeline_supplied/add camera kay/icons8-add-camera-64.png",
	"add_file": "res://assets/timeline_supplied/Choose an animation layer/icons8-folder-60.png",
	"anim_onion": "res://assets/timeline_supplied/onion skin/icons8-onion-64.png"
}

# ---------------------------------------------------------------- set up

func setup(anim_player: AnimPlayer, target_clip: Anim.Clip,
		target_stack: LayerStack, canvas: CanvasView) -> void:
	player = anim_player
	clip = target_clip
	stack = target_stack
	view = canvas

	add_theme_stylebox_override("panel", UiKit.rail_style())
	mouse_filter = Control.MOUSE_FILTER_STOP

	var column: VBoxContainer = VBoxContainer.new()
	column.add_theme_constant_override("separation", int(UiKit.s(2.0)))
	column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(column)

	# The toolbar contains every supplied timeline control. On a phone the
	# complete row is horizontally scrollable instead of squeezing icons until
	# their touch targets become unreliable.
	var rail: ScrollContainer = ScrollContainer.new()
	rail.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	rail.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	rail.custom_minimum_size = Vector2(0.0, UiKit.s(44.0))
	rail.mouse_filter = Control.MOUSE_FILTER_PASS
	column.add_child(rail)
	_build_head(rail)

	_body = Control.new()
	_body.mouse_filter = Control.MOUSE_FILTER_STOP
	_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_body.custom_minimum_size = Vector2(0.0, UiKit.s(RULER_H + ROW_H * 3.0))
	_body.draw.connect(_draw_body)
	_body.gui_input.connect(_body_input)
	column.add_child(_body)

	# Redrawing the whole band on every rendered frame of playback costs more
	# than the drawing does. The band only has something new to say when the
	# playhead has actually moved far enough to be seen moving, so that is
	# the only time it is asked to draw itself.
	player.frame_changed.connect(_on_frame_changed)
	player.playing_changed.connect(_show_transport)
	view.camera_framed.connect(_camera_changed)
	# Layers arriving, leaving or being foldered all change who is soft — a
	# focus worked out before that change is describing a stack that no
	# longer exists.
	stack.changed.connect(_apply_focus)
	stack.changed.connect(rebuild)
	_show_transport(player.playing)
	_sync_readout(int(floor(player.frame)))
	_apply_focus()
	rebuild()

func _on_frame_changed(_f: float) -> void:
	_apply_focus()
	var x: float = x_of(player.frame)
	if absf(x - _last_head_x) < 0.75:
		return
	_last_head_x = x
	_follow_playhead()
	refresh()

## Keeps the playhead on screen while it is moving, the way a page turns
## itself under a line of text being read.
func _follow_playhead() -> void:
	if _body == null or clip == null:
		return
	var grid: Rect2 = grid_rect()
	if grid.size.x <= 1.0:
		return
	var x: float = x_of(player.frame)
	var margin: float = minf(grid.size.x * 0.22, UiKit.s(90.0))
	if x > grid.position.x + grid.size.x - margin:
		_set_scroll_x(scroll_x + (x - (grid.position.x + grid.size.x - margin)))
	elif x < grid.position.x + margin:
		_set_scroll_x(scroll_x - ((grid.position.x + margin) - x))

func _sync_readout(f: int) -> void:
	if _readout == null or clip == null:
		return
	# Through the language rather than glued together, so the number can sit
	# where each language puts it — and so Arabic gets Arabic digits.
	_readout.text = Lang.fill("Frame {0} of {1}",
		[f + 1, maxi(clip.length, 1)], "الإطار {0} من {1}")

func _dirty() -> void:
	if view == null or view.projects == null:
		return
	var p: ProjectManager.Project = view.projects.active
	if p == null:
		return
	p.frames = maxi(clip.length, 1)
	p.fps = clampi(clip.fps, 1, 60)
	p.onion_skin = player.onion
	p.onion_back = clampi(player.onion_back, 0, 5)
	p.onion_forward = clampi(player.onion_forward, 0, 5)
	p.onion_back_tint = player.onion_back_tint
	p.onion_highlight = player.onion_highlight_tint
	p.onion_forward_tint = player.onion_forward_tint
	p.looping = player.looping
	view.projects.mark_dirty(p)

func _build_head(rail: ScrollContainer) -> void:
	_head = HBoxContainer.new()
	_head.add_theme_constant_override("separation", int(UiKit.s(5.0)))
	_head.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	rail.add_child(_head)

	# Play / Stop share one button. The supplied timeline assets are used for
	# both states: play when idle, stop while playing.
	_play_btn = _icon("anim_play", UiKit.label_for("Play animation", "تشغيل الحركة"),
		_toggle_play_stop)
	_play_btn.toggle_mode = false
	_head.add_child(_play_btn)
	var frame_readout: Label = UiKit.make_label("", 11.0, UiKit.TEXT_DIM)
	frame_readout.custom_minimum_size = Vector2(UiKit.s(94.0), UiKit.s(40.0))
	frame_readout.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	frame_readout.name = "FrameReadout"
	_head.add_child(frame_readout)
	_readout = frame_readout
	player.frame_index_changed.connect(_sync_readout)

	# Tap steps one frame. Held, they jump to the next drawing rather than the
	# next frame — on a scene held on twos or threes that is the difference
	# between eight taps and one press.
	# Stepping a frame turns the ghosts on.
	#
	# Moving to the next frame is the moment onion skin is *for*: you are
	# there to draw the frame after the one you just drew, and the one you
	# just drew is the thing you need to see. Leaving it off meant reaching
	# for a second button every single time, and the app knowing perfectly
	# well what you were about to want.
	var back: Button = _icon("anim_prev",
		UiKit.label_for("Previous frame", "الإطار السابق"),
		func() -> void: _step_frame(-1))
	back.button_down.connect(func() -> void:
		_hold_start(func() -> void: player.step_to_drawing(-1)))
	back.button_up.connect(_hold_end)
	_head.add_child(back)

	var fwd: Button = _icon("anim_next",
		UiKit.label_for("Next frame", "الإطار التالي"),
		func() -> void: _step_frame(1))
	fwd.button_down.connect(func() -> void:
		_hold_start(func() -> void: player.step_to_drawing(1)))
	fwd.button_up.connect(_hold_end)
	_head.add_child(fwd)

	# The supplied keyframe icon is dedicated to Duplicate After. A normal tap
	# always duplicates immediately. Long-pressing opens the frame insertion
	# settings, where a blank frame can be inserted between the current frame
	# and an already-existing next frame.
	var add: Button = _icon("add_frame", UiKit.label_for("Duplicate after", "نسخ بعده"),
		func() -> void: _add_frame(true))
	add.button_down.connect(func() -> void: _hold_start(_open_frame_settings))
	add.button_up.connect(_hold_end)
	_head.add_child(add)

	# Depth of field. It acts on the layer chosen in the band, because
	# choosing what is sharp is the thing this does — and the layer under
	# your finger is the thing you are thinking about.
	_head.add_child(_icon("depth_focus",
		UiKit.label_for("Shallow depth of field", "عمق ميدان ضحل"),
		_add_focus))

	# One button, two meanings, in the order an animator meets them: add the
	# camera to the scene, then add keys to the camera. Holding it steps in
	# and out of composing the shot on the canvas.
	_camera_btn = _icon("anim_camera",
		UiKit.label_for("Add camera", "أضف كاميرا"), _camera_button)
	_camera_btn.toggle_mode = true
	_camera_btn.button_down.connect(func() -> void: _hold_start(_toggle_camera_edit))
	_camera_btn.button_up.connect(_hold_end)
	_head.add_child(_camera_btn)

	_layer_btn = _icon("add_file", UiKit.label_for("Choose animation layer",
		"اختيار طبقة الرسوم المتحركة"), _open_animation_layer_picker)
	_head.add_child(_layer_btn)

	_onion_btn = _icon("anim_onion", UiKit.label_for("Onion skin", "قشرة البصل"),
		_toggle_onion)
	_onion_btn.toggle_mode = true
	_onion_btn.button_down.connect(func() -> void: _hold_start(_open_onion_settings))
	_onion_btn.button_up.connect(_hold_end)
	_head.add_child(_onion_btn)

	var spacer: Control = Control.new()
	spacer.custom_minimum_size = Vector2(UiKit.s(12.0), 1.0)
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_head.add_child(spacer)

	var curves: Button = UiKit.make_text_button(
		UiKit.label_for("Curves", "المنحنيات"), true)
	curves.custom_minimum_size = Vector2(UiKit.s(86.0), UiKit.s(40.0))
	curves.pressed.connect(_open_camera_curves)
	_head.add_child(curves)

	_head.add_child(_icon("settings_gear",
		UiKit.label_for("Timeline settings", "إعدادات التايم لاين"),
		_open_timeline_settings))

	var shut: Button = UiKit.make_text_button("▾")
	shut.custom_minimum_size = Vector2(UiKit.s(40.0), UiKit.s(40.0))
	shut.tooltip_text = UiKit.label_for("Hide the timeline", "أخفِ التايم لاين")
	shut.pressed.connect(func() -> void: closed.emit())
	_head.add_child(shut)

func _icon(icon_name: String, tip: String, action: Callable) -> Button:
	var b: Button = Button.new()
	b.tooltip_text = tip
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(UiKit.s(44.0), UiKit.s(40.0))
	var path: String = TL_ICON.get(icon_name, ICON % icon_name)
	if ResourceLoader.exists(path):
		b.icon = load(path)
	b.expand_icon = true
	b.add_theme_constant_override("icon_max_width", int(UiKit.s(21.0)))
	b.add_theme_color_override("icon_normal_color", UiKit.ON_RAIL)
	b.add_theme_color_override("icon_hover_color", Color.WHITE)
	b.add_theme_color_override("icon_pressed_color", Color("#1b1c22"))

	var flat: StyleBoxFlat = StyleBoxFlat.new()
	flat.bg_color = UiKit.RAIL_FILL
	flat.set_corner_radius_all(int(UiKit.s(9.0)))
	var hover: StyleBoxFlat = flat.duplicate() as StyleBoxFlat
	hover.bg_color = UiKit.RAIL_ON
	var on: StyleBoxFlat = flat.duplicate() as StyleBoxFlat
	on.bg_color = UiKit.ACCENT
	b.add_theme_stylebox_override("normal", flat)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", on)
	b.add_theme_stylebox_override("focus", flat)
	b.pressed.connect(action)
	return b

## Play / Stop is a single transport control. Its icon follows the current
## player state, using the supplied play and stop assets without changing the
## rest of the timeline toolbar.
func _toggle_play_stop() -> void:
	if player == null:
		return
	if player.playing:
		player.stop()
	else:
		player.play()

func _show_transport(on: bool) -> void:
	if _play_btn == null:
		return
	var icon_name: String = "anim_stop" if on else "anim_play"
	var path: String = TL_ICON.get(icon_name, ICON % icon_name)
	if ResourceLoader.exists(path):
		_play_btn.icon = load(path)
	_play_btn.tooltip_text = UiKit.label_for(
		"Stop animation" if on else "Play animation",
		"إيقاف الحركة" if on else "تشغيل الحركة")

# ---------------------------------------------------------------- layout

## One row per layer, top of the picture first, and the camera above them
## all — it frames everything, so it belongs at the top of the list.
func rebuild() -> void:
	_rows.clear()
	if stack == null or clip == null:
		refresh()
		return
	# A clip can never be shorter than the work inside it. Dragging a hold
	# out past the end, or loading a scene saved with a smaller length,
	# used to leave drawings sitting beyond the last frame — present in the
	# file, absent from playback and from every export.
	clip.grow_to_fit(stack)
	var y: float = 0.0
	if clip.camera_on:
		_rows.append({"kind": "camera", "layer": null, "y": y})
		y += UiKit.s(ROW_H)
	# The same order the layers panel shows, folders and all, taken from the
	# same call it uses. Two lists of the same layers in two different orders
	# is a thing nobody can hold in their head — you look at a row here and
	# count rows over there to find out which drawing it is.
	for entry in stack.display_rows():
		if String(entry["kind"]) == "group":
			_rows.append({"kind": "group", "layer": null,
				"gid": int(entry["gid"]), "y": y})
			y += UiKit.s(GROUP_H)
			continue
		var index: int = int(entry["index"])
		_rows.append({"kind": "layer", "layer": stack.layers[index],
			"index": index, "y": y})
		y += UiKit.s(ROW_H)
	_content_h = y
	refresh()

func refresh() -> void:
	if _onion_btn != null and player != null:
		_onion_btn.button_pressed = player.onion
	if _camera_btn != null and view != null and clip != null:
		_camera_btn.set_pressed_no_signal(view.camera_edit and clip.camera_on)
		_camera_btn.tooltip_text = UiKit.label_for("Add camera key",
			"إضافة مفتاح كاميرا") if clip.camera_on \
			else UiKit.label_for("Add camera", "أضف كاميرا")
	scroll_x = clampf(scroll_x, 0.0, _time_span())
	if _body != null:
		var down: float = maxf(_content_h - (_body.size.y - UiKit.s(RULER_H)), 0.0)
		scroll_y = clampf(scroll_y, 0.0, down)
	if player != null:
		_sync_readout(int(floor(player.frame + 0.000001)))
	if _body != null:
		_body.queue_redraw()

func grid_rect() -> Rect2:
	if _body == null:
		return Rect2()
	return Rect2(UiKit.s(TREE_W), 0.0,
		maxf(_body.size.x - UiKit.s(TREE_W), 1.0), _body.size.y)

func frame_at(x: float) -> float:
	return (x - grid_rect().position.x + scroll_x) / maxf(frame_w, 0.001)

func x_of(frame: float) -> float:
	return grid_rect().position.x + frame * frame_w - scroll_x

## The furthest the grid may travel: the end of the clip, plus a little air
## so the last drawing is not pinned against the edge of the screen.
func _time_span() -> float:
	if clip == null or _body == null:
		return 0.0
	var whole: float = float(maxi(clip.length, 1)) * frame_w
	return maxf(whole + UiKit.s(40.0) - grid_rect().size.x, 0.0)

func _set_scroll_x(value: float) -> void:
	var wanted: float = clampf(value, 0.0, _time_span())
	if absf(wanted - scroll_x) < 0.01:
		return
	scroll_x = wanted
	refresh()

## The first and last frame worth drawing, so a six-hundred frame clip does
## not cost six hundred circles a redraw.
func _visible_frames() -> Vector2i:
	var grid: Rect2 = grid_rect()
	var first: int = maxi(int(floor(frame_at(grid.position.x))) - 1, 0)
	var last: int = int(ceil(frame_at(grid.position.x + grid.size.x))) + 1
	return Vector2i(first, maxi(last, first))

# --------------------------------------------------------------- drawing

func _draw_body() -> void:
	if clip == null or _body == null or stack == null:
		return
	var grid: Rect2 = grid_rect()
	_body.draw_rect(Rect2(Vector2.ZERO, _body.size), Color("#181a20"), true)
	_body.draw_rect(Rect2(0.0, 0.0, UiKit.s(TREE_W), _body.size.y),
		Color("#1e2129"), true)

	_draw_ruler(grid)
	_draw_rows(grid)
	_draw_playhead(grid)

func _draw_ruler(grid: Rect2) -> void:
	var f: Font = ThemeDB.fallback_font
	var h: float = UiKit.s(RULER_H)
	_body.draw_rect(Rect2(grid.position.x, 0.0, grid.size.x, h),
		Color("#20242c"), true)

	var per_second: int = maxi(clip.fps, 1)
	var span: Vector2i = _visible_frames()
	var stop: int = mini(span.y, maxi(clip.length, 1))
	for i in range(span.x, stop + 1):
		var x: float = x_of(float(i))
		if x < grid.position.x - 2.0 or x > grid.position.x + grid.size.x:
			continue
		var second: bool = i % per_second == 0
		var col: Color = Color("#6c7385") if second else Color("#333846")
		_body.draw_line(Vector2(x, h * (0.35 if second else 0.6)),
			Vector2(x, h), col, 1.0)
		if second and f != null and frame_w >= 5.0:
			var mark: int = floori(float(i) / float(per_second))
			_body.draw_string(f, Vector2(x + UiKit.s(3.0), UiKit.s(12.0)),
				"%ds" % mark, HORIZONTAL_ALIGNMENT_LEFT, -1,
				int(UiKit.s(9.0)), Color("#7c8394"))

func _draw_rows(grid: Rect2) -> void:
	var f: Font = ThemeDB.fallback_font
	var top: float = UiKit.s(RULER_H)
	for entry in _rows:
		var y: float = top + float(entry["y"]) - scroll_y
		var tall: float = _row_height(entry)
		if y > _body.size.y or y + tall < top:
			continue

		if String(entry["kind"]) == "group":
			_draw_group_row(entry, grid, y, f)
			continue

		var camera: bool = entry["kind"] == "camera"
		var title: String = Lang.t("Camera") if camera \
			else (entry["layer"] as LayerStack.Layer).title
		var selected: bool = not camera \
			and int(entry["index"]) == stack.active_index

		# A row that is currently out of focus is dimmed here too, so the
		# band and the canvas agree about what is being looked at without
		# having to check one against the other.
		var sharp: float = 1.0
		if not camera:
			var lid: int = (entry["layer"] as LayerStack.Layer).id
			if stack.focus_sharpness.has(lid):
				sharp = float(stack.focus_sharpness[lid])
		if sharp < 0.995:
			_body.draw_rect(Rect2(0.0, y, _body.size.x, UiKit.s(ROW_H)),
				Color(0.03, 0.04, 0.06, (1.0 - sharp) * 0.42), true)

		if selected:
			_body.draw_rect(Rect2(0.0, y, _body.size.x, UiKit.s(ROW_H)),
				Color(1.0, 1.0, 1.0, 0.05), true)
		if f != null:
			_body.draw_string(f, Vector2(UiKit.s(12.0), y + UiKit.s(19.0)),
				title, HORIZONTAL_ALIGNMENT_LEFT,
				UiKit.s(TREE_W) - UiKit.s(18.0), int(UiKit.s(11.0)),
				Color("#dfe2ea") if selected else Color("#a8adba"))

		if camera:
			_draw_camera_row(grid, y)
		else:
			_draw_cel_row(entry["layer"], grid, y)
			_draw_focus_row(entry["layer"], grid, y)
		_body.draw_line(Vector2(0.0, y + UiKit.s(ROW_H)),
			Vector2(_body.size.x, y + UiKit.s(ROW_H)), Color("#242833"), 1.0)

	_body.draw_line(Vector2(grid.position.x, 0.0),
		Vector2(grid.position.x, _body.size.y), Color("#333846"), 1.5)

## A layer's drawings: a line the length of the clip, and a dot on every
## frame that holds one. The line says the layer exists for the whole clip;
## the dots say where its drawings change.
## Rows are not all the same height, so how tall one is has to be asked
## rather than assumed — which is what a hard-coded ROW_H everywhere meant.
func _row_height(entry: Dictionary) -> float:
	return UiKit.s(GROUP_H) if String(entry["kind"]) == "group" \
		else UiKit.s(ROW_H)

## A folder, in the band. It holds no drawings of its own, so it carries no
## track — it is here to say where in the stack the rows below it sit.
func _draw_group_row(entry: Dictionary, grid: Rect2, y: float, f: Font) -> void:
	var g: LayerStack.Group = stack.group_by_id(int(entry["gid"]))
	if g == null:
		return
	var tall: float = UiKit.s(GROUP_H)
	_body.draw_rect(Rect2(0.0, y, _body.size.x, tall), Color("#2e333d"), true)
	var animation: bool = g.is_animation
	if f != null:
		var mark: String = "▾ " if not g.collapsed else "▸ "
		# Not `name`: every Node already has one, and a local of that name
		# quietly shadows it. Harmless here, but the kind of shadow that
		# eventually has somebody debugging why setting a title renamed a
		# node.
		var caption: String = mark + g.title
		if animation:
			# An animation folder is a different kind of thing from a plain
			# one, and the band says so rather than leaving it to be found out
			# by pressing something and watching nothing happen.
			caption += "  ·  " + Lang.t("Animation layer")
		_body.draw_string(f, Vector2(UiKit.s(10.0), y + tall * 0.68), caption,
			HORIZONTAL_ALIGNMENT_LEFT, UiKit.s(TREE_W) - UiKit.s(14.0),
			int(UiKit.s(11.0)),
			Color("#e8d5a3") if animation else Color("#c3c8d4"))
	if animation:
		_body.draw_line(Vector2(grid.position.x, y + tall * 0.5),
			Vector2(minf(x_of(float(clip.length)),
				grid.position.x + grid.size.x), y + tall * 0.5),
			Color(0.85, 0.75, 0.55, 0.35), UiKit.s(2.0))
	_body.draw_line(Vector2(0.0, y + tall), Vector2(_body.size.x, y + tall),
		Color("#242833"), 1.0)

func _draw_cel_row(l: LayerStack.Layer, grid: Rect2, y: float) -> void:
	var mid: float = y + UiKit.s(ROW_H) * 0.5
	var ink: Color = Color("#d24b4b")
	var end: float = minf(x_of(float(clip.length)),
		grid.position.x + grid.size.x)
	_body.draw_line(Vector2(grid.position.x, mid), Vector2(end, mid),
		Color(ink.r, ink.g, ink.b, 0.55), UiKit.s(1.6))

	var showing: int = l.cels.frame_showing(int(round(player.frame)))
	var frames: Array = l.cels.frames()
	var right: float = grid.position.x + grid.size.x + 8.0
	for i in frames.size():
		var one: int = int(frames[i])
		var held: int = l.cels.hold_length(one, clip.length)
		var x0: float = x_of(float(one))
		var x1: float = x_of(float(one + held))
		if x0 > right:
			# The list is in frame order, so once one drawing starts past
			# the right edge every drawing after it does too.
			break
		if x1 < grid.position.x - 8.0:
			continue

		# A drawing is not an instant: it holds until the next one. Drawn as
		# a bar reaching that far, its duration can be read without counting
		# squares, and a long hold is obvious at a glance.
		var filled: bool = not (l.cels.cels[one]["png"] as PackedByteArray).is_empty()
		var bar: Rect2 = Rect2(x0 + UiKit.s(1.5), mid - UiKit.s(6.0),
			maxf(x1 - x0 - UiKit.s(3.0), UiKit.s(4.0)), UiKit.s(12.0))
		var body_ink: Color = Color(ink.r, ink.g, ink.b, 0.30 if filled else 0.12)
		_body.draw_rect(bar, body_ink, true)

		var r: float = UiKit.s(5.5)
		if one == showing:
			# The drawing on screen right now gets a ring, so the eye finds
			# it without counting along the row.
			_body.draw_circle(Vector2(x0, mid), r + UiKit.s(2.5),
				Color(1.0, 1.0, 1.0, 0.9))
		_body.draw_circle(Vector2(x0, mid), r, ink if filled else Color("#5a3030"))

		# The grip that lengthens the hold, shown only when it is reachable.
		if bar.size.x > UiKit.s(20.0):
			_body.draw_line(Vector2(x1 - UiKit.s(2.5), mid - UiKit.s(5.0)),
				Vector2(x1 - UiKit.s(2.5), mid + UiKit.s(5.0)),
				Color(ink.r, ink.g, ink.b, 0.75), UiKit.s(2.0))

## The camera's line is blue, and that is the only thing that tells it apart
## — it is a row like any other, which is what makes it easy to reach.
##
## Between two keys the line thickens into a bar, because that stretch is
## not empty: it is the move, filled in frame by frame from the poses at
## either end. A cut carries no bar, since nothing travels across it.
func _draw_camera_row(grid: Rect2, y: float) -> void:
	var mid: float = y + UiKit.s(ROW_H) * 0.5
	var ink: Color = Color("#4f8ede")
	var right: float = grid.position.x + grid.size.x
	var end: float = minf(x_of(float(clip.length)), right)
	_body.draw_line(Vector2(grid.position.x, mid), Vector2(end, mid),
		Color(ink.r, ink.g, ink.b, 0.55), UiKit.s(1.6))

	# --- the moves ---
	for i in range(clip.shots.size() - 1):
		var a: Anim.Shot = clip.shots[i]
		var b: Anim.Shot = clip.shots[i + 1]
		if a.ease_mode == Anim.Ease.HOLD:
			continue
		var x0: float = x_of(float(a.frame))
		var x1: float = x_of(float(b.frame))
		if x1 < grid.position.x - 8.0:
			continue
		if x0 > right + 8.0:
			break
		var travel: Rect2 = Rect2(x0, mid - UiKit.s(3.5),
			maxf(x1 - x0, UiKit.s(2.0)), UiKit.s(7.0))
		_body.draw_rect(travel, Color(ink.r, ink.g, ink.b, 0.34), true)
		# Whether the move is holding still, building or settling is read
		# off the shape of the bar rather than by opening the key.
		var lead: float = _ease_lead(a.ease_mode)
		if lead > 0.0 and travel.size.x > UiKit.s(14.0):
			_body.draw_rect(Rect2(travel.position.x, mid - UiKit.s(1.5),
				travel.size.x * lead, UiKit.s(3.0)),
				Color(ink.r, ink.g, ink.b, 0.62), true)

	# --- the keys ---
	for sh in clip.shots:
		var shot: Anim.Shot = sh
		var x: float = x_of(float(shot.frame))
		if x < grid.position.x - 8.0 or x > right + 8.0:
			continue
		if shot.frame == _last_key_frame:
			_body.draw_circle(Vector2(x, mid), UiKit.s(8.0),
				Color(1.0, 1.0, 1.0, 0.85))
		if shot.ease_mode == Anim.Ease.HOLD:
			# A held shot is square, so a cut reads differently from a move
			# without having to be tapped to find out.
			_body.draw_rect(Rect2(x - UiKit.s(4.5), mid - UiKit.s(4.5),
				UiKit.s(9.0), UiKit.s(9.0)), ink, true)
		else:
			_body.draw_circle(Vector2(x, mid), UiKit.s(5.5), ink)

## Where the speed of a move sits: nothing for an even one, weighted to the
## far end for a build, to the near end for a settle.
func _ease_lead(mode: int) -> float:
	if mode == Anim.Ease.IN:
		return 0.34
	if mode == Anim.Ease.OUT:
		return 0.72
	if mode == Anim.Ease.SMOOTH:
		return 0.5
	return 0.0

func _draw_playhead(grid: Rect2) -> void:
	if player == null:
		return
	var x: float = x_of(player.frame)
	if x < grid.position.x or x > grid.position.x + grid.size.x:
		return
	var glow: Color = UiKit.ACCENT
	_body.draw_line(Vector2(x, 0.0), Vector2(x, _body.size.y),
		Color(glow.r, glow.g, glow.b, 0.35), UiKit.s(4.0))
	_body.draw_line(Vector2(x, 0.0), Vector2(x, _body.size.y), glow, UiKit.s(1.4))
	var r: float = UiKit.s(7.0)
	_body.draw_colored_polygon(PackedVector2Array([
		Vector2(x, r * 2.0), Vector2(x + r, r), Vector2(x, 0.0),
		Vector2(x - r, r)]), glow)

# --------------------------------------------------------------- gestures

func _body_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		App.touch_mode = true
		var st: InputEventScreenTouch = event as InputEventScreenTouch
		if st.pressed:
			_touches[st.index] = st.position
			if _touches.size() >= 2:
				_begin_pinch()
			else:
				_press(st.position)
		else:
			_touches.erase(st.index)
			if _mode == Mode.DRAG and _touches.is_empty():
				_mode = Mode.IDLE
			elif _touches.is_empty():
				_release(st.position)
		_body.accept_event()
	elif event is InputEventScreenDrag:
		var sd: InputEventScreenDrag = event as InputEventScreenDrag
		_touches[sd.index] = sd.position
		if _touches.size() >= 2:
			_update_pinch()
		else:
			_move(sd.position)
		_body.accept_event()
	elif event is InputEventMouseButton:
		if App.touch_mode:
			return
		var mb: InputEventMouseButton = event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_press(mb.position)
			else:
				_release(mb.position)
			_body.accept_event()
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			_zoom_time(1.15)
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_zoom_time(1.0 / 1.15)
	elif event is InputEventMouseMotion and _mode != Mode.IDLE:
		_move((event as InputEventMouseMotion).position)

## As in the layers panel: awake only while something is being held.
func _process(_dt: float) -> void:
	_check_hold()
	_check_body_hold()
	if _hold_ms == 0 and _body_hold_ms == 0:
		set_process(false)

## A press held on a frame, rather than on a button — so the frame's own
## commands are reached from the frame itself.
func _check_body_hold() -> void:
	if _body_hold_ms == 0 or _mode != Mode.WAITING:
		return
	if Time.get_ticks_msec() - _body_hold_ms < HOLD_MS:
		return
	_body_hold_ms = 0
	_mode = Mode.IDLE
	if _drag_focus != null:
		_open_focus_menu(_drag_focus as Anim.Focus)
		_drag_focus = null
		return
	if _drag_camera:
		_open_camera_key_menu(_drag_frame)
	elif _drag_layer != null:
		_open_frame_menu(_drag_layer, _drag_frame)

func _press(at: Vector2) -> void:
	if player != null and player.playing:
		player.stop()
	_press_at = at
	_press_ms = Time.get_ticks_msec()
	_scroll_from = scroll_y
	_drag_layer = null
	_drag_frame = -1
	_drag_edge = false
	_drag_camera = false

	_pan_from = scroll_x
	_body_hold_ms = 0
	if at.y <= UiKit.s(RULER_H):
		_mode = Mode.SCRUB
		_scrub(at.x)
		return
	var found: Dictionary = _dot_at(at)
	if not found.is_empty():
		_drag_focus = found.get("focus", null)
		_drag_focus_end = int(found.get("end", 1))
		if _drag_focus != null:
			# Two taps on the closing point ask what kind of softness this
			# is — the same gesture that opens a frame's own settings.
			var key: int = int(found["frame"]) * 4 + _drag_focus_end + 2
			var now: int = Time.get_ticks_msec()
			if now - _tap_ms <= DOUBLE_TAP_MS and _tap_key == key:
				_tap_ms = 0
				_tap_key = -1
				_open_focus_menu(_drag_focus as Anim.Focus)
				_drag_focus = null
				_mode = Mode.IDLE
				return
			_tap_ms = now
			_tap_key = key
		_drag_layer = found.get("layer", null)
		_drag_camera = bool(found.get("camera", false))
		_drag_edge = bool(found.get("edge", false))
		_drag_frame = int(found["frame"])
		# A drawing held under the finger has more to say than "move me",
		# and a band this size has no room for a row of small buttons. So
		# the rest of what a frame can do is behind a hold on the frame.
		_body_hold_ms = Time.get_ticks_msec()
	_mode = Mode.WAITING
	set_process(true)

func _move(at: Vector2) -> void:
	if _mode == Mode.SCRUB:
		_scrub(at.x)
		return
	if _mode == Mode.WAITING:
		if _press_at.distance_to(at) <= SLOP * App.ui_scale:
			return
		_body_hold_ms = 0
		# Sideways means time, up and down means the list — whichever the
		# finger committed to first. Sideways on a drawing carries that
		# drawing; sideways on bare grid carries the whole clip past the
		# window, which is the only way to reach the end of a long scene.
		if absf(at.x - _press_at.x) > absf(at.y - _press_at.y):
			_mode = Mode.DRAG if _drag_frame >= 0 else Mode.PAN
		else:
			_mode = Mode.SCROLL
	if _mode == Mode.SCROLL:
		_set_scroll(_scroll_from - (at.y - _press_at.y))
	elif _mode == Mode.PAN:
		_set_scroll_x(_pan_from - (at.x - _press_at.x))
	elif _mode == Mode.DRAG:
		_drag_to(at.x)

func _release(at: Vector2) -> void:
	var was: int = _mode
	_mode = Mode.IDLE
	_body_hold_ms = 0
	if _drag_focus != null and was == Mode.DRAG:
		_drag_focus = null
		return
	if was == Mode.WAITING:
		_tap(at)
	_drag_layer = null
	_drag_frame = -1
	_drag_edge = false
	refresh()

func _tap(at: Vector2) -> void:
	if at.x < UiKit.s(TREE_W):
		var entry: Dictionary = _row_at(at.y)
		if entry.is_empty() or entry["kind"] != "layer":
			return
		stack.set_active(int(entry["index"]))
		refresh()
		return
	# Anywhere in the grid moves the playhead. Scrubbing should not demand
	# the ruler when the whole row means the same thing.
	var entry2: Dictionary = _row_at(at.y)
	if not entry2.is_empty() and entry2["kind"] == "layer":
		stack.set_active(int(entry2["index"]))
	_scrub(at.x)

func _row_at(y: float) -> Dictionary:
	var local: float = y - UiKit.s(RULER_H) + scroll_y
	for entry in _rows:
		var top: float = float(entry["y"])
		if local >= top and local < top + _row_height(entry):
			return entry
	return {}

func _dot_at(at: Vector2) -> Dictionary:
	var entry: Dictionary = _row_at(at.y)
	if entry.is_empty():
		return {}
	var reach: float = maxf(UiKit.s(12.0), frame_w * 0.5)
	if String(entry["kind"]) == "group":
		return {}
	if entry["kind"] == "camera":
		for s in clip.shots:
			if absf(x_of(float((s as Anim.Shot).frame)) - at.x) <= reach:
				return {"camera": true, "frame": (s as Anim.Shot).frame}
		return {}

	var l: LayerStack.Layer = entry["layer"]

	# The focus line sits a little above the layer's own, so it is checked
	# first — a finger reaching for it should never come away holding a
	# drawing instead.
	var lift: float = float(entry["y"]) + UiKit.s(ROW_H) * 0.5 - UiKit.s(7.0)
	var local_y: float = at.y - UiKit.s(RULER_H) + scroll_y
	if absf(local_y - lift) <= UiKit.s(9.0):
		for f in clip.focus_for(l.id):
			var one: Anim.Focus = f as Anim.Focus
			if absf(x_of(float(one.to_frame)) - at.x) <= reach:
				return {"focus": one, "end": 1, "frame": one.to_frame}
			if absf(x_of(float(one.from_frame)) - at.x) <= reach:
				return {"focus": one, "end": 0, "frame": one.from_frame}

	# The right edge first: it is a separate grip, and it lengthens the hold
	# rather than moving the drawing somewhere else.
	for frame in l.cels.frames():
		var one: int = int(frame)
		var held: int = l.cels.hold_length(one, clip.length)
		if absf(x_of(float(one + held)) - at.x) <= UiKit.s(11.0):
			return {"layer": l, "frame": one, "edge": true}
	for frame2 in l.cels.frames():
		if absf(x_of(float(int(frame2))) - at.x) <= reach:
			return {"layer": l, "frame": int(frame2), "edge": false}
	return {}

## Dragging a focus point stretches the line rather than moving it whole: the
## first point is where focus arrives and the second is where it leaves, and
## each is dragged to wherever that should be.
func _drag_focus_to(x: float) -> void:
	if _drag_focus == null:
		return
	var one: Anim.Focus = _drag_focus as Anim.Focus
	var want: int = clampi(int(round(frame_at(x))), 0, Anim.CEILING_FRAMES - 1)
	if _drag_focus_end == 0:
		one.from_frame = mini(want, one.to_frame)
	else:
		one.to_frame = maxi(want, one.from_frame)
	clip.grow_to_fit(stack, one.to_frame)
	_apply_focus()
	_dirty()
	refresh()

func _drag_to(x: float) -> void:
	if _drag_focus != null:
		_drag_focus_to(x)
		return
	var to: int = clampi(int(round(frame_at(x))), 0, maxi(clip.length - 1, 0))
	# The edge grip is measured from the end of the hold, not from the
	# drawing's own frame, so it must not be turned away by this guard.
	if to == _drag_frame and not _drag_edge:
		return
	if _drag_camera:
		var shot: Anim.Shot = clip.shot_at(_drag_frame)
		if shot == null or clip.shot_at(to) != null:
			return
		clip.drop_shot(_drag_frame)
		clip.set_shot(to, shot.offset, shot.zoom, shot.ease_mode, shot.rotation)
	elif _drag_layer != null and _drag_edge:
		# Lengthening a hold pushes everything after it along, so the
		# drawings that follow keep their own durations instead of being
		# eaten by the one being stretched.
		var held: int = _drag_layer.cels.hold_length(_drag_frame, clip.length)
		var wanted: int = clampi(to - _drag_frame, 1, 600)
		if wanted == held:
			return
		_drag_layer.cels.shift_after(_drag_frame, wanted - held)
		clip.length = maxi(clip.length, _drag_frame + wanted)
		player.refresh_visuals()
		refresh()
		return
	elif _drag_layer != null:
		if _drag_layer.cels.has_frame(to):
			return
		_drag_layer.cels.move_frame(_drag_frame, to)
	_drag_frame = to
	player.apply()
	refresh()

func _begin_pinch() -> void:
	_mode = Mode.IDLE
	_body_hold_ms = 0
	_drag_layer = null
	_drag_frame = -1
	_drag_edge = false
	_pinch_span = _span()
	_pinch_from = frame_w

func _update_pinch() -> void:
	var span: float = _span()
	if _pinch_span < 8.0 or span < 8.0:
		return
	# The frame between the fingers is the one being held on to, so the
	# clip is scrolled to keep it where it was rather than letting the
	# whole scene slide away from under the pinch.
	var anchor: float = frame_at(_pinch_mid_x())
	frame_w = clampf(_pinch_from * (span / _pinch_span), MIN_FRAME_W, MAX_FRAME_W)
	var grid: Rect2 = grid_rect()
	scroll_x = clampf(anchor * frame_w - (_pinch_mid_x() - grid.position.x),
		0.0, _time_span())
	refresh()

func _pinch_mid_x() -> float:
	var keys: Array = _touches.keys()
	if keys.size() < 2:
		return grid_rect().get_center().x
	return ((_touches[keys[0]] as Vector2).x + (_touches[keys[1]] as Vector2).x) * 0.5

func _span() -> float:
	var keys: Array = _touches.keys()
	if keys.size() < 2:
		return 0.0
	return (_touches[keys[0]] as Vector2).distance_to(_touches[keys[1]] as Vector2)

func _zoom_time(factor: float) -> void:
	frame_w = clampf(frame_w * factor, MIN_FRAME_W, MAX_FRAME_W)
	scroll_x = clampf(scroll_x, 0.0, _time_span())
	refresh()

func _scrub(x: float) -> void:
	if player == null or clip == null:
		return
	player.seek(clampf(frame_at(x), 0.0, float(maxi(clip.length - 1, 0))))

func _set_scroll(value: float) -> void:
	var span: float = maxf(_content_h - (_body.size.y - UiKit.s(RULER_H)), 0.0)
	scroll_y = clampf(value, 0.0, span)
	refresh()

func _open_animation_layer_picker() -> void:
	if stack == null:
		return
	var sheet: PanelContainer = _sheet()
	var v: VBoxContainer = _sheet_column(sheet,
		UiKit.label_for("Choose animation layer", "اختيار طبقة الرسوم المتحركة"))
	for i in range(stack.layers.size() - 1, -1, -1):
		var layer: LayerStack.Layer = stack.layers[i]
		var index: int = i
		var b: Button = UiKit.make_text_button(layer.title, index == stack.active_index)
		b.toggle_mode = true
		b.set_pressed_no_signal(index == stack.active_index)
		b.pressed.connect(func() -> void:
			stack.set_active(index)
			_shut_sheet()
			refresh())
		v.add_child(b)
	_float_sheet(sheet)

# ------------------------------------------------------------- the frames

## A drawing on this layer at this frame — never a new layer.
##
## `carry_on` starts it from the drawing before it, which is what tracing a
## movement wants; blank is what a fresh pose wants. Those are the two ways,
## and there is no third.
## Adding a frame — except where frames are not the way the layer moves.
##
## On a rigged layer this walks forward and does nothing else: it does not
## make a frame, and it does not touch the one that is there. The drawing
## stays exactly as it was and the playhead moves on, which is all that was
## wanted from the button in the first place on a layer that is posed rather
## than redrawn.
## A step, with the ghosts brought up behind it.
##
## Onion skin is turned on rather than toggled, and only in one direction:
## stepping never turns it off. If you have deliberately switched the ghosts
## off, the onion button is where you do that and it stays done — but arriving
## at an empty frame with nothing to draw against is not a state anybody
## chooses on purpose, and it was one button away every single time.
##
## At least one frame back, too. The ghosts being *on* with a look-back of
## nought shows nothing at all, which looks exactly like the feature being
## broken.
func _step_frame(by: int) -> void:
	if player == null:
		return
	player.step(by)
	if not player.onion:
		player.onion = true
		player.onion_back = maxi(player.onion_back, 1)
		if _onion_btn != null and is_instance_valid(_onion_btn):
			_onion_btn.button_pressed = true
		_dirty()
	player.refresh_visuals()
	refresh()

func _add_frame(carry_on: bool) -> void:
	if stack != null and stack.active_frames_locked():
		var here: int = int(round(player.frame))
		player.seek(float(clampi(here + 1, 0, maxi(clip.length - 1, 0))))
		_flash_locked()
		refresh()
		return
	_add_frame_now(carry_on)

func _flash_locked() -> void:
	var l: LayerStack.Layer = stack.layers[clampi(stack.active_index, 0,
		stack.layers.size() - 1)] if not stack.layers.is_empty() else null
	if l != null and not l.rig.is_empty():
		_tell_row(UiKit.label_for(
			"This layer is posed, not redrawn — moved on a frame instead",
			"هذه الطبقة تُحرَّك بالوضعيات لا بالرسم — تقدّم إطاراً بدل ذلك"))
	else:
		_tell_row(UiKit.label_for(
			"Animation folder — frames come from the layers inside it",
			"مجلد تحريك — الإطارات تأتي من الطبقات التي بداخله"))

func _tell_row(text: String) -> void:
	if _readout != null:
		_readout.text = text

func _add_frame_now(carry_on: bool) -> void:
	if stack == null or player == null or clip == null:
		return
	var index: int = stack.active_index
	if index < 0 or index >= stack.layers.size():
		return
	var l: LayerStack.Layer = stack.layers[index]
	var frame: int = clampi(int(floor(player.frame + 0.000001)), 0, maxi(clip.length - 1, 0))

	# Frame 0 is always the real first cel. If the user already drew there,
	# keep that drawing and never turn it into another page.
	if frame == 0 and l.cels.is_empty():
		l.cels.capture_surface(l.surface, 0)
		player.frame = 0.0
		player.onion = false
		player.refresh_visuals()
		stack.changed.emit()
		_dirty()
		rebuild()
		return

	# Duplicate After is explicit: the new cel is placed at frame + 1 only
	# when that destination is genuinely empty. An existing drawing is never
	# overwritten; the insert command handles that case by shifting it right.
	var target: int = frame + 1
	if target >= clip.length:
		clip.grow_to_fit(stack, target)
	if not l.cels.has_frame(frame):
		l.cels.capture_surface(l.surface, frame)
	if l.cels.has_frame(target):
		return
	l.cels.add_frame(l.surface, target, carry_on)
	_carry_pose(l, frame, target)
	player.frame = float(target)
	player.onion = true
	player.refresh_visuals()
	stack.changed.emit()
	_dirty()
	rebuild()

## Duplicate After carries the *pose* forward as well as the drawing.
##
## This is the join between the two halves of the app, and it was missing.
## Both kinds of bone live on the layer's `poses` track: the flat 2-D bones
## bent in the B-Spline room, and the turnaround's own rig. Duplicating a
## frame without them meant the drawing arrived at the new frame and the
## skeleton stayed behind on the old one — so the very next bend keyed a pose
## that had no previous key to travel from, and the app looked as though bones
## and frames were two unrelated features.
##
## Carried, not blended. Duplicate After exists to give you *the same thing,
## one frame later*, as a place to change something — so the new key is an
## exact copy of the old one and the tween between them is flat until you move
## something. That is what an animator means by duplicating a frame.
##
## Nothing is created for a layer that has no poses. An unrigged drawing stays
## an unrigged drawing, and no empty key appears on the band to be wondered at.
func _carry_pose(l: LayerStack.Layer, frame: int, target: int) -> void:
	if l == null or l.poses == null or l.poses.is_empty():
		return
	if l.poses.has_key(target):
		return
	# Read at `frame` rather than from the key at `frame`: the drawing being
	# duplicated may sit between two keys, and what should carry forward is
	# the pose that was on screen, not the last one that happened to be
	# written down.
	var pose: Dictionary = l.poses.pose_at(float(frame))
	if pose.is_empty():
		return
	var made: RigTrack.RigKey = l.poses.touch(target)
	if pose.has("along"):
		made.along = pose["along"]
	if pose.has("bones"):
		made.bones = pose["bones"]
	if pose.has("pins"):
		made.pins = pose["pins"]
	if pose.has("turn"):
		made.turn = float(pose["turn"])
		made.has_turn = true

## Same rule as the frame button: a posed layer does not gain blank frames
## from anywhere, not from the button and not from a menu behind it.
func _insert_blank_after_current() -> void:
	if stack != null and stack.active_frames_locked():
		_flash_locked()
		return
	_insert_blank_now()

func _insert_blank_now() -> void:
	if stack == null or player == null or clip == null:
		return
	var current: int = clampi(int(floor(player.frame + 0.000001)), 0, maxi(clip.length - 1, 0))
	stack.insert_blank_frame_after(current)
	clip.insert_frame_after(current)
	# The clip has now grown by one frame, and all content after the insertion
	# point moved to the right. Activate the inserted blank frame.
	player.frame = float(current + 1)
	player.onion = true
	player.onion_back = maxi(player.onion_back, 1)
	player.refresh_visuals()
	_dirty()
	rebuild()

## What a single drawing can do, reached by holding that drawing.
##
## Until now a frame could be added and moved but never taken back, so a
## mistaken frame stayed in the scene for good. Delete is the reason this
## menu exists; the rest is here because the finger is already on the frame.
func _open_frame_menu(l: LayerStack.Layer, frame: int) -> void:
	if l == null or clip == null:
		return
	var sheet: PanelContainer = _sheet()
	var v: VBoxContainer = _sheet_column(sheet,
		"%s %d" % [UiKit.label_for("Frame", "فريم"), frame + 1])
	_sheet_note(v, l.title)

	var go: Button = UiKit.make_text_button(
		UiKit.label_for("Go to this frame", "اذهب إلى هذا الإطار"), true)
	go.pressed.connect(func() -> void:
		_shut_sheet()
		player.seek(float(frame)))
	v.add_child(go)

	var copy: Button = UiKit.make_text_button(
		UiKit.label_for("Duplicate after", "نسخ بعده"), true)
	copy.pressed.connect(func() -> void:
		_shut_sheet()
		player.seek(float(frame))
		_add_frame(true))
	v.add_child(copy)

	var blank: Button = UiKit.make_text_button(
		UiKit.label_for("Insert blank after current", "وضع إطار فارغ بعد الحالي"), true)
	blank.pressed.connect(func() -> void:
		_shut_sheet()
		player.seek(float(frame))
		_insert_blank_after_current())
	v.add_child(blank)

	var wipe: Button = UiKit.make_text_button(
		UiKit.label_for("Clear this drawing", "امسح هذا الرسم"), true)
	wipe.pressed.connect(func() -> void:
		_shut_sheet()
		_clear_frame(l, frame))
	v.add_child(wipe)
	_sheet_note(v, UiKit.label_for(
		"The frame stays where it is and keeps its timing. Only the drawing on it goes.",
		"يبقى الإطار مكانه ويحتفظ بتوقيته، ولا يذهب إلا الرسم الذي عليه."))

	# Frame zero is the layer's own drawing. Removing it would leave the
	# layer with a track and nothing in it, so it is emptied instead.
	if frame > 0:
		var armed: Array = [false]
		var kill: Button = UiKit.make_text_button(
			UiKit.label_for("Delete frame", "احذف الإطار"), true)
		kill.pressed.connect(func() -> void:
			if not armed[0]:
				armed[0] = true
				kill.text = UiKit.label_for("Tap again to delete",
					"اضغط ثانية للحذف")
				return
			_shut_sheet()
			_delete_frame(l, frame))
		v.add_child(kill)
	_float_sheet(sheet)

func _clear_frame(l: LayerStack.Layer, frame: int) -> void:
	if l == null or player == null:
		return
	stack.commit_all_cels()
	l.cels.cels[frame] = {"png": PackedByteArray(), "at": Vector2i.ZERO,
		"size": Vector2i.ZERO}
	if l.cels.loaded == frame:
		l.surface.clear_all()
	player.apply(true, false)
	player.refresh_visuals()
	stack.changed.emit()
	_dirty()
	rebuild()

func _delete_frame(l: LayerStack.Layer, frame: int) -> void:
	if l == null or player == null or frame <= 0:
		return
	stack.commit_all_cels()
	l.cels.remove_frame(frame)
	# The playhead may have been standing on what just went; the drawing
	# that holds through this moment is loaded in its place rather than
	# leaving the layer showing nothing.
	player.apply(true, false)
	player.refresh_visuals()
	stack.changed.emit()
	_dirty()
	rebuild()

## The camera key under the finger — moved by dragging it, removed here.
func _open_camera_key_menu(frame: int) -> void:
	if clip == null:
		return
	var sheet: PanelContainer = _sheet()
	var v: VBoxContainer = _sheet_column(sheet,
		"%s %d" % [UiKit.label_for("Camera key", "مفتاح الكاميرا"), frame + 1])

	var go: Button = UiKit.make_text_button(
		UiKit.label_for("Go to this frame", "اذهب إلى هذا الإطار"), true)
	go.pressed.connect(func() -> void:
		_shut_sheet()
		player.seek(float(frame)))
	v.add_child(go)

	var recut: Button = UiKit.make_text_button(
		UiKit.label_for("Reframe from the canvas", "أعد التأطير من اللوحة"), true)
	recut.pressed.connect(func() -> void:
		_shut_sheet()
		player.seek(float(frame))
		if view != null and not view.camera_edit:
			_toggle_camera_edit())
	v.add_child(recut)

	# The curve belongs to the key it leaves from, so it is set here rather
	# than only for the whole scene at once: a shot can build into one move
	# and settle out of the next.
	_vlabel(v, UiKit.label_for("Travel to the next key", "الانتقال إلى المفتاح التالي"))
	var here: Anim.Shot = clip.shot_at(frame)
	var current: int = here.ease_mode if here != null else Anim.Ease.SMOOTH
	for row in _ease_choices():
		var mode: int = int(row[0])
		var b: Button = UiKit.make_text_button(String(row[1]), true)
		b.toggle_mode = true
		b.set_pressed_no_signal(mode == current)
		b.pressed.connect(func() -> void:
			var target: Anim.Shot = clip.shot_at(frame)
			if target != null:
				target.ease_mode = mode
			player.apply(true, false)
			_dirty()
			_shut_sheet()
			rebuild())
		v.add_child(b)

	var armed: Array = [false]
	var kill: Button = UiKit.make_text_button(
		UiKit.label_for("Delete camera key", "احذف مفتاح الكاميرا"), true)
	kill.pressed.connect(func() -> void:
		if not armed[0]:
			armed[0] = true
			kill.text = UiKit.label_for("Tap again to delete", "اضغط ثانية للحذف")
			return
		_shut_sheet()
		clip.drop_shot(frame)
		if _last_key_frame == frame:
			_last_key_frame = -1
		player.apply(true, false)
		_dirty()
		rebuild())
	v.add_child(kill)
	_float_sheet(sheet)

func _open_frame_settings() -> void:
	var sheet: PanelContainer = _sheet()
	var v: VBoxContainer = _sheet_column(sheet,
		UiKit.label_for("Frame insertion", "إضافة إطار"))

	var copy: Button = UiKit.make_text_button(
		UiKit.label_for("Duplicate after", "نسخ بعده"), true)
	copy.pressed.connect(func() -> void:
		_shut_sheet()
		_add_frame(true))
	v.add_child(copy)
	_sheet_note(v, UiKit.label_for(
		"Copies the current drawing into the next empty frame. It never overwrites an existing frame.",
		"ينسخ الرسم الحالي إلى الإطار الفارغ التالي ولا يكتب فوق إطار موجود."))

	var insert_blank: Button = UiKit.make_text_button(
		UiKit.label_for("Insert blank after current", "وضع إطار فارغ بعد الحالي"), true)
	insert_blank.pressed.connect(func() -> void:
		_shut_sheet()
		_insert_blank_after_current())
	v.add_child(insert_blank)
	_sheet_note(v, UiKit.label_for(
		"If another drawn frame already exists immediately after the current one, it is shifted right and the new blank frame is inserted between them.",
		"إذا كان هناك فريم مرسوم مباشرة بعد الحالي، يُزاح إلى اليمين ويُدرج الفريم الفارغ بينهما."))
	_float_sheet(sheet)

# ------------------------------------------------------------ depth of field

## Puts a focus line on the chosen layer.
##
## It opens as a short span — two points close together, just above the
## layer's own line — and is dragged out to however long the shot holds focus
## there. Everything without a line of its own goes soft for as long as this
## one runs, which is what depth of field *is*: choosing the subject and
## choosing the blur are one act.
func _add_focus() -> void:
	if clip == null or stack == null or stack.layers.is_empty():
		return
	var l: LayerStack.Layer = stack.layers[clampi(stack.active_index, 0,
		stack.layers.size() - 1)]
	var here: int = clampi(int(round(player.frame)), 0, maxi(clip.length - 1, 0))
	for f in clip.focus_for(l.id):
		var one: Anim.Focus = f as Anim.Focus
		if here >= one.from_frame and here <= one.to_frame:
			_tell_row(UiKit.label_for("This layer is already the subject here",
				"هذه الطبقة هي الموضوع هنا بالفعل"))
			return
	clip.add_focus(l.id, here, here + 2)
	clip.grow_to_fit(stack, here + 2)
	_apply_focus()
	_dirty()
	rebuild()

## Hands the current focus to the layers, so what is on the band and what is
## on the canvas are the same thing.
func _apply_focus() -> void:
	if stack == null or clip == null or player == null:
		return
	stack.apply_focus(clip, int(floor(player.frame + 0.000001)))

## The focus line for a layer, drawn just above its own line so the two read
## as belonging together without ever being mistaken for each other.
func _draw_focus_row(l: LayerStack.Layer, grid: Rect2, y: float) -> void:
	var spans: Array = clip.focus_for(l.id)
	if spans.is_empty():
		return
	var lift: float = y + UiKit.s(ROW_H) * 0.5 - UiKit.s(7.0)
	var right: float = grid.position.x + grid.size.x
	var gold: Color = Color("#E8C46A")
	for f in spans:
		var one: Anim.Focus = f as Anim.Focus
		var x0: float = x_of(float(one.from_frame))
		var x1: float = x_of(float(one.to_frame))
		if x1 < grid.position.x - 10.0 or x0 > right + 10.0:
			continue
		_body.draw_line(Vector2(x0, lift), Vector2(x1, lift),
			Color(gold.r, gold.g, gold.b, 0.75), UiKit.s(3.0))
		if one.mode == Anim.Blur.CINEMATIC:
			# The quarter over which the pull arrives, drawn as the part of
			# the line that is still thickening.
			var quarter: float = x0 + (x1 - x0) * 0.25
			_body.draw_line(Vector2(x0, lift), Vector2(quarter, lift),
				Color(gold.r, gold.g, gold.b, 0.35), UiKit.s(6.0))
		_body.draw_circle(Vector2(x0, lift), UiKit.s(4.5), gold)
		if one.mode == Anim.Blur.HARD:
			_body.draw_rect(Rect2(x1 - UiKit.s(4.5), lift - UiKit.s(4.5),
				UiKit.s(9.0), UiKit.s(9.0)), gold, true)
		else:
			_body.draw_circle(Vector2(x1, lift), UiKit.s(5.5), gold)
			_body.draw_arc(Vector2(x1, lift), UiKit.s(5.5), 0.0, TAU, 16,
				Color("#FFF8E7"), UiKit.s(1.4))

## What kind of softness this line brings on.
func _open_focus_menu(one: Anim.Focus) -> void:
	var sheet: PanelContainer = _sheet()
	var v: VBoxContainer = _sheet_column(sheet,
		UiKit.label_for("Depth of field", "عمق الميدان"))
	_sheet_note(v, UiKit.label_for(
		"Everything without a focus line of its own goes soft while this one runs.",
		"كل ما ليس عليه خط تركيز خاص به يصبح ضبابياً ما دام هذا الخط ممتداً."))

	var cut: Button = UiKit.make_text_button(
		UiKit.label_for("Full blur, no build-up", "ضبابية كاملة بلا تدرج"), true)
	cut.toggle_mode = true
	cut.set_pressed_no_signal(one.mode == Anim.Blur.HARD)
	cut.pressed.connect(func() -> void:
		one.mode = Anim.Blur.HARD
		_apply_focus()
		_dirty()
		_shut_sheet()
		refresh())
	v.add_child(cut)

	var pull: Button = UiKit.make_text_button(
		UiKit.label_for("Cinematic fade", "تلاشٍ سينمائي"), true)
	pull.toggle_mode = true
	pull.set_pressed_no_signal(one.mode == Anim.Blur.CINEMATIC)
	pull.pressed.connect(func() -> void:
		one.mode = Anim.Blur.CINEMATIC
		_apply_focus()
		_dirty()
		_shut_sheet()
		refresh())
	v.add_child(pull)
	_sheet_note(v, UiKit.label_for(
		"The blur comes on across the first quarter of the line and holds for the rest, the way a focus pull settles.",
		"تأتي الضبابية عبر الربع الأول من الخط وتثبت في بقيته، كما تستقر نقلة التركيز."))

	UiKit.slider_row(v, UiKit.label_for("How soft", "مقدار الضبابية"),
		0.15, 1.0, one.strength, 0.05, "",
		func(x: float) -> void:
			one.strength = x
			_apply_focus()
			_dirty())

	v.add_child(HSeparator.new())
	var armed: Array = [false]
	var kill: Button = UiKit.make_text_button(
		UiKit.label_for("Remove this focus line", "احذف خط التركيز"), true)
	kill.pressed.connect(func() -> void:
		if not armed[0]:
			armed[0] = true
			kill.text = UiKit.label_for("Tap again to delete", "اضغط ثانية للحذف")
			return
		clip.drop_focus(one)
		_apply_focus()
		_dirty()
		_shut_sheet()
		rebuild())
	v.add_child(kill)
	_float_sheet(sheet)

# ------------------------------------------------------------- the camera

## The camera, in the order it is met.
##
## The first press puts a camera in the scene: a row appears above every
## layer, the frame is drawn on the page, and the first key is set right
## there so the shot has a starting pose. Every press after that adds a key
## at the playhead.
func _camera_button() -> void:
	if clip == null or view == null:
		return
	if not clip.camera_on:
		_add_camera_track()
		return
	_add_camera_key()

func _add_camera_track() -> void:
	clip.camera_on = true
	# Composing starts immediately: a camera with no frame drawn on the page
	# is a row of dots with nothing to aim.
	view.set_camera_edit(true)
	if _camera_btn != null:
		_camera_btn.set_pressed_no_signal(true)
		_camera_btn.tooltip_text = UiKit.label_for("Add camera key",
			"إضافة مفتاح كاميرا")
	_add_camera_key()
	_dirty()
	rebuild()

## Keyed from the frame as it is drawn on screen, never from numbers typed
## at it. That is the difference between a camera you compose and a camera
## you configure.
##
## A key holds the whole pose at one moment: where the frame sits, how much
## of the page it keeps, and how far it is turned. Two keys are a move —
## everything between them is filled in from the two poses and the curve on
## the earlier key, at whatever rate the scene runs at.
func _add_camera_key() -> void:
	if clip == null or player == null or view == null:
		return
	if not view.camera_edit:
		view.set_camera_edit(true)
	var now: Dictionary = view.camera_values()
	if now.is_empty():
		return
	var frame: int = clampi(int(round(player.frame)), 0, maxi(clip.length - 1, 0))
	var ease_mode: int = _default_ease
	var here: Anim.Shot = clip.shot_at(frame)
	if here != null:
		ease_mode = here.ease_mode
	clip.set_shot(frame, Vector2(float(now["x"]), float(now["y"])),
		float(now["zoom"]), ease_mode, float(now.get("rotation", 0.0)))
	_last_key_frame = frame
	_dirty()
	rebuild()

## While the shot is being composed on the canvas, what the hand does goes
## into the key at the playhead.
##
## The old behaviour tried to guess a second key somewhere ahead of you and
## wrote into that instead, so framing a shot could move a key you were not
## looking at. A key belongs to the moment it was made at, and nowhere else.
## Nothing is keyed unless composing is switched on, so scrubbing a scene
## can never leave keys behind it.
func _camera_changed(_shot: Rect2) -> void:
	if clip == null or player == null or view == null:
		return
	if not clip.camera_on or not view.camera_edit:
		return
	var now: Dictionary = view.camera_values()
	if now.is_empty():
		return
	var frame: int = clampi(int(round(player.frame)), 0, maxi(clip.length - 1, 0))
	var here: Anim.Shot = clip.shot_at(frame)
	var ease_mode: int = here.ease_mode if here != null else _default_ease
	clip.set_shot(frame, Vector2(float(now["x"]), float(now["y"])),
		float(now["zoom"]), ease_mode, float(now.get("rotation", 0.0)))
	_last_key_frame = frame
	player.apply(true, false)
	_dirty()
	rebuild()

func _toggle_camera_edit() -> void:
	if view == null or clip == null:
		return
	if not clip.camera_on:
		_add_camera_track()
		return
	view.set_camera_edit(not view.camera_edit)
	if _camera_btn != null:
		_camera_btn.set_pressed_no_signal(view.camera_edit)
	refresh()

## The list of curves, in one place, so the sheet and the key menu can
## never drift apart.
func _ease_choices() -> Array:
	return [
		[Anim.Ease.SMOOTH, UiKit.label_for("Ease in and out", "تسارع وتباطؤ")],
		[Anim.Ease.IN, UiKit.label_for("Ease in — start slowly", "تسارع — يبدأ ببطء")],
		[Anim.Ease.OUT, UiKit.label_for("Ease out — arrive slowly", "تباطؤ — يصل ببطء")],
		[Anim.Ease.LINEAR, UiKit.label_for("Even speed", "سرعة ثابتة")],
		[Anim.Ease.HOLD, UiKit.label_for("Cut", "قطع")],
	]

## How the camera travels between its keys.
##
## Two keys and the frames between them are the whole of a camera move: the
## app measures how far along each in-between frame is and bends that
## number by the curve chosen here. A straight line reads as machinery; a
## shot that leaves slowly and arrives slowly reads as a camera someone is
## holding.
func _open_camera_curves() -> void:
	var sheet: PanelContainer = _sheet()
	var v: VBoxContainer = _sheet_column(sheet,
		UiKit.label_for("Camera", "الكاميرا"))
	_sheet_note(v, UiKit.label_for(
		"Key the first shot, go to a later frame, frame it again. Every frame between the two is filled in for you at the scene's own rate.",
		"ثبّت اللقطة الأولى، ثم اذهب إلى إطار لاحق وأعد التأطير. وكل إطار بينهما يُملأ لك تلقائياً بمعدل المشهد نفسه."))

	_vlabel(v, UiKit.label_for("New keys use", "المفاتيح الجديدة تستخدم"))
	var buttons: Array = []
	var choices: Array = _ease_choices()
	for i in choices.size():
		var mode: int = int(choices[i][0])
		var index: int = i
		var b: Button = UiKit.make_text_button(String(choices[i][1]), true)
		b.toggle_mode = true
		b.set_pressed_no_signal(mode == _default_ease)
		b.pressed.connect(func() -> void:
			_default_ease = mode
			for k in buttons.size():
				(buttons[k] as Button).set_pressed_no_signal(k == index))
		buttons.append(b)
		v.add_child(b)

	v.add_child(HSeparator.new())
	_vlabel(v, UiKit.label_for("Set every key at once", "طبّق على كل المفاتيح"))
	for row in choices:
		var all_mode: int = int(row[0])
		var apply_all: Button = UiKit.make_text_button(String(row[1]), true)
		apply_all.pressed.connect(func() -> void:
			_default_ease = all_mode
			_set_camera_ease(all_mode)
			_shut_sheet())
		v.add_child(apply_all)
	_sheet_note(v, UiKit.label_for(
		"A single key can still be set on its own: hold it on the camera row.",
		"ويمكن ضبط مفتاح واحد بمفرده: اضغط عليه مطولاً في صف الكاميرا."))
	_float_sheet(sheet)

func _set_camera_ease(ease_mode: int) -> void:
	for s in clip.shots:
		(s as Anim.Shot).ease_mode = ease_mode
	player.apply()
	_dirty()
	rebuild()

# -------------------------------------------------------------- the rest

func _toggle_onion() -> void:
	if player == null:
		return
	player.onion = not player.onion
	player.refresh_visuals()
	_dirty()
	refresh()

## Four pairs, and each pair is one colour and its opposite.
##
## Behind and ahead have to be told apart in a glance while a hand is
## moving, so they are never two shades of one idea: pick a colour for the
## drawings behind you and the one for the drawings ahead is its opposite
## on the wheel. Strong and flat, because a ghost is competing with the ink
## on top of it.
const ONION_PAIRS: Array = [
	[Color(0.94, 0.16, 0.26, 0.52), Color(0.10, 0.72, 0.94, 0.50)],
	[Color(0.98, 0.45, 0.05, 0.52), Color(0.16, 0.34, 0.95, 0.50)],
	[Color(0.90, 0.12, 0.72, 0.52), Color(0.14, 0.80, 0.35, 0.50)],
	[Color(0.55, 0.24, 0.94, 0.52), Color(0.94, 0.82, 0.10, 0.52)],
]

func _open_onion_settings() -> void:
	var sheet: PanelContainer = _sheet()
	var v: VBoxContainer = _sheet_column(sheet,
		UiKit.label_for("Onion skin", "قشرة البصل"))
	_sheet_note(v, UiKit.label_for(
		"One colour for the drawings behind the playhead and one for the drawings ahead of it. The nearest drawing on each side is the strongest, and each one further out is fainter — so a run of ghosts reads as a direction.",
		"لون واحد للرسوم التي خلف رأس التشغيل ولون آخر للتي أمامه. الأقرب على كل جانب هو الأقوى، وكلما ابتعد الرسم خفت لونه — فتُقرأ سلسلة الأطياف كاتجاه."))

	# --- behind ---
	_vlabel(v, UiKit.label_for("Frames behind", "إطارات للخلف"))
	UiKit.slider_row(v, UiKit.label_for("How many behind", "كم إطاراً للخلف"),
		0.0, 8.0, float(player.onion_back), 1.0, "",
		func(x: float) -> void:
			player.onion_back = clampi(int(x), 0, 8)
			player.refresh_visuals()
			_dirty()
			refresh())
	_colour_strip(v, true)

	v.add_child(HSeparator.new())

	# --- ahead ---
	_vlabel(v, UiKit.label_for("Frames ahead", "إطارات للأمام"))
	UiKit.slider_row(v, UiKit.label_for("How many ahead", "كم إطاراً للأمام"),
		0.0, 8.0, float(player.onion_forward), 1.0, "",
		func(x: float) -> void:
			player.onion_forward = clampi(int(x), 0, 8)
			player.refresh_visuals()
			_dirty()
			refresh())
	_colour_strip(v, false)
	_float_sheet(sheet)

## A row of four swatches, drawn as swatches rather than opened from a
## colour dialog.
##
## The old rows used Godot's colour button, and on a touch panel it could
## not be reached at all: the panel forwards a tap as a plain press, and a
## colour button opens its wheel from its own input handling instead — so
## the row looked live and did nothing whatever you did to it. Four ready
## colours are also the better answer here: what these need to be is
## unmistakable, not exact.
func _colour_strip(v: VBoxContainer, behind: bool) -> void:
	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", int(UiKit.s(6.0)))
	v.add_child(row)

	var current: Color = player.onion_back_tint if behind \
		else player.onion_forward_tint
	var chips: Array = []
	for i in ONION_PAIRS.size():
		var pair: Array = ONION_PAIRS[i]
		var mine: Color = pair[0] if behind else pair[1]
		var other: Color = pair[1] if behind else pair[0]
		var index: int = i
		var chip: Button = _swatch(mine)
		chip.set_pressed_no_signal(_same_hue(mine, current))
		chips.append(chip)
		chip.pressed.connect(func() -> void:
			# Choosing one side chooses the other: the pair is the point.
			player.onion_back_tint = mine if behind else other
			player.onion_forward_tint = other if behind else mine
			player.onion = true
			player.refresh_visuals()
			_dirty()
			for k in chips.size():
				(chips[k] as Button).set_pressed_no_signal(k == index)
			refresh())
		row.add_child(chip)

## A solid block of the colour itself. A swatch that says its own name in
## words would be one more thing to read; this one simply is the answer.
func _swatch(col: Color) -> Button:
	var b: Button = Button.new()
	b.toggle_mode = true
	b.focus_mode = Control.FOCUS_NONE
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.custom_minimum_size = Vector2(UiKit.s(52.0), UiKit.s(44.0))

	var solid: Color = Color(col.r, col.g, col.b, 1.0)
	var flat: StyleBoxFlat = StyleBoxFlat.new()
	flat.bg_color = solid
	flat.set_corner_radius_all(int(UiKit.s(10.0)))
	flat.border_color = Color(0.0, 0.0, 0.0, 0.35)
	flat.set_border_width_all(1)

	var hover: StyleBoxFlat = flat.duplicate() as StyleBoxFlat
	hover.bg_color = solid.lightened(0.12)

	# The chosen one wears a thick pale ring. A tick or a tint would have to
	# survive being drawn on top of every colour in the row; a ring does.
	var on: StyleBoxFlat = flat.duplicate() as StyleBoxFlat
	on.border_color = UiKit.TEXT
	on.set_border_width_all(int(maxf(UiKit.s(3.0), 3.0)))

	b.add_theme_stylebox_override("normal", flat)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", on)
	b.add_theme_stylebox_override("focus", flat)
	return b

func _same_hue(a: Color, b: Color) -> bool:
	return absf(a.r - b.r) < 0.06 and absf(a.g - b.g) < 0.06 \
		and absf(a.b - b.b) < 0.06

func _vlabel(v: VBoxContainer, text: String) -> void:
	v.add_child(UiKit.make_label(text, 12.0, UiKit.TEXT_DIM))

func _open_timeline_settings() -> void:
	var sheet: PanelContainer = _sheet()
	var v: VBoxContainer = _sheet_column(sheet,
		UiKit.label_for("Timeline settings", "إعدادات التايم لاين"))

	v.add_child(UiKit.make_label(
		UiKit.label_for("Frames per second", "إطارات في الثانية"),
		12.0, UiKit.TEXT_DIM))
	var rates: HBoxContainer = HBoxContainer.new()
	rates.add_theme_constant_override("separation", int(UiKit.s(5.0)))
	v.add_child(rates)
	var choices: Array = [8, 12, 15, 24, 25, 30, 50, 60]
	var rate_buttons: Array = []
	for i in choices.size():
		var value: int = int(choices[i])
		var index: int = i
		var b: Button = UiKit.make_text_button(str(value))
		b.toggle_mode = true
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.set_pressed_no_signal(value == clip.fps)
		b.pressed.connect(func() -> void:
			clip.fps = value
			for k in rate_buttons.size():
				(rate_buttons[k] as Button).set_pressed_no_signal(k == index)
			_dirty()
			refresh())
		rate_buttons.append(b)
		rates.add_child(b)
	_sheet_note(v, UiKit.label_for(
		"This is the rate the scene plays at and the rate it is written out at — change it here and every export follows.",
		"هذا هو المعدّل الذي يعمل به المشهد والمعدّل الذي يُصدَّر به — غيّره هنا ويتبعه كل تصدير."))

	v.add_child(HSeparator.new())

	# --- what plays ---
	#
	# Length is not asked for any more. A scene ends where the drawing ends,
	# and the band grows to fit it. What is worth choosing is which stretch
	# to watch — an action six frames long in the middle of a long scene
	# should be watchable without sitting through everything before it.
	_vlabel(v, UiKit.label_for("Play from frame", "التشغيل من الإطار"))
	var last: int = maxi(clip.length - 1, 0)
	var span: Vector2i = clip.play_span(stack)
	var from_label: Label = UiKit.make_label("", 11.0, UiKit.TEXT_DIM)
	var to_label: Label = UiKit.make_label("", 11.0, UiKit.TEXT_DIM)
	var restate: Callable = func() -> void:
		var now: Vector2i = clip.play_span(stack)
		var whole: bool = clip.play_from < 0 and clip.play_to < 0
		from_label.text = UiKit.label_for("Whole scene", "المشهد كامله") if whole \
			else "%d → %d  ·  %d %s" % [now.x + 1, now.y + 1,
				now.y - now.x + 1, UiKit.label_for("frames", "إطاراً")]
		to_label.text = "%.2f %s" % [
			float(now.y - now.x + 1) / float(maxi(clip.fps, 1)),
			UiKit.label_for("seconds", "ثانية")]

	UiKit.slider_row(v, UiKit.label_for("First frame", "أول إطار"),
		1.0, float(last + 1), float(span.x + 1), 1.0, "",
		func(x: float) -> void:
			clip.play_from = clampi(int(x) - 1, 0, maxi(clip.length - 1, 0))
			if clip.play_to >= 0 and clip.play_to < clip.play_from:
				clip.play_to = clip.play_from
			restate.call()
			_dirty()
			refresh())
	UiKit.slider_row(v, UiKit.label_for("Last frame", "آخر إطار"),
		1.0, float(last + 1), float(span.y + 1), 1.0, "",
		func(x: float) -> void:
			clip.play_to = clampi(int(x) - 1, 0, maxi(clip.length - 1, 0))
			if clip.play_from >= 0 and clip.play_from > clip.play_to:
				clip.play_from = clip.play_to
			restate.call()
			_dirty()
			refresh())
	v.add_child(from_label)
	v.add_child(to_label)
	restate.call()

	var whole_b: Button = UiKit.make_text_button(
		UiKit.label_for("Play the whole scene", "شغّل المشهد كامله"), true)
	whole_b.pressed.connect(func() -> void:
		clip.play_from = -1
		clip.play_to = -1
		restate.call()
		_dirty()
		refresh())
	v.add_child(whole_b)

	var loop: Button = UiKit.make_text_button(
		UiKit.label_for("Repeat", "تكرار"), true)
	loop.toggle_mode = true
	loop.set_pressed_no_signal(player.looping)
	loop.pressed.connect(func() -> void:
		player.looping = not player.looping
		_dirty()
		_shut_sheet())
	v.add_child(loop)

	UiKit.slider_row(v, UiKit.label_for("Frame width", "عرض الإطار"),
		MIN_FRAME_W, MAX_FRAME_W, frame_w, 1.0, "",
		func(x: float) -> void:
			frame_w = x
			refresh())
	_float_sheet(sheet)

# ------------------------------------------------------------ the sheets

## Every sheet is built the same way: a title, a scrolling column, and a
## shade over the whole screen. Pressing anything inside closes it, because
## a settings sheet has said its piece the moment it is used.
func _sheet() -> PanelContainer:
	var sheet: PanelContainer = PanelContainer.new()
	sheet.add_theme_stylebox_override("panel", UiKit.panel_style())
	var screen_w: float = get_viewport_rect().size.x
	var min_w: float = clampf(screen_w * 0.78, UiKit.s(320.0), UiKit.s(520.0))
	sheet.custom_minimum_size = Vector2(min_w, 0.0)
	return sheet

func _sheet_column(sheet: PanelContainer, title: String) -> VBoxContainer:
	var outer: VBoxContainer = VBoxContainer.new()
	outer.add_theme_constant_override("separation", int(UiKit.s(8.0)))
	sheet.add_child(outer)
	var heading: Label = UiKit.make_label(title, 16.0, UiKit.TEXT)
	heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	heading.custom_minimum_size = Vector2(0.0, UiKit.s(26.0))
	outer.add_child(heading)
	var v: VBoxContainer = VBoxContainer.new()
	v.add_theme_constant_override("separation", int(UiKit.s(10.0)))
	var scroller: Control = UiKit.scroller(v, UiKit.s(420.0))
	scroller.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outer.add_child(scroller)
	return v

func _sheet_note(v: VBoxContainer, text: String) -> void:
	var l: Label = UiKit.make_label(text, 10.0, UiKit.TEXT_DIM)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(l)

var _shade: Control = null

func _shut_sheet() -> void:
	if _shade != null:
		_shade.queue_free()
		_shade = null
	refresh()

func _float_sheet(sheet: PanelContainer) -> void:
	_shut_sheet()
	_shade = Control.new()
	_shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_shade.offset_top = -get_viewport_rect().size.y
	_shade.mouse_filter = Control.MOUSE_FILTER_STOP
	_shade.gui_input.connect(func(e: InputEvent) -> void:
		var down: bool = false
		if e is InputEventScreenTouch:
			down = (e as InputEventScreenTouch).pressed
		elif e is InputEventMouseButton:
			down = (e as InputEventMouseButton).pressed
		if down:
			_shut_sheet())
	add_child(_shade)

	sheet.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	_shade.add_child(sheet)
	# Guarded on both sides of the wait. Before it, because `get_tree()` on a
	# node outside the tree is null — the exact fault that stopped the
	# B-Spline room opening. After it, because a frame is long enough for the
	# panel to have been closed and freed while we were away.
	if not is_inside_tree():
		return
	await get_tree().process_frame
	if not is_inside_tree() or not is_instance_valid(sheet):
		return

	# Placed against the whole screen rather than the band, which is short
	# enough to cut a sheet in half.
	var screen: Vector2 = get_viewport_rect().size
	var here: Vector2 = global_position
	var max_h: float = screen.y - UiKit.s(24.0)
	if sheet.size.y > max_h:
		sheet.size = Vector2(minf(sheet.size.x, screen.x - UiKit.s(24.0)), max_h)
	else:
		sheet.size.x = minf(sheet.size.x, screen.x - UiKit.s(24.0))
	var top: float = clampf(here.y - sheet.size.y - UiKit.s(10.0),
		UiKit.s(12.0), screen.y - sheet.size.y - UiKit.s(12.0)) - here.y
	var left: float = clampf((screen.x - sheet.size.x) * 0.5, UiKit.s(12.0),
		screen.x - sheet.size.x - UiKit.s(12.0))
	sheet.position = Vector2(left, top)

# --------------------------------------------------------- held buttons

func _hold_start(action: Callable) -> void:
	_hold_action = action
	_hold_ms = Time.get_ticks_msec()
	set_process(true)

func _hold_end() -> void:
	_hold_action = Callable()
	_hold_ms = 0

func _check_hold() -> void:
	if _hold_ms == 0 or not _hold_action.is_valid():
		return
	if Time.get_ticks_msec() - _hold_ms < HOLD_MS:
		return
	var action: Callable = _hold_action
	_hold_end()
	action.call()
