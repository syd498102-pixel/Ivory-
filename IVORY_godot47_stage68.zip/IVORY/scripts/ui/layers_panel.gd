class_name LayersPanel
extends PanelContainer
## The layer stack, laid out the way drawing apps have settled on: topmost
## layer at the top, a picture of what each one holds, one tap to select.
##
## All touch in the list is handled here, in one place, as a single state
## machine with three outcomes:
##
##   short tap                -> select, or open settings if already selected
##   drag without holding     -> scroll the list
##   hold, then drag          -> pick the layer up and drop it somewhere else
##
## Doing it in one handler rather than per-row is what keeps the three from
## fighting: a nested scroll container and a drag-to-reorder row would each
## claim the same finger, and whichever won would feel broken.

signal solo_requested(index: int)
signal import_requested(index: int)
signal puppet_requested(index: int)
signal animation_layer_requested(group_id: int)
signal text_edit_requested(index: int)
signal turn_360_requested(index: int)

const ICON: String = "res://assets/icons/%s.png"
const ROW_H: float = 62.0
const GROUP_H: float = 42.0
const THUMB: float = 46.0
const LIST_MAX: float = 430.0
const HOLD_MS: int = 300
const MOVE_SLOP: float = 12.0

enum Mode { IDLE, WAITING, SCROLL, DRAG }

var view: CanvasView = null
var stack: LayerStack = null

var _body: VBoxContainer = null
var _clip: Control = null
var _host: VBoxContainer = null
var _settings: VBoxContainer = null
var _settings_scroll: TouchScroll = null
var _paint: Control = null

var _rows: Array = []              # {node, kind, index/gid}
var _slots: Array = []             # {y, index, group}
var _fold_btn: Button = null
var _undo_btn: Button = null
var _redo_btn: Button = null
var _settings_for: int = -1        # layer index
var _settings_group: int = -1      # group id
var _scroll: float = 0.0
var _content_h: float = 0.0

# --- gesture state ---
var _mode: int = Mode.IDLE
var _press_at: Vector2 = Vector2.ZERO
var _press_ms: int = 0
var _press_row: int = -1
var _pointer: Vector2 = Vector2.ZERO
var _drag_layer: int = -1
var _drag_slot: int = -1
var _scroll_from: float = 0.0

func setup(canvas: CanvasView) -> void:
	view = canvas
	stack = canvas.layers
	add_theme_stylebox_override("panel", UiKit.panel_style())
	custom_minimum_size = Vector2(UiKit.s(300.0), 0.0)
	mouse_filter = Control.MOUSE_FILTER_STOP

	_body = VBoxContainer.new()
	_body.add_theme_constant_override("separation", int(UiKit.s(8.0)))
	_body.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_body)

	_build_header()

	_clip = Control.new()
	_clip.clip_contents = true
	_clip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_clip.custom_minimum_size = Vector2(0.0, UiKit.s(160.0))
	_clip.resized.connect(_sync_host)
	_body.add_child(_clip)

	_host = VBoxContainer.new()
	_host.add_theme_constant_override("separation", int(UiKit.s(5.0)))
	_host.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_clip.add_child(_host)

	# The settings column scrolls: a layer with a merge, a solo view
	# and half a dozen notes is taller than a phone, and losing the last
	# button off the bottom is the same as not having it.
	_settings = VBoxContainer.new()
	_settings.add_theme_constant_override("separation", int(UiKit.s(8.0)))
	_settings.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_settings_scroll = UiKit.scroller(_settings, UiKit.s(400.0))
	_settings_scroll.visible = false
	_body.add_child(_settings_scroll)

	# Drop indicator and drag ghost live above everything else.
	_paint = Control.new()
	_paint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_paint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_paint.draw.connect(_draw_overlay)
	add_child(_paint)

	stack.changed.connect(_rebuild)
	stack.active_changed.connect(func(_i: int) -> void: _rebuild())
	view.history_changed.connect(_sync_history)
	_rebuild()
	_sync_history()

## Opens the settings for whatever is selected.
func open_settings_for_active() -> void:
	_settings_group = -1
	_settings_for = stack.active_index
	_rebuild()

## Runs only while a finger is down and the long-press has not resolved yet.
##
## This panel used to be in the engine's process list for the whole life of
## the app, waking every frame to compare two numbers that are equal except
## during the third of a second after a press. The panel now switches itself
## on when a press begins and off the moment it is answered, so a tablet
## sitting still is running one less node per frame — and, more to the point,
## so does every other panel that follows this pattern.
func _process(_dt: float) -> void:
	if _mode != Mode.WAITING:
		set_process(false)
		return
	if Time.get_ticks_msec() - _press_ms >= HOLD_MS:
		set_process(false)
		_start_drag()

# ------------------------------------------------------------------ header

func _build_header() -> void:
	var head: HBoxContainer = HBoxContainer.new()
	head.add_theme_constant_override("separation", int(UiKit.s(6.0)))
	_body.add_child(head)

	var title: Label = UiKit.make_label(UiKit.label_for("Layers", "الطبقات"), 15.0, UiKit.TEXT)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)

	# Only ever acts on a layer: a folder cannot be put inside a folder.
	_fold_btn = _icon_button("add_file",
		UiKit.label_for("Put this layer in a folder", "ضع هذه الطبقة في مجلد"))
	_fold_btn.pressed.connect(func() -> void:
		if stack.active_group != 0:
			return
		stack.group_layer(stack.active_index)
		_close_settings())
	head.add_child(_fold_btn)

	var add_layer: Button = _icon_button("add_layer",
		UiKit.label_for("New layer", "طبقة جديدة"))
	add_layer.pressed.connect(func() -> void:
		stack.add_layer_here()
		_close_settings())
	head.add_child(add_layer)

	var trash: Button = _icon_button("delete_layer",
		UiKit.label_for("Delete layer", "حذف الطبقة"))
	trash.pressed.connect(func() -> void:
		stack.remove_layer(stack.active_index)
		_close_settings())
	head.add_child(trash)

	# Right here rather than only on the canvas: the moment a layer is
	# deleted by mistake is the moment the finger is already in this panel,
	# and asking it to travel to the drawing to take that back is the worst
	# time to ask.
	var undo_row: HBoxContainer = HBoxContainer.new()
	undo_row.add_theme_constant_override("separation", int(UiKit.s(6.0)))
	_body.add_child(undo_row)

	_undo_btn = UiKit.make_text_button(UiKit.label_for("Undo", "تراجع"), true)
	_undo_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_undo_btn.pressed.connect(func() -> void: view.undo())
	undo_row.add_child(_undo_btn)

	_redo_btn = UiKit.make_text_button(UiKit.label_for("Redo", "إعادة"), true)
	_redo_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_redo_btn.pressed.connect(func() -> void: view.redo())
	undo_row.add_child(_redo_btn)

func _icon_button(icon_name: String, tip: String) -> Button:
	var b: Button = Button.new()
	b.tooltip_text = tip
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(UiKit.s(44.0), UiKit.s(44.0))
	var path: String = ICON % icon_name
	if ResourceLoader.exists(path):
		b.icon = load(path)
	b.expand_icon = true
	b.add_theme_constant_override("icon_max_width", int(UiKit.s(22.0)))
	b.add_theme_color_override("icon_normal_color", UiKit.ON_RAIL)
	b.add_theme_color_override("icon_hover_color", Color.WHITE)
	b.add_theme_color_override("icon_pressed_color", Color("#1b1c22"))

	var n: StyleBoxFlat = StyleBoxFlat.new()
	n.bg_color = UiKit.CHIP
	n.border_color = UiKit.PANEL_EDGE
	n.set_border_width_all(1)
	n.set_corner_radius_all(int(UiKit.s(10.0)))
	var h: StyleBoxFlat = n.duplicate() as StyleBoxFlat
	h.bg_color = UiKit.CHIP_HOVER
	var p: StyleBoxFlat = n.duplicate() as StyleBoxFlat
	p.bg_color = UiKit.ACCENT

	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", h)
	b.add_theme_stylebox_override("pressed", p)
	b.add_theme_stylebox_override("focus", n)
	return b

# -------------------------------------------------------------------- list

func refresh_thumbs() -> void:
	# Never mid-gesture, and never while a settings page holds a live slider.
	if _mode != Mode.IDLE or _settings_for >= 0 or _settings_group >= 0:
		return
	stack.refresh_all_thumbs(int(THUMB * 2.0))
	_rebuild()

func _close_settings() -> void:
	_settings_for = -1
	_settings_group = -1
	_rebuild()

func _rebuild() -> void:
	if _host == null:
		return
	for c in _host.get_children():
		_host.remove_child(c)
		c.queue_free()
	for c in _settings.get_children():
		_settings.remove_child(c)
		c.queue_free()
	_rows.clear()

	if _settings_group >= 0:
		_clip.visible = false
		_settings_scroll.visible = true
		_build_group_settings(_settings_group)
		return
	if _settings_for >= 0 and _settings_for < stack.layers.size():
		_clip.visible = false
		_settings_scroll.visible = true
		_build_layer_settings(_settings_for)
		return

	_clip.visible = true
	_settings_scroll.visible = false
	_sync_fold_button()

	var gap: float = UiKit.s(5.0)
	_content_h = 0.0
	for entry in stack.display_rows():
		var node: Control = null
		if String(entry["kind"]) == "group":
			node = _group_row(int(entry["gid"]))
			_content_h += UiKit.s(GROUP_H) + gap
		else:
			node = _layer_row(int(entry["index"]))
			_content_h += UiKit.s(ROW_H) + gap
		_host.add_child(node)
		var rec: Dictionary = entry.duplicate()
		rec["node"] = node
		_rows.append(rec)

	_content_h = maxf(_content_h - gap, 0.0)
	_clip.custom_minimum_size = Vector2(0.0, minf(_content_h, UiKit.s(LIST_MAX)))
	_sync_host()
	if _paint != null:
		_paint.queue_redraw()

## A plain Control does not lay out its children, so the list gets its width
## and height set by hand whenever either could have changed.
func _sync_host() -> void:
	if _host == null or _clip == null:
		return
	_host.size = Vector2(_clip.size.x, _content_h)
	_scroll = clampf(_scroll, 0.0, maxf(_content_h - _clip.size.y, 0.0))
	_host.position = Vector2(0.0, -_scroll)

## Greyed out when a folder is what is selected, so it is clear the button
## acts on layers rather than quietly doing nothing.
## A small sheet of choices over the panel, each with a line saying what it
## is for — because a name alone rarely tells anyone which one they want.
func _open_sheet(title: String, rows: Array) -> void:
	var shade: Control = Control.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_STOP
	shade.gui_input.connect(func(e: InputEvent) -> void:
		var down: bool = false
		if e is InputEventScreenTouch:
			down = (e as InputEventScreenTouch).pressed
		elif e is InputEventMouseButton:
			down = (e as InputEventMouseButton).pressed
		if down:
			shade.queue_free())
	add_child(shade)

	var sheet: PanelContainer = PanelContainer.new()
	sheet.add_theme_stylebox_override("panel", UiKit.panel_style())
	sheet.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	sheet.custom_minimum_size = Vector2(clampf(get_viewport_rect().size.x * 0.78, UiKit.s(320.0), UiKit.s(520.0)), 0.0)
	shade.add_child(sheet)

	var outer: VBoxContainer = VBoxContainer.new()
	outer.add_theme_constant_override("separation", int(UiKit.s(8.0)))
	sheet.add_child(outer)
	var head: Label = UiKit.make_label(title, 16.0, UiKit.TEXT)
	head.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	outer.add_child(head)

	var v: VBoxContainer = VBoxContainer.new()
	v.add_theme_constant_override("separation", int(UiKit.s(8.0)))
	var scroller: Control = UiKit.scroller(v, UiKit.s(420.0))
	scroller.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outer.add_child(scroller)

	for row in rows:
		var box: VBoxContainer = VBoxContainer.new()
		box.add_theme_constant_override("separation", 0)
		var b: Button = UiKit.make_text_button(String(row[0]), true)
		b.custom_minimum_size = Vector2(0.0, UiKit.s(46.0))
		var action: Callable = row[2]
		b.pressed.connect(func() -> void:
			shade.queue_free()
			action.call())
		box.add_child(b)
		var hint: Label = UiKit.make_label(String(row[1]), 10.0, UiKit.TEXT_DIM)
		hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		box.add_child(hint)
		v.add_child(box)

func _sync_history() -> void:
	if _undo_btn != null:
		_undo_btn.disabled = not view.can_undo()
	if _redo_btn != null:
		_redo_btn.disabled = not view.can_redo()

func _sync_fold_button() -> void:
	if _fold_btn == null:
		return
	var ok: bool = stack.active_group == 0
	if ok and stack.active_index < stack.layers.size():
		var l: LayerStack.Layer = stack.layers[stack.active_index]
		ok = not l.is_background and l.group_id == 0
	_fold_btn.disabled = not ok

func _layer_row(index: int) -> Control:
	var l: LayerStack.Layer = stack.layers[index]
	var selected: bool = index == stack.active_index
	var indented: bool = l.group_id != 0

	var outer: MarginContainer = MarginContainer.new()
	outer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if indented:
		outer.add_theme_constant_override("margin_left", int(UiKit.s(16.0)))

	var row: PanelContainer = PanelContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.custom_minimum_size = Vector2(0.0, UiKit.s(ROW_H))
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = Color("#31363f") if selected else Color("#262a33")
	sb.set_corner_radius_all(int(UiKit.s(10.0)))
	sb.set_content_margin_all(UiKit.s(6.0))
	if selected:
		sb.border_color = UiKit.ACCENT
		sb.border_width_left = int(UiKit.s(3.0))
	if index == _drag_layer and _mode == Mode.DRAG:
		sb.bg_color = Color("#3a3f4a")
	row.add_theme_stylebox_override("panel", sb)
	outer.add_child(row)

	var line: HBoxContainer = HBoxContainer.new()
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	line.add_theme_constant_override("separation", int(UiKit.s(8.0)))
	row.add_child(line)

	line.add_child(_thumb_box(l.thumb))

	var name_box: VBoxContainer = VBoxContainer.new()
	name_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	name_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_box.alignment = BoxContainer.ALIGNMENT_CENTER
	line.add_child(name_box)

	var title: String = l.title
	if l.is_background:
		title = UiKit.label_for("Background", "الخلفية")
	name_box.add_child(UiKit.make_label(title, 13.0, UiKit.TEXT))

	var note: String = "%d%%" % int(round(l.opacity * 100.0))
	if l.locked:
		note += "  " + UiKit.label_for("locked", "مقفلة")
	if selected:
		note += "  ·  " + UiKit.label_for("tap again", "اضغط ثانية")
	name_box.add_child(UiKit.make_label(note, 10.0, UiKit.TEXT_DIM))

	var eye: Button = _icon_button("hide_layer",
		UiKit.label_for("Show or hide", "إظهار أو إخفاء"))
	eye.custom_minimum_size = Vector2(UiKit.s(40.0), UiKit.s(40.0))
	eye.modulate = Color(1.0, 1.0, 1.0, 1.0 if l.visible else 0.40)
	eye.pressed.connect(func() -> void:
		if index < stack.layers.size():
			stack.set_visible_at(index, not stack.layers[index].visible))
	line.add_child(eye)
	return outer

func _group_row(gid: int) -> Control:
	var g: LayerStack.Group = stack.group_by_id(gid)
	var row: PanelContainer = PanelContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.custom_minimum_size = Vector2(0.0, UiKit.s(GROUP_H))
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = Color("#2e333d")
	sb.set_corner_radius_all(int(UiKit.s(10.0)))
	sb.set_content_margin_all(UiKit.s(6.0))
	row.add_theme_stylebox_override("panel", sb)

	var line: HBoxContainer = HBoxContainer.new()
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	line.add_theme_constant_override("separation", int(UiKit.s(8.0)))
	row.add_child(line)

	# Its own button, so folding a folder and opening its settings never
	# compete for the same tap.
	var mark: Button = UiKit.make_text_button("-" if not g.collapsed else "+")
	mark.custom_minimum_size = Vector2(UiKit.s(38.0), UiKit.s(30.0))
	mark.tooltip_text = UiKit.label_for("Fold or unfold", "طيّ أو فتح")
	mark.pressed.connect(func() -> void:
		stack.set_group_collapsed(gid, not g.collapsed))
	line.add_child(mark)

	var name_l: Label = UiKit.make_label(
		"%s  (%d)" % [g.title, stack.member_count(gid)], 13.0, UiKit.TEXT)
	name_l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	line.add_child(name_l)

	var eye: Button = _icon_button("hide_layer",
		UiKit.label_for("Show or hide the folder", "إظهار أو إخفاء المجلد"))
	eye.custom_minimum_size = Vector2(UiKit.s(38.0), UiKit.s(38.0))
	eye.modulate = Color(1.0, 1.0, 1.0, 1.0 if g.visible else 0.40)
	eye.pressed.connect(func() -> void: stack.set_group_visible(gid, not g.visible))
	line.add_child(eye)
	return row

func _thumb_box(tex: ImageTexture) -> Control:
	var frame: PanelContainer = PanelContainer.new()
	frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
	frame.custom_minimum_size = Vector2(UiKit.s(THUMB), UiKit.s(THUMB))
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = Color("#f4f1ea")
	sb.border_color = Color("#4a505c")
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(int(UiKit.s(7.0)))
	frame.add_theme_stylebox_override("panel", sb)

	var pic: TextureRect = TextureRect.new()
	pic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	# Comes straight off the canvas, so it blends the canvas's way.
	pic.material = PaintSurface.premultiplied_material()
	pic.texture = tex
	frame.add_child(pic)
	return frame

# ----------------------------------------------------------------- gestures

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		App.touch_mode = true
		var st: InputEventScreenTouch = event as InputEventScreenTouch
		if st.pressed:
			_press(st.position)
		else:
			_release(st.position)
		accept_event()
	elif event is InputEventScreenDrag:
		_drag_to((event as InputEventScreenDrag).position)
		accept_event()
	elif event is InputEventMouseButton:
		if App.touch_mode:
			return
		var mb: InputEventMouseButton = event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_press(mb.position)
			else:
				_release(mb.position)
			accept_event()
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			_scroll_by(-UiKit.s(40.0))
			accept_event()
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_scroll_by(UiKit.s(40.0))
			accept_event()
	elif event is InputEventMouseMotion:
		if App.touch_mode or _mode == Mode.IDLE:
			return
		_drag_to((event as InputEventMouseMotion).position)
		accept_event()

func _press(pos: Vector2) -> void:
	if not _clip.visible:
		return
	if not _in_list(pos):
		return
	_press_at = pos
	_pointer = pos
	_press_ms = Time.get_ticks_msec()
	set_process(true)
	_press_row = _row_at(pos)
	_scroll_from = _scroll
	_mode = Mode.WAITING

func _drag_to(pos: Vector2) -> void:
	_pointer = pos
	if _mode == Mode.WAITING:
		if absf(pos.y - _press_at.y) > MOVE_SLOP * App.ui_scale:
			# Moved before the hold matured: the finger wants to scroll.
			_mode = Mode.SCROLL
		else:
			return
	if _mode == Mode.SCROLL:
		_set_scroll(_scroll_from - (pos.y - _press_at.y))
	elif _mode == Mode.DRAG:
		_drag_slot = _nearest_slot(pos.y)
		_edge_scroll(pos.y)
		_paint.queue_redraw()

func _release(pos: Vector2) -> void:
	# The mode is cleared first: both branches below rebuild the list, and a
	# rebuild that still believed a drag was running would draw an indicator
	# against rows that no longer exist.
	var was: int = _mode
	_mode = Mode.IDLE
	_press_row = -1
	if was == Mode.DRAG:
		_finish_drag()
	elif was == Mode.WAITING:
		_tap(pos)
	_drag_layer = -1
	_drag_slot = -1
	_paint.queue_redraw()

func _tap(pos: Vector2) -> void:
	var r: int = _row_at(pos)
	if r < 0 or r >= _rows.size():
		return
	var entry: Dictionary = _rows[r]
	if String(entry["kind"]) == "group":
		var gid: int = int(entry["gid"])
		if stack.group_by_id(gid) == null:
			return
		stack.set_active_group(gid)
		_settings_group = gid
		_settings_for = -1
		_rebuild()
		return
	var index: int = int(entry["index"])
	if index == stack.active_index:
		_settings_for = index
		_settings_group = -1
		_rebuild()
		return
	stack.set_active(index)
	_close_settings()

func _start_drag() -> void:
	if _press_row < 0 or _press_row >= _rows.size():
		_mode = Mode.IDLE
		return
	var entry: Dictionary = _rows[_press_row]
	if String(entry["kind"]) != "layer":
		_mode = Mode.IDLE
		return
	var index: int = int(entry["index"])
	if index >= stack.layers.size() or stack.layers[index].is_background:
		_mode = Mode.IDLE
		return
	_drag_layer = index
	_mode = Mode.DRAG
	_build_slots()
	_drag_slot = _nearest_slot(_pointer.y)
	_paint.queue_redraw()

func _finish_drag() -> void:
	if _drag_layer < 0 or _drag_slot < 0 or _drag_slot >= _slots.size():
		return
	var slot: Dictionary = _slots[_drag_slot]
	stack.relocate(_drag_layer, int(slot["index"]), int(slot["group"]))

# ------------------------------------------------------------ drop targets

## One slot per gap between rows. A folder contributes two gaps at its top
## edge — one just above the header and one just below it — and that pair is
## what lets a finger say "beside the folder" or "inside it" without any
## extra gesture.
func _build_slots() -> void:
	_slots.clear()
	if _rows.is_empty():
		return
	var first: Control = _rows[0]["node"]
	_slots.append({
		"y": _list_y(first.position.y),
		"index": stack.layers.size(),
		"group": 0,
	})
	for entry in _rows:
		var node: Control = entry["node"]
		var bottom: float = _list_y(node.position.y + node.size.y)
		if String(entry["kind"]) == "group":
			var gid: int = int(entry["gid"])
			var top_index: int = _group_top_index(gid)
			_slots.append({"y": bottom, "index": top_index + 1, "group": gid})
		else:
			var index: int = int(entry["index"])
			_slots.append({
				"y": bottom,
				"index": index,
				"group": stack.layers[index].group_id,
			})

func _group_top_index(gid: int) -> int:
	var top: int = -1
	for i in stack.layers.size():
		if stack.layers[i].group_id == gid:
			top = i
	return top

func _nearest_slot(y: float) -> int:
	var best: int = -1
	var best_d: float = 1e20
	for i in _slots.size():
		var d: float = absf(float(_slots[i]["y"]) - y)
		if d < best_d:
			best_d = d
			best = i
	return best

## Dragging against the top or bottom edge creeps the list along, so a layer
## can travel further than one screenful without being put down first.
func _edge_scroll(y: float) -> void:
	var box: Rect2 = _clip_rect()
	var top: float = box.position.y
	var bottom: float = top + box.size.y
	var zone: float = UiKit.s(34.0)
	if y < top + zone:
		_set_scroll(_scroll - UiKit.s(9.0))
		_build_slots()
	elif y > bottom - zone:
		_set_scroll(_scroll + UiKit.s(9.0))
		_build_slots()

# -------------------------------------------------------------- list maths

## The list's box in panel-local coordinates — the same space _gui_input
## reports positions in. Everything below measures through this, so nested
## containers and their margins can never shift the maths out from under it.
func _clip_rect() -> Rect2:
	if _clip == null:
		return Rect2()
	return Rect2(_clip.global_position - global_position, _clip.size)

func _in_list(pos: Vector2) -> bool:
	return _clip_rect().has_point(pos)

func _list_y(host_y: float) -> float:
	return _clip_rect().position.y + _host.position.y + host_y

func _row_at(pos: Vector2) -> int:
	for i in _rows.size():
		var node: Control = _rows[i]["node"]
		var top: float = _list_y(node.position.y)
		if pos.y >= top and pos.y <= top + node.size.y:
			return i
	return -1

func _scroll_by(amount: float) -> void:
	_set_scroll(_scroll + amount)

func _set_scroll(value: float) -> void:
	var span: float = maxf(_content_h - _clip_rect().size.y, 0.0)
	_scroll = clampf(value, 0.0, span)
	_host.position = Vector2(0.0, -_scroll)
	_paint.queue_redraw()

# ----------------------------------------------------------------- overlay

func _draw_overlay() -> void:
	if _clip == null or not _clip.visible:
		return
	_draw_folder_frames()
	_draw_drop_hint()
	if _mode == Mode.DRAG:
		_draw_ghost()

## A folder should read as a container at a glance. An outline plus the
## faintest wash of the same colour does that without competing with the
## rows for attention.
##
## Three states, three meanings, and none of them borrows another's colour:
##   resting  — cool slate, "this is a container"
##   selected — brass, the app's one word for "you are working on this"
##   dragging — near-black, "this is somewhere a layer can land"
func _draw_folder_frames() -> void:
	var clip: Rect2 = _clip_rect()
	var dragging: bool = _mode == Mode.DRAG
	var target: int = 0
	if dragging and _drag_slot >= 0 and _drag_slot < _slots.size():
		target = int(_slots[_drag_slot]["group"])

	for g in stack.groups:
		var frame: Rect2 = _group_frame(g.id)
		if frame.size.y <= 0.0:
			continue
		# The gap between rows is shared by the row above and the row below,
		# so the frame may only take half of it. Any more and it reaches
		# across into a layer that is not in this folder.
		var air: float = UiKit.s(5.0) * 0.5 - UiKit.s(1.0)
		frame = frame.grow_individual(UiKit.s(2.0), air, UiKit.s(2.0), air)
		var width: float = UiKit.s(1.5)
		var tone: Color = UiKit.FOLDER
		var wash: float = 0.05

		if dragging:
			tone = UiKit.RAIL
			if g.id == target:
				# The frame stretches by a row, so the space the layer is
				# about to take is visible before the finger lets go.
				frame = frame.grow_individual(0.0, 0.0, 0.0, UiKit.s(ROW_H) * 0.5)
				width = UiKit.s(2.5)
				wash = 0.10
			else:
				width = UiKit.s(1.5)
				wash = 0.03
		elif stack.active_group == g.id:
			tone = UiKit.ACCENT
			width = UiKit.s(2.0)
			wash = 0.10

		var shown: Rect2 = frame.intersection(clip.grow(UiKit.s(4.0)))
		if shown.size.y <= 0.0 or shown.size.x <= 0.0:
			continue
		_paint.draw_rect(shown, Color(tone.r, tone.g, tone.b, wash), true)
		_paint.draw_rect(shown, tone, false, width)

func _draw_drop_hint() -> void:
	if _mode != Mode.DRAG or _drag_slot < 0 or _drag_slot >= _slots.size():
		return
	var box: Rect2 = _clip_rect()
	var slot: Dictionary = _slots[_drag_slot]
	var y: float = clampf(float(slot["y"]), box.position.y,
		box.position.y + box.size.y)
	var left: float = box.position.x
	var right: float = left + box.size.x
	# Brass, and deliberately not the folder's colour: the frame answers
	# "which container", this answers "which gap".
	_paint.draw_line(Vector2(left, y), Vector2(right, y), UiKit.ACCENT, UiKit.s(3.0))
	_paint.draw_circle(Vector2(left + UiKit.s(4.0), y), UiKit.s(5.0), UiKit.ACCENT)

## The exact span of one folder's rows, header included, and nothing else.
## Measured from the rows on screen rather than from the layer list, so a
## folded folder frames only its header and an open one stops at its last
## member instead of reaching into whatever follows.
func _group_frame(gid: int) -> Rect2:
	var top: float = 1e20
	var bottom: float = -1e20
	for entry in _rows:
		var belongs: bool = false
		if String(entry["kind"]) == "group":
			belongs = int(entry["gid"]) == gid
		else:
			var index: int = int(entry["index"])
			belongs = index < stack.layers.size() and stack.layers[index].group_id == gid
		if not belongs:
			continue
		var node: Control = entry["node"]
		top = minf(top, _list_y(node.position.y))
		bottom = maxf(bottom, _list_y(node.position.y + node.size.y))
	if bottom <= top:
		return Rect2()
	var box: Rect2 = _clip_rect()
	# Trimmed on the right so the frame ends where its rows end rather than
	# running the full width of the panel, and gaps between rows are not
	# counted as part of it.
	return Rect2(box.position.x + UiKit.s(1.0), top,
		box.size.x - UiKit.s(2.0), bottom - top)

## A small card riding under the finger, so it is never unclear what is
## being carried.
func _draw_ghost() -> void:
	if _drag_layer < 0 or _drag_layer >= stack.layers.size():
		return
	var l: LayerStack.Layer = stack.layers[_drag_layer]
	var clip: Rect2 = _clip_rect()
	var w: float = clip.size.x * 0.7
	var h: float = UiKit.s(44.0)
	var box: Rect2 = Rect2(clip.position.x + UiKit.s(18.0),
		_pointer.y - h * 0.5, w, h)

	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = Color(0.11, 0.11, 0.13, 0.94)
	sb.set_corner_radius_all(int(UiKit.s(10.0)))
	_paint.draw_style_box(sb, box)

	var dot: Rect2 = Rect2(box.position + Vector2(UiKit.s(10.0), UiKit.s(10.0)),
		Vector2(h - UiKit.s(20.0), h - UiKit.s(20.0)))
	_paint.draw_rect(dot, UiKit.ACCENT, true)

	var f: Font = ThemeDB.fallback_font
	if f != null:
		var title: String = l.title
		if l.is_background:
			title = UiKit.label_for("Background", "الخلفية")
		_paint.draw_string(f, box.position + Vector2(h, h * 0.62), title,
			HORIZONTAL_ALIGNMENT_LEFT, box.size.x - h - UiKit.s(6.0),
			int(UiKit.s(12.0)), Color(0.88, 0.86, 0.81))

# --------------------------------------------------------- layer settings

func _settings_header(title: String) -> void:
	var head: HBoxContainer = HBoxContainer.new()
	head.add_theme_constant_override("separation", int(UiKit.s(6.0)))
	_settings.add_child(head)

	var back: Button = UiKit.make_text_button(UiKit.label_for("Back", "رجوع"))
	back.pressed.connect(_close_settings)
	head.add_child(back)

	var name_l: Label = UiKit.make_label(title, 15.0, UiKit.TEXT)
	name_l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	head.add_child(name_l)

	_settings.add_child(HSeparator.new())

func _note(text: String) -> void:
	var l: Label = UiKit.make_label(text, 10.0, UiKit.TEXT_DIM)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_settings.add_child(l)

func _build_layer_settings(index: int) -> void:
	var l: LayerStack.Layer = stack.layers[index]
	var title: String = l.title
	if l.is_background:
		title = UiKit.label_for("Background", "الخلفية")
	_settings_header(title)

	# The value is written live so the canvas answers the finger, but the
	# history only hears about it once, when the finger lifts.
	var before: Array = []
	var fade: TouchSlider = UiKit.slider_row(_settings,
		UiKit.label_for("Opacity", "الشفافية"),
		0.0, 1.0, l.opacity, 0.01, "",
		func(x: float) -> void:
			if before.is_empty():
				before.append(stack.capture_arrangement())
			stack.set_opacity_at(index, x))
	fade.drag_ended.connect(func(_x: float) -> void:
		if before.is_empty():
			return
		view.history.push(UiKit.label_for("Layer opacity", "شفافية طبقة"),
			[{"t": "arrangement", "state": before[0]}])
		before.clear())

	var lock: Button = UiKit.make_text_button(
		UiKit.label_for("Locked", "مقفلة") if l.locked
		else UiKit.label_for("Unlocked", "غير مقفلة"), true)
	lock.pressed.connect(func() -> void:
		stack.set_locked_at(index, not stack.layers[index].locked)
		_rebuild())
	_settings.add_child(lock)

	var bring: Button = UiKit.make_text_button(
		UiKit.label_for("Import image", "استيراد صورة"), true)
	bring.pressed.connect(func() -> void: import_requested.emit(index))
	_settings.add_child(bring)

	var copy: Button = UiKit.make_text_button(
		UiKit.label_for("Duplicate", "نسخة مطابقة"), true)
	copy.pressed.connect(func() -> void:
		stack.duplicate_layer(index)
		_close_settings())
	_settings.add_child(copy)

	var open_it: Button = UiKit.make_text_button(
		UiKit.label_for("Open this layer alone", "افتح هذه الطبقة وحدها"), true)
	open_it.pressed.connect(func() -> void: solo_requested.emit(index))
	_settings.add_child(open_it)

	# A turnaround layer has settings nothing else has, so they appear only
	# here and nowhere near an ordinary drawing layer.
	if l.is_360 and l.character != null:
		_note(UiKit.label_for(
			"A turnaround of %d drawings. Turning it re-draws the pose it is facing; nothing of the rig is ever written into the picture." % l.character.count(),
			"دوران من %d رسوم. تدويره يعيد رسم الوضعية التي يواجهها، ولا يُكتب شيء من الهيكل في الصورة." % l.character.count()))

		UiKit.slider_row(_settings, UiKit.label_for("Facing", "الاتجاه"),
			0.0, 1.0, l.turn_360, 0.005, "",
			func(x: float) -> void:
				l.turn_360 = x
				turn_360_requested.emit(index))

		_settings.add_child(HSeparator.new())
		_note(UiKit.label_for("What the room shows", "ما تعرضه الغرفة"))
		UiKit.slider_row(_settings, UiKit.label_for("Bones", "العظام"),
			0.0, 1.0, l.show_bones, 0.01, "",
			func(x: float) -> void: l.show_bones = x)
		UiKit.slider_row(_settings, UiKit.label_for("Points", "النقاط"),
			0.0, 1.0, l.show_points, 0.01, "",
			func(x: float) -> void: l.show_points = x)
		UiKit.slider_row(_settings, UiKit.label_for("Rings", "الدوائر"),
			0.0, 1.0, l.show_rings, 0.01, "",
			func(x: float) -> void: l.show_rings = x)
		_note(UiKit.label_for(
			"These only govern what you see while working. None of it reaches the drawing.",
			"هذه تحكم ما تراه أثناء العمل فقط، ولا يصل شيء منها إلى الرسم."))
		_settings.add_child(HSeparator.new())

	# Light. It belongs to the layer rather than to the brush, because it is
	# about how this drawing meets the ones under it — and a glow painted
	# before the switch was flicked should not have to be painted again.
	var glow: Button = UiKit.make_text_button(
		UiKit.label_for("Light layer", "طبقة ضوء"), true)
	glow.toggle_mode = true
	glow.set_pressed_no_signal(l.glow)
	glow.pressed.connect(func() -> void:
		stack.set_glow_at(index, not l.glow))
	_settings.add_child(glow)
	_note(UiKit.label_for(
		"Adds its light to the layers below instead of covering them. A halo over a night scene lifts what it falls on and leaves the dark alone.",
		"يضيف ضوءه إلى الطبقات تحته بدل أن يغطيها. فالهالة فوق مشهد ليلي ترفع ما تقع عليه وتترك العتمة كما هي."))

	# A text layer still knows its own words, so it offers to be rewritten
	# rather than erased and typed again. This only appears on layers that
	# were made by writing — on a drawing there is nothing to reopen.
	if l.is_text:
		var rewrite: Button = UiKit.make_text_button(
			UiKit.label_for("Edit the text", "عدّل النص"), true)
		rewrite.pressed.connect(func() -> void:
			text_edit_requested.emit(index))
		_settings.add_child(rewrite)
		_note(UiKit.label_for(
			"The words are kept, not just their picture — so this restyles rather than redraws.",
			"الكلمات محفوظة لا صورتها فقط — فهذا يعيد تنسيقها لا رسمها."))

	# Bending belongs to a layer, so it is offered where a layer is being
	# talked about rather than in the tool rail: the rail chooses what the
	# hand is doing, and this changes what the drawing already is.
	var warp: Button = UiKit.make_text_button(
		UiKit.label_for("Puppet warp", "التحريك بالدبابيس"), true)
	warp.pressed.connect(func() -> void:
		stack.set_active(index)
		puppet_requested.emit(index))
	_settings.add_child(warp)
	_note(UiKit.label_for(
		"Pin the drawing and pull. What you pin holds still.",
		"ثبّت الرسم بالدبابيس ثم اسحب. وما تثبّته يبقى مكانه."))

	if not l.is_background:
		if l.group_id != 0:
			var out: Button = UiKit.make_text_button(
				UiKit.label_for("Take out of the folder", "أخرجها من المجلد"), true)
			out.pressed.connect(func() -> void:
				stack.ungroup_layer(index)
				_close_settings())
			_settings.add_child(out)

	if index > 0:
		var merge: Button = UiKit.make_text_button(
			UiKit.label_for("Merge into the one below", "دمج مع التي تحتها"), true)
		merge.pressed.connect(func() -> void:
			stack.merge_down(index)
			_close_settings())
		_settings.add_child(merge)

	var wipe: Button = UiKit.make_text_button(
		UiKit.label_for("Erase its contents", "امسح محتواها"), true)
	wipe.pressed.connect(func() -> void:
		stack.clear_layer(index)
		_close_settings())
	_settings.add_child(wipe)

	if l.is_background:
		_settings.add_child(UiKit.make_label(
			UiKit.label_for("The background stays. Only what is on it can go.",
				"الخلفية لا تُحذف. يُمسح محتواها فقط."), 11.0, UiKit.TEXT_DIM))

func _build_group_settings(gid: int) -> void:
	var g: LayerStack.Group = stack.group_by_id(gid)
	if g == null:
		_close_settings()
		return
	_settings_header(g.title)

	var before: Array = []
	var fade: TouchSlider = UiKit.slider_row(_settings,
		UiKit.label_for("Folder opacity", "شفافية المجلد"),
		0.0, 1.0, g.opacity, 0.01, "",
		func(x: float) -> void:
			if before.is_empty():
				before.append(stack.capture_arrangement())
			stack.set_group_opacity(gid, x))
	fade.drag_ended.connect(func(_x: float) -> void:
		if before.is_empty():
			return
		view.history.push(UiKit.label_for("Folder opacity", "شفافية مجلد"),
			[{"t": "arrangement", "state": before[0]}])
		before.clear())

	_settings.add_child(UiKit.make_label(
		UiKit.label_for("Dims every layer inside it.",
			"تخفّف كل الطبقات التي بداخله."), 11.0, UiKit.TEXT_DIM))

	var expand: Button = UiKit.make_text_button(
		UiKit.label_for("Open the folder", "افتح المجلد"), true)
	expand.pressed.connect(func() -> void:
		stack.set_group_collapsed(gid, false)
		_close_settings())
	_settings.add_child(expand)

	# The animation layer: it sits at the head of the folder and reads the
	# bones of everything inside it, so a figure drawn across several layers
	# poses as one figure. It gathers the skeleton, never the drawings — the
	# layers under it stay exactly as many layers as they were.
	_settings.add_child(HSeparator.new())
	var rigged: bool = stack.group_has_rig(gid)
	var anim: Button = UiKit.make_text_button(
		UiKit.label_for("Animation layer", "طبقة التحريك"), true)
	anim.disabled = not rigged
	anim.pressed.connect(func() -> void:
		g.is_animation = true
		animation_layer_requested.emit(gid)
		_close_settings())
	_settings.add_child(anim)
	_settings.add_child(UiKit.make_label(UiKit.label_for(
		"Gathers the bones of every rigged layer in this folder and moves them as one skeleton."
		if rigged else
		"Give a layer in this folder bones first, in the B-Spline room.",
		"يجمع عظام كل طبقة مُهيكلة في هذا المجلد ويحركها كهيكل واحد."
		if rigged else
		"أعطِ طبقةً في هذا المجلد عظاماً أولاً، من غرفة بي-سبلاين."),
		11.0, UiKit.TEXT_DIM))
	_settings.add_child(HSeparator.new())

	var undo_group: Button = UiKit.make_text_button(
		UiKit.label_for("Remove the folder", "أزل المجلد"), true)
	undo_group.pressed.connect(func() -> void:
		stack.dissolve_group(gid)
		_close_settings())
	_settings.add_child(undo_group)

	_settings.add_child(UiKit.make_label(
		UiKit.label_for("The layers inside are kept.",
			"الطبقات التي بداخله تبقى كما هي."), 11.0, UiKit.TEXT_DIM))
