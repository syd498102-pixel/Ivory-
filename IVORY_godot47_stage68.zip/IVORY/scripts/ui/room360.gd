class_name Room360
extends Control
## The room where a turnaround becomes a character you can turn.

## Cream and warm, not the cold grey of the drawing rooms — this one is about
## looking at a figure rather than marking one, and the light should say so.
##
## The grid is measured in the page's own units and labelled, because a
## turnaround only works if the eight drawings agree about scale, and the only
## way to see that they agree is to be able to read it off.

signal closed()
signal exported(character: Character360)

const ICON: String = "res://assets/icons/%s.png"
const PAPER: Color = Color(0.113, 0.101, 0.086, 1.0)
const GRID_INK: Color = Color(0.86, 0.72, 0.48, 0.13)
const GRID_BOLD: Color = Color(0.90, 0.76, 0.52, 0.26)
const AXIS_INK: Color = Color(0.95, 0.83, 0.60, 0.55)
const GOLD: Color = Color("#D9B45B")
const CREAM: Color = Color("#FFF3DC")
const EMBER: Color = Color("#E08A3C")

enum Mode { TURN, BUILD, CONNECT, TEST }

## How close the room will let you get.
##
## The ceiling was sixteen, which sounds generous until you try to put a child
## point on a knuckle: at sixteen times, a knuckle on a full-figure turnaround
## is still only a few pixels across, and the point lands on the finger beside
## it. Rigging is work done at the scale of the joint, not the scale of the
## figure, so the room now goes to sixty-four — close enough that a knuckle
## fills a thumb.
##
## The floor comes down too, because the way back out matters just as much:
## after working on a hand you want the whole figure in one gesture rather
## than four pinches.
const MIN_ZOOM: float = 0.02
const MAX_ZOOM: float = 64.0

## How near a finger has to be to catch something, in screen pixels.
##
## It was twenty-four page units, which is a different thing entirely: at low
## zoom it caught everything within a hand's width, and at high zoom — exactly
## when you are working carefully — it shrank to nothing and the point you
## were reaching for could not be caught at all.
##
## Measured on the screen instead, and scaled for the device, so the grab is
## the same size under the finger at every zoom: a little under half a
## centimetre, which is about the width of a fingertip's contact patch and the
## figure the platform guidelines settle on.
const GRAB_PX: float = 30.0
## Connect asks for a slightly wider grab than Build, because joining two
## things that are already placed is a coarser act than placing them.
const GRAB_PX_WIDE: float = 34.0

var view: CanvasView = null
var character: Character360 = null
var rig: Rig360 = Rig360.new()
var mode: int = Mode.TURN
## What kind of thing the Build mode is currently laying down.
var build_kind: int = Rig360.Kind.CHILD
var build_ring: int = -1
var build_bone: bool = false
var show_dead: bool = false
## Where the figure is facing, 0 to 1 around the whole turn.
var turn: float = 0.0

var _board: Control = null
var _bar: PanelContainer = null
var _say: Label = null
var _spin_from: float = 0.0
var _spin_at: Vector2 = Vector2.ZERO
var _spinning: bool = false
## How fast the figure is still turning after the finger has left it.
##
## A turntable that stops dead the instant you let go feels like a slideshow.
## Carrying the speed and letting it fall away is most of what makes this
## read as an object rather than a row of pictures — and it costs one number.
var _spin_speed: float = 0.0
var _spin_last: float = 0.0
var _spin_time: int = 0

var _grab_joint: int = -1
var _grab_ring: int = -1
var _grab_bone: Array = []
var _link_from: int = -1
var _drag_from: Vector2 = Vector2.ZERO
var _dragging: bool = false
var _bar_for: int = -1
var _bar_inverse: bool = false
var _bar_path: PackedVector2Array = PackedVector2Array()
var _tap_ms: int = 0
var _tap_key: int = -1
var _export_button: Button = null
var _mode_buttons: Dictionary = {}
var _kind_buttons: Dictionary = {}
const DOUBLE_TAP_MS: int = 320

var _zoom: float = 1.0
var _pan: Vector2 = Vector2.ZERO
var _touches: Dictionary = {}
var _pinch_span: float = 0.0
var _pinch_zoom: float = 1.0
var _pinch_mid: Vector2 = Vector2.ZERO

func setup(canvas: CanvasView) -> bool:
	view = canvas
	if view == null:
		return false
	_build_shell()
	return true

func _build_shell() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP

	var back: ColorRect = ColorRect.new()
	back.color = PAPER
	back.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(back)

	_board = Control.new()
	_board.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_board.mouse_filter = Control.MOUSE_FILTER_STOP
	_board.draw.connect(_draw_board)
	_board.gui_input.connect(_on_board_input)
	add_child(_board)

	var leave: Button = UiKit.make_tool_button(ICON % "exit",
		UiKit.label_for("Exit", "خروج"))
	leave.pressed.connect(func() -> void: closed.emit())
	add_child(leave)
	resized.connect(func() -> void:
		leave.position = Vector2(size.x - UiKit.s(66.0), UiKit.s(14.0))
		_layout_bar()
		_frame())
	leave.position = Vector2(size.x - UiKit.s(66.0), UiKit.s(14.0))

	_build_bar()
	_frame()

func _build_bar() -> void:
	_bar = PanelContainer.new()
	_bar.add_theme_stylebox_override("panel", UiKit.rail_style())
	_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	add_child(_bar)
	_bar.resized.connect(_layout_bar)

	var col: VBoxContainer = VBoxContainer.new()
	col.add_theme_constant_override("separation", int(UiKit.s(5.0)))
	_bar.add_child(col)

	_say = UiKit.make_label("", 11.0, UiKit.TEXT_DIM)
	_say.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_say.custom_minimum_size = Vector2(UiKit.s(320.0), 0.0)
	col.add_child(_say)

	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", int(UiKit.s(5.0)))
	col.add_child(row)

	var bring: Button = UiKit.make_text_button(
		UiKit.label_for("Import PNG sequence", "استيراد تسلسل PNG"), true)
	bring.pressed.connect(_ask_for_sheet)
	row.add_child(bring)

	# --- what the hand is doing ---
	var modes: HBoxContainer = HBoxContainer.new()
	modes.add_theme_constant_override("separation", int(UiKit.s(5.0)))
	col.add_child(modes)
	_mode_button(modes, Mode.TURN, UiKit.label_for("Orbit", "مدار"))
	_mode_button(modes, Mode.BUILD, UiKit.label_for("Build", "بناء"))
	_mode_button(modes, Mode.CONNECT, UiKit.label_for("Connect", "اتصال"))
	_mode_button(modes, Mode.TEST, UiKit.label_for("Test", "تجربة"))

	# --- what Build lays down ---
	var kinds: HBoxContainer = HBoxContainer.new()
	kinds.add_theme_constant_override("separation", int(UiKit.s(5.0)))
	col.add_child(kinds)
	_kind_button(kinds, "child", UiKit.label_for("Child", "ابن"), Rig360.AMBER)
	_kind_button(kinds, "parent", UiKit.label_for("Parent", "أب"), Rig360.RED)
	_kind_button(kinds, "grand", UiKit.label_for("Grandparent", "جد"),
		Rig360.GREEN)
	_kind_button(kinds, "bone", UiKit.label_for("Bone", "عظم"),
		Rig360.BONE_INK)
	_kind_button(kinds, "purple", UiKit.label_for("Ring", "حلقة"),
		Rig360.PURPLE)
	_kind_button(kinds, "tiffany", UiKit.label_for("Limb ring", "حلقة طرف"),
		Rig360.TIFFANY)
	_kind_button(kinds, "white", UiKit.label_for("Body ring", "حلقة الجسم"),
		Rig360.WHITE_RING)

	var send: Button = UiKit.make_text_button(
		UiKit.label_for("Export to timeline", "تصدير إلى التايم لاين"), true)
	send.pressed.connect(func() -> void:
		if character == null:
			_tell(UiKit.label_for("Nothing imported yet", "لم يُستورد شيء بعد"))
			return
		exported.emit(character))
	_export_button = send
	row.add_child(send)

	var ghosts: Button = UiKit.make_text_button(
		UiKit.label_for("Show dead rings", "أظهر الحلقات الميتة"), true)
	ghosts.toggle_mode = true
	ghosts.pressed.connect(func() -> void:
		show_dead = not show_dead
		ghosts.text = UiKit.label_for("Hide dead rings", "أخفِ الحلقات الميتة") \
			if show_dead \
			else UiKit.label_for("Show dead rings", "أظهر الحلقات الميتة")
		_refresh())
	row.add_child(ghosts)

	var rest: Button = UiKit.make_text_button(
		UiKit.label_for("Rest pose", "الوضع الأصلي"), true)
	rest.pressed.connect(func() -> void:
		rig.rest_pose()
		_refresh())
	row.add_child(rest)

	_set_mode(Mode.TURN)

func _mode_button(row: HBoxContainer, which: int, label: String) -> void:
	var b: Button = UiKit.make_text_button(label, true)
	b.toggle_mode = true
	b.pressed.connect(func() -> void: _set_mode(which))
	_mode_buttons[which] = b
	row.add_child(b)

func _kind_button(row: HBoxContainer, id: String, label: String,
		tint: Color) -> void:
	var b: Button = UiKit.make_text_button(label, true)
	b.toggle_mode = true
	b.add_theme_color_override("font_color", tint)
	b.pressed.connect(func() -> void: _set_kind(id))
	_kind_buttons[id] = b
	row.add_child(b)

func _set_kind(id: String) -> void:
	build_bone = id == "bone"
	build_ring = -1
	match id:
		"child": build_kind = Rig360.Kind.CHILD
		"parent": build_kind = Rig360.Kind.PARENT
		"grand": build_kind = Rig360.Kind.GRANDPARENT
		"purple": build_ring = Rig360.RingKind.PURPLE
		"tiffany": build_ring = Rig360.RingKind.TIFFANY
		"white": build_ring = Rig360.RingKind.WHITE
	for key in _kind_buttons.keys():
		(_kind_buttons[key] as Button).set_pressed_no_signal(key == id)
	if mode != Mode.BUILD:
		_set_mode(Mode.BUILD)
	else:
		_say_mode()

## Each mode has one rule, and the room says which is in force rather than
## leaving it to be discovered by a gesture that does nothing.
func _set_mode(which: int) -> void:
	mode = which
	for key in _mode_buttons.keys():
		(_mode_buttons[key] as Button).set_pressed_no_signal(key == which)
	_grab_joint = -1
	_grab_ring = -1
	_grab_bone = []
	_link_from = -1
	_bar_for = -1
	_say_mode()
	_refresh()

func _say_mode() -> void:
	match mode:
		Mode.TURN:
			_tell(UiKit.label_for(
				"Drag sideways to turn the figure. 01 is the front and every other pose is measured against it.",
				"اسحب أفقياً لتدوير الشخصية. و01 هو الأمام، وتُقاس بقيّة الوضعيات عليه."))
		Mode.BUILD:
			if build_bone:
				_tell(UiKit.label_for(
					"Drag inside the figure to lay a bone. A bone cannot begin, end or pass outside the drawing.",
					"اسحب داخل الشخصية لتضع عظماً. لا يمكن للعظم أن يبدأ أو ينتهي أو يمر خارج الرسم."))
			elif build_ring >= 0:
				_tell(UiKit.label_for(
					"Drag along a limb and the ring swells to fit it. Make it larger if that is easier to reach.",
					"اسحب على طول الطرف فتنتفخ الحلقة حتى تناسبه. وكبّرها أكثر إن كان ذلك أسهل لليد."))
			else:
				_tell(UiKit.label_for(
					"Put points where the figure bends. Amber is a bend, red is what a hand pulls, green carries the reds under it.",
					"ضع النقاط حيث تنثني الشخصية. الكهرماني انحناء، والأحمر ما تسحبه اليد، والأخضر يحمل الحمر التي تحته."))
		Mode.CONNECT:
			_tell(UiKit.label_for(
				"Drag from a point to the one above it to join them. One tap on a red adds a movement bar; tap it again for the inverse. One tap on a ring makes it dead — it still holds, but stops turning.",
				"اسحب من نقطة إلى التي فوقها لوصلهما. وضغطة واحدة على الأحمر تضيف شريط تمرير، وضغطة أخرى تضيف التمرير العكسي. وضغطة على الحلقة تجعلها ميتة — تبقى ممسكة لكنها تتوقف عن الدوران."))
		Mode.TEST:
			_tell(UiKit.label_for(
				"Drag a red point along its bar and the chain follows the shape you drew. Rings turn what they cover.",
				"اسحب نقطة حمراء على طول شريطها فتتبع السلسلة الشكل الذي رسمته. والحلقات تدير ما تغطيه."))

func _layout_bar() -> void:
	if _bar == null:
		return
	_bar.position = Vector2((size.x - _bar.size.x) * 0.5,
		size.y - _bar.size.y - UiKit.s(14.0))

func _tell(text: String) -> void:
	if _say != null:
		_say.text = text

# ------------------------------------------------------------------ import

func _ask_for_sheet() -> void:
	var dialog: FileDialog = FileDialog.new()
	dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILES
	dialog.access = FileDialog.ACCESS_FILESYSTEM
	dialog.filters = PackedStringArray(["*.png ; PNG", "*.webp ; WebP",
		"*.jpg, *.jpeg ; JPEG"])
	dialog.title = UiKit.label_for("Choose the turnaround drawings",
		"اختر رسوم الدوران")
	dialog.size = Vector2i(int(size.x * 0.86), int(size.y * 0.84))
	add_child(dialog)
	dialog.files_selected.connect(func(paths: PackedStringArray) -> void:
		_take_sheet(paths)
		dialog.queue_free())
	dialog.canceled.connect(func() -> void: dialog.queue_free())
	dialog.popup_centered()

func _take_sheet(paths: PackedStringArray) -> void:
	var report: Dictionary = Character360.read_sequence(paths)
	if not bool(report.get("ok", false)):
		_tell(UiKit.label_for(
			"Nothing in that selection could be read as a drawing.",
			"لا شيء في هذا الاختيار يمكن قراءته كرسم."))
		return
	character = report["character"]
	turn = 0.0
	_frame()

	# The report is told, not swallowed. A sheet that half-loaded is the
	# usual case, and "import failed" tells nobody what to fix.
	var said: String = "%s: %s  ·  %s %s px" % [
		UiKit.label_for("Poses", "الوضعيات"),
		Lang.number(int(report.get("count", 0))),
		UiKit.label_for("Height", "الارتفاع"),
		Lang.number(int(round(character.standard_height)))]
	var thrown: Array = report.get("thrown", [])
	if not thrown.is_empty():
		# Named, not merely counted. A drawing that was thrown out silently is
		# a drawing the user will spend an evening looking for.
		said += "  ·  " + Lang.fill("Dropped {0} repeated or stray drawings",
			[thrown.size()], "حُذف {0} من الرسوم المكرّرة أو الدخيلة")
		var listed: PackedStringArray = PackedStringArray()
		for row in thrown:
			listed.append("%s (%s)" % [Lang.digits(String(row["path"])),
				Lang.t(String(row["why"]))])
		said += ": " + ", ".join(listed)
	_tell(said)
	_refresh()

# ------------------------------------------------------------------ turning

func _frame() -> void:
	if character == null or character.count() == 0 or size.x <= 0.0:
		return
	var pose: Character360.Pose = character.pose_at(character.master)
	if pose == null:
		return
	var span: Vector2 = Vector2(pose.ink.size)
	if span.x <= 0.0 or span.y <= 0.0:
		return
	_zoom = minf(size.x / span.x, size.y / span.y) * 0.62
	_pan = size * 0.5
	_refresh()

func to_screen(p: Vector2) -> Vector2:
	return p * _zoom + _pan

func to_page(p: Vector2) -> Vector2:
	return (p - _pan) / maxf(_zoom, 0.000001)

func _refresh() -> void:
	if _board != null:
		_board.queue_redraw()

# -------------------------------------------------------------------- input

func _on_board_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var st: InputEventScreenTouch = event as InputEventScreenTouch
		if st.pressed:
			_touches[st.index] = st.position
			if _touches.size() == 2:
				_begin_pinch()
			elif _touches.size() == 1:
				_press(st.position)
		else:
			_touches.erase(st.index)
			_release(st.position)
		_board.accept_event()
	elif event is InputEventScreenDrag:
		var sd: InputEventScreenDrag = event as InputEventScreenDrag
		_touches[sd.index] = sd.position
		if _touches.size() >= 2:
			_pinch()
		else:
			_drag(sd.position)
		_board.accept_event()
	elif event is InputEventMouseButton:
		var mb: InputEventMouseButton = event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			_zoom_at(mb.position, 1.1)
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_zoom_at(mb.position, 1.0 / 1.1)
		elif mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_press(mb.position)
			else:
				_release(mb.position)
		_board.accept_event()
	elif event is InputEventMouseMotion:
		var mm: InputEventMouseMotion = event as InputEventMouseMotion
		if mm.button_mask & MOUSE_BUTTON_MASK_LEFT:
			_drag(mm.position)
			_board.accept_event()

## Whether there is ink under a place — the sensor the whole room leans on.
## Nothing may be built on empty paper: a point with no drawing under it has
## nothing to bend, and a bone across air belongs to no limb.
func on_ink(w: Vector2) -> bool:
	if character == null:
		return false
	var pair: Dictionary = character.between(turn)
	if pair.is_empty():
		return false
	var pose: Character360.Pose = pair["a"]
	if pose == null or pose.art == null:
		return false
	# The figure is drawn standing on the origin and centred on it, so the
	# same offset takes a page point back into the drawing.
	var local: Vector2 = w + Vector2(float(pose.ink.size.x) * 0.5,
		float(pose.ink.size.y))
	var px: int = int(floor(local.x)) + pose.ink.position.x
	var py: int = int(floor(local.y)) + pose.ink.position.y
	if px < 0 or py < 0 or px >= pose.art.get_width() \
			or py >= pose.art.get_height():
		return false
	return pose.art.get_pixel(px, py).a > 0.02

func bone_fits(a: Vector2, b: Vector2) -> bool:
	var span: float = a.distance_to(b)
	if span < 6.0:
		return false
	var steps: int = maxi(int(span / 3.0), 8)
	var blank: int = 0
	for i in steps + 1:
		if on_ink(a.lerp(b, float(i) / float(steps))):
			blank = 0
		else:
			blank += 1
			# A run of gaps means the bone has left the drawing. A few is
			# only the hollow inside an outlined shape.
			if blank > maxi(floori(float(steps) / 6.0), 2):
				return false
	return true

func _process(delta: float) -> void:
	if absf(_spin_speed) < 0.0002 or _spinning:
		return
	turn = fposmod(turn + _spin_speed * delta, 1.0)
	# Falls away smoothly rather than stopping. The rate is per second, so it
	# behaves the same whatever the screen is running at.
	_spin_speed *= pow(0.12, delta)
	if absf(_spin_speed) < 0.0002:
		_spin_speed = 0.0
	_carry_rig()
	_refresh()

## The rig rides with the figure.
##
## Eight drawings never agree about where anything sits — a shoulder is higher
## in the back view than in the front, because they were drawn on different
## days. Without this a bone stays at the coordinates it was laid on and
## drifts off its limb the moment the figure turns.
func _carry_rig() -> void:
	if character == null or character.count() == 0:
		return
	var pair: Dictionary = character.between(turn)
	if pair.is_empty():
		return
	var here: Character360.Pose = pair["a"]
	var home: Character360.Pose = character.pose_at(character.master)
	if here == null or home == null:
		return
	var lift: float = 0.0
	# `stretch`, not `scale`: this room is a Control and `scale` is one of
	# its own properties, so a local by that name shadows it.
	var stretch: float = 1.0
	if home.height > 1.0:
		stretch = here.height / home.height
		lift = (home.height - here.height)
	rig.carry_to(int(pair["index_a"]), lift, stretch)

func _press(at: Vector2) -> void:
	var w: Vector2 = to_page(at)
	# Screen-sized, then converted to page units for the hit tests — so it
	# stays a fingertip wide however far in or out the room is zoomed.
	var reach: float = UiKit.s(GRAB_PX) / maxf(_zoom, 0.000001)
	var now: int = Time.get_ticks_msec()
	_drag_from = w
	_dragging = false

	match mode:
		Mode.TURN:
			_spinning = true
			_spin_at = at
			_spin_from = turn
			_spin_speed = 0.0
			_spin_last = turn
			_spin_time = Time.get_ticks_msec()
		Mode.BUILD:
			_press_build(w, reach)
		Mode.CONNECT:
			_press_connect(w, reach, now)
		Mode.TEST:
			_press_test(w, reach)

func _press_build(w: Vector2, reach: float) -> void:
	if build_bone or build_ring >= 0:
		# Both are drawn by dragging, so the press only records where from.
		return
	# An existing point under the finger is moved rather than doubled.
	var hit: int = rig.joint_at(w, reach)
	if hit >= 0:
		_grab_joint = hit
		return
	if not on_ink(w):
		_tell(UiKit.label_for("That is off the figure — nothing placed",
			"هذا خارج الشخصية — لم يُوضع شيء"))
		return
	rig.add_joint(build_kind, w)
	_refresh()

func _press_connect(w: Vector2, reach: float, now: int) -> void:
	var ring: int = rig.ring_at(w, not show_dead)
	if ring >= 0:
		var r: Rig360.Ring = rig.rings[ring] as Rig360.Ring
		var key: int = 10000 + ring
		if now - _tap_ms <= DOUBLE_TAP_MS and _tap_key == key and not r.live:
			# Two taps on a dead ring, while they are being shown, removes
			# it — the only way to take one back once it has vanished.
			rig.remove_ring(ring)
			_tap_key = -1
			_refresh()
			return
		_tap_ms = now
		_tap_key = key
		r.live = not r.live
		_tell(UiKit.label_for("Ring holds and no longer turns",
			"الحلقة تمسك ولم تعد تدور") if not r.live
			else UiKit.label_for("Ring turns again", "عادت الحلقة تدور"))
		_refresh()
		return

	# A bone end, before a point: the two sit close together on a rigged
	# figure and the bone's grips are the larger target.
	var end: Array = rig.bone_joint_at(w, reach)
	if not end.is_empty():
		var how: int = rig.cycle_bend(int(end[0]), int(end[1]))
		_tell(UiKit.label_for("Right-angle bend — an elbow that reaches its stop",
			"انحناء بزاوية قائمة — كوع يبلغ حدّه") if how == Rig360.Bend.RIGHT
			else UiKit.label_for("Free bend — turns wherever it is taken",
				"انحناء حر — يدور حيث يُؤخذ"))
		_refresh()
		return

	var hit: int = rig.joint_at(w, reach)
	if hit < 0:
		return
	var j: Rig360.Joint = rig.joints[hit] as Rig360.Joint
	if j.kind == Rig360.Kind.PARENT:
		var key2: int = hit
		if now - _tap_ms <= DOUBLE_TAP_MS and _tap_key == key2:
			# The second tap asks for the movement read the other way.
			_bar_for = hit
			_bar_inverse = true
			_bar_path = PackedVector2Array()
			_tap_key = -1
			_tell(UiKit.label_for("Draw the inverse movement",
				"ارسم التمرير العكسي"))
			_refresh()
			return
		_tap_ms = now
		_tap_key = key2
		_bar_for = hit
		_bar_inverse = false
		_bar_path = PackedVector2Array()
		_tell(UiKit.label_for("Draw the movement this point follows",
			"ارسم التمرير الذي تتبعه هذه النقطة"))
		_refresh()
		return
	_link_from = hit

func _press_test(w: Vector2, reach: float) -> void:
	var ring: int = rig.ring_at(w, true)
	if ring >= 0:
		_grab_ring = ring
		return
	var hit: int = rig.joint_at(w, reach)
	if hit >= 0 and (rig.joints[hit] as Rig360.Joint).kind == Rig360.Kind.PARENT:
		_grab_joint = hit
		return
	_grab_bone = rig.bone_joint_at(w, reach)

## A drag across the screen turns the figure once. Sideways only: a
## turnaround has one axis, and letting a vertical wobble affect it makes the
## figure feel like it is fighting the hand.
func _drag(at: Vector2) -> void:
	var w: Vector2 = to_page(at)
	_dragging = true

	if mode == Mode.TURN and _spinning:
		var across: float = (at.x - _spin_at.x) / maxf(size.x * 0.75, 1.0)
		var was: float = turn
		turn = fposmod(_spin_from - across, 1.0)
		# Speed is measured from what actually happened on screen, so a slow
		# careful drag hands over no momentum and a flick hands over a lot.
		var gap: int = Time.get_ticks_msec() - _spin_time
		if gap > 8:
			var moved: float = turn - was
			if moved > 0.5:
				moved -= 1.0
			elif moved < -0.5:
				moved += 1.0
			_spin_speed = moved / (float(gap) / 1000.0)
			_spin_time = Time.get_ticks_msec()
		_carry_rig()
		_refresh()
		return

	if _bar_for >= 0:
		# The bar is drawn, not configured. What the hand does here is
		# exactly what the part will do later.
		if _bar_path.is_empty() or w.distance_to(_bar_path[_bar_path.size() - 1]) > 4.0:
			_bar_path.append(w)
		_refresh()
		return

	if mode == Mode.BUILD:
		if _grab_joint >= 0:
			if on_ink(w):
				var j: Rig360.Joint = rig.joints[_grab_joint] as Rig360.Joint
				j.rest = w
				j.now = w
			_refresh()
		else:
			_refresh()
		return

	if mode == Mode.CONNECT and _link_from >= 0:
		_refresh()
		return

	if mode == Mode.TEST:
		if _grab_joint >= 0:
			# Measured along the bar rather than followed, so the part moves
			# the way it was told it moves however the hand wanders.
			var amount: float = rig.read_bar(_grab_joint, w) \
				if rig.has_bar(_grab_joint) \
				else clampf((w - _drag_from).length() / 160.0, 0.0, 1.0)
			rig.drive(_grab_joint, amount)
			_refresh()
		elif _grab_ring >= 0:
			var r: Rig360.Ring = rig.rings[_grab_ring] as Rig360.Ring
			r.turn = (w - r.centre).angle() - (_drag_from - r.centre).angle()
			_refresh()
		elif not _grab_bone.is_empty():
			var bone: Rig360.Bone = rig.bones[int(_grab_bone[0])] as Rig360.Bone
			rig.swing_bone(int(_grab_bone[0]), int(_grab_bone[1]),
				w - bone.carry)
			_refresh()
		return

func _release(at: Vector2) -> void:
	var w: Vector2 = to_page(at)
	if _spinning:
		# A drag that ended still moving keeps going; one that ended at rest
		# stays where it was put.
		_spin_speed = clampf(_spin_speed, -2.4, 2.4)
		if absf(_spin_speed) < 0.05:
			_spin_speed = 0.0
	_spinning = false

	# A bar being drawn is kept when the finger lifts, and the hand is free
	# again — tapping anywhere puts it away, which is what the spec asked for
	# and also what a hand expects after finishing a gesture.
	if _bar_for >= 0:
		if _bar_path.size() >= 2:
			rig.set_bar(_bar_for, _bar_path, _bar_inverse)
			_tell(UiKit.label_for("Movement saved — try it in Test",
				"حُفظ التمرير — جرّبه في وضع التجربة"))
		_bar_for = -1
		_bar_path = PackedVector2Array()
		_refresh()
		return

	if mode == Mode.BUILD and _dragging:
		if build_bone:
			if bone_fits(_drag_from, w):
				rig.add_bone(_drag_from, w)
				_tell(UiKit.label_for("Bone laid", "وُضع العظم"))
			else:
				_tell(UiKit.label_for(
					"That bone would leave the figure — nothing laid",
					"هذا العظم يخرج عن الشخصية — لم يُوضع شيء"))
		elif build_ring >= 0:
			# Dragged along a limb: the ring swells to cover what was
			# stroked, and sits in the middle of it.
			var span: float = _drag_from.distance_to(w)
			if span > 10.0:
				# Which way it turns is read from the way it was drawn — a
				# ring built down an arm turns in the arm's plane, one built
				# across the body turns in the body's.
				var across: bool = absf(w.x - _drag_from.x) \
					> absf(w.y - _drag_from.y)
				rig.add_ring(build_ring, (_drag_from + w) * 0.5,
					span * 0.55, Rig360.Axis.HORIZONTAL if across
					else Rig360.Axis.VERTICAL)
				_tell(UiKit.label_for("Ring placed", "وُضعت الحلقة"))
		_refresh()

	if mode == Mode.CONNECT and _link_from >= 0:
		var reach: float = UiKit.s(GRAB_PX_WIDE) / maxf(_zoom, 0.000001)
		var upper: int = rig.joint_at(w, reach)
		if upper >= 0 and upper != _link_from:
			if rig.connect_joints(_link_from, upper):
				_tell(UiKit.label_for("Joined", "وُصلت"))
			else:
				# The refusal is explained. A rig that silently declines is
				# a rig somebody spends ten minutes fighting.
				_tell(UiKit.label_for(
					"A child hangs from a parent, and a parent from a grandparent — not the other way round.",
					"الابن يُعلَّق بالأب، والأب بالجد — لا العكس."))
		_link_from = -1
		_refresh()

	_grab_joint = -1
	_grab_ring = -1
	_grab_bone = []
	_dragging = false

func _begin_pinch() -> void:
	_spinning = false
	var keys: Array = _touches.keys()
	var a: Vector2 = _touches[keys[0]]
	var b: Vector2 = _touches[keys[1]]
	_pinch_span = a.distance_to(b)
	_pinch_zoom = _zoom
	_pinch_mid = (a + b) * 0.5

func _pinch() -> void:
	var keys: Array = _touches.keys()
	if keys.size() < 2:
		return
	var a: Vector2 = _touches[keys[0]]
	var b: Vector2 = _touches[keys[1]]
	var span: float = a.distance_to(b)
	if _pinch_span < 8.0 or span < 8.0:
		return
	var mid: Vector2 = (a + b) * 0.5
	var anchor: Vector2 = to_page(_pinch_mid)
	_zoom = clampf(_pinch_zoom * span / _pinch_span, MIN_ZOOM, MAX_ZOOM)
	_pinch_mid = mid
	_pan += mid - to_screen(anchor)
	_refresh()

func _zoom_at(screen: Vector2, by: float) -> void:
	var anchor: Vector2 = to_page(screen)
	_zoom = clampf(_zoom * by, MIN_ZOOM, MAX_ZOOM)
	_pan += screen - to_screen(anchor)
	_refresh()

# --------------------------------------------------------------------- draw

func _draw_board() -> void:
	_draw_grid()
	_draw_figure()
	if mode != Mode.TURN:
		_draw_rig()
	_draw_compass()

## The rig, drawn at a constant size on screen.
##
## None of this is ever exported. The guide line between two joined points
## says where a bend is and nothing more — it is not a bone, it carries no
## drawing, and the picture that leaves this room has no trace of it.
func _draw_rig() -> void:
	var thin: float = 1.0 / maxf(_zoom, 0.000001)
	var shown: Dictionary = _rig_visibility()

	# --- rings ---
	if float(shown["rings"]) > 0.01:
		for i in rig.rings.size():
			var r: Rig360.Ring = rig.rings[i] as Rig360.Ring
			if not r.live and not show_dead:
				continue
			var tint: Color = Rig360.PURPLE
			if r.kind == Rig360.RingKind.TIFFANY:
				tint = Rig360.TIFFANY
			elif r.kind == Rig360.RingKind.WHITE:
				tint = Rig360.WHITE_RING
			var alpha: float = float(shown["rings"]) * (0.9 if r.live else 0.32)
			var mid: Vector2 = to_screen(r.centre)
			var rad: float = r.radius * _zoom
			# A ring lying in the body's plane is drawn as an ellipse, so
			# which way it turns is visible without being told.
			var squash: float = 0.34 if r.axis == Rig360.Axis.HORIZONTAL else 1.0
			var ring_pts: PackedVector2Array = PackedVector2Array()
			for k in 49:
				var ang: float = float(k) / 48.0 * TAU
				ring_pts.append(mid + Vector2(cos(ang) * rad,
					sin(ang) * rad * squash))
			_board.draw_polyline(ring_pts,
				Color(tint.r, tint.g, tint.b, alpha), UiKit.s(2.2))
			if not r.live:
				_board.draw_line(mid - Vector2(rad, 0.0) * 0.3,
					mid + Vector2(rad, 0.0) * 0.3,
					Color(tint.r, tint.g, tint.b, alpha), UiKit.s(1.6))

	# --- bones ---
	if float(shown["bones"]) > 0.01:
		for b in rig.bones:
			var bone: Rig360.Bone = b as Rig360.Bone
			_draw_bone(to_screen(bone.a + bone.carry),
				to_screen(bone.b + bone.carry), float(shown["bones"]),
				bone.bend_a, bone.bend_b)
	if mode == Mode.BUILD and build_bone and _dragging:
		var ok: bool = bone_fits(_drag_from, to_page(_board.get_local_mouse_position()))
		_board.draw_line(to_screen(_drag_from),
			_board.get_local_mouse_position(),
			Rig360.BONE_INK if ok else Color(0.85, 0.35, 0.30, 0.9),
			UiKit.s(2.6))

	if float(shown["points"]) <= 0.01:
		return

	# --- the guide lines between joined points ---
	for i in rig.joints.size():
		var j: Rig360.Joint = rig.joints[i] as Rig360.Joint
		if j.parent < 0:
			continue
		var up: Rig360.Joint = rig.joints[j.parent] as Rig360.Joint
		_board.draw_dashed_line(to_screen(j.now), to_screen(up.now),
			Color(0.95, 0.92, 0.85, 0.34 * float(shown["points"])),
			UiKit.s(1.4), UiKit.s(6.0))

	if _link_from >= 0:
		_board.draw_line(to_screen((rig.joints[_link_from] as Rig360.Joint).now),
			_board.get_local_mouse_position(),
			Color(0.95, 0.92, 0.85, 0.5), UiKit.s(1.6))

	# --- the movement bars ---
	for i in rig.joints.size():
		var jb: Rig360.Joint = rig.joints[i] as Rig360.Joint
		if jb.kind != Rig360.Kind.PARENT:
			continue
		_draw_bar(jb, jb.bar, EMBER, float(shown["points"]))
		_draw_bar(jb, jb.mirror, Rig360.TIFFANY, float(shown["points"]))
	if _bar_for >= 0 and _bar_path.size() > 1:
		var live: PackedVector2Array = PackedVector2Array()
		for p in _bar_path:
			live.append(to_screen(p))
		_board.draw_polyline(live, CREAM, UiKit.s(2.4))

	# --- the points themselves ---
	for i in rig.joints.size():
		_draw_joint(rig.joints[i] as Rig360.Joint, thin,
			float(shown["points"]))

## What the layer settings have asked to be shown. Nothing here changes the
## rig; it only governs what reaches the screen.
func _rig_visibility() -> Dictionary:
	var out: Dictionary = {"bones": 1.0, "points": 1.0, "rings": 1.0}
	if view == null or view.layers == null:
		return out
	for l in view.layers.layers:
		if l.is_360:
			out["bones"] = l.show_bones
			out["points"] = l.show_points
			out["rings"] = l.show_rings
			break
	return out

func _draw_bar(j: Rig360.Joint, bar: PackedVector2Array, tint: Color,
		alpha: float) -> void:
	if bar.size() < 2:
		return
	var line: PackedVector2Array = PackedVector2Array()
	for p in bar:
		line.append(to_screen(j.rest + p))
	_board.draw_polyline(line, Color(tint.r, tint.g, tint.b, 0.75 * alpha),
		UiKit.s(2.0))
	_board.draw_circle(line[line.size() - 1], UiKit.s(3.4),
		Color(tint.r, tint.g, tint.b, alpha))

func _draw_joint(j: Rig360.Joint, _thin: float, alpha: float) -> void:
	var at: Vector2 = to_screen(j.now)
	var tint: Color = Rig360.AMBER
	var r: float = UiKit.s(7.0)
	if j.kind == Rig360.Kind.PARENT:
		tint = Rig360.RED
		r = UiKit.s(9.0)
	elif j.kind == Rig360.Kind.GRANDPARENT:
		tint = Rig360.GREEN
		r = UiKit.s(11.0)
	_board.draw_circle(at + Vector2(1.0, 2.0), r + UiKit.s(1.5),
		Color(0.0, 0.0, 0.0, 0.3 * alpha))
	_board.draw_circle(at, r, Color(tint.r, tint.g, tint.b, alpha))
	_board.draw_arc(at, r, 0.0, TAU, 20,
		Color(1.0, 1.0, 1.0, 0.55 * alpha), UiKit.s(1.6))

## A bone, in ivory, with a grip at each end.
##
## Drawn as a tapered spindle rather than a line so which way it runs is
## readable without a legend, and with a mark on each end that says how that
## end bends — a square for a right-angle stop, a circle for a free turn.
## Shape rather than colour, because these sit on top of artwork of every
## colour there is.
func _draw_bone(a: Vector2, b: Vector2, alpha: float,
		bend_a: int = 0, bend_b: int = 0) -> void:
	var dir: Vector2 = b - a
	var span: float = dir.length()
	if span < 1.0:
		return
	dir = dir / span
	var side: Vector2 = Vector2(-dir.y, dir.x)
	var wide: float = clampf(span * 0.13, 5.0, 15.0)
	var neck: Vector2 = a + dir * (span * 0.22)
	var body: PackedVector2Array = PackedVector2Array([
		a, neck + side * wide, b, neck - side * wide])
	_board.draw_colored_polygon(body,
		Color(Rig360.BONE_INK.r, Rig360.BONE_INK.g, Rig360.BONE_INK.b,
			0.46 * alpha))
	_board.draw_polyline(PackedVector2Array([a, neck + side * wide, b,
		neck - side * wide, a]),
		Color(Rig360.BONE_INK.r, Rig360.BONE_INK.g, Rig360.BONE_INK.b,
			0.9 * alpha), UiKit.s(1.8))
	_draw_grip(a, wide * 0.86, bend_a, alpha)
	_draw_grip(b, wide * 0.76, bend_b, alpha)

func _draw_grip(at: Vector2, r: float, bend: int, alpha: float) -> void:
	var core: Color = Color(Rig360.BONE_CORE.r, Rig360.BONE_CORE.g,
		Rig360.BONE_CORE.b, alpha)
	var edge: Color = Color(Rig360.BONE_EDGE.r, Rig360.BONE_EDGE.g,
		Rig360.BONE_EDGE.b, alpha)
	_board.draw_circle(at + Vector2(1.0, 2.0), r + UiKit.s(1.4),
		Color(0.0, 0.0, 0.0, 0.28 * alpha))
	if bend == Rig360.Bend.RIGHT:
		_board.draw_rect(Rect2(at - Vector2(r, r), Vector2(r, r) * 2.0),
			core, true)
		_board.draw_rect(Rect2(at - Vector2(r, r), Vector2(r, r) * 2.0),
			edge, false, UiKit.s(2.0))
	else:
		_board.draw_circle(at, r, core)
		_board.draw_arc(at, r, 0.0, TAU, 20, edge, UiKit.s(2.0))

func _draw_grid() -> void:
	var want: float = 64.0 / maxf(_zoom, 0.000001)
	var step: float = pow(10.0, floor(log(maxf(want, 1.0)) / log(10.0)))
	for mult in [1.0, 2.0, 5.0, 10.0]:
		if step * mult >= want:
			step *= mult
			break

	var top_left: Vector2 = to_page(Vector2.ZERO)
	var bottom_right: Vector2 = to_page(_board.size)
	var f: Font = UiKit.font if UiKit.font != null else ThemeDB.fallback_font

	var x: float = floor(top_left.x / step) * step
	while x <= bottom_right.x:
		var sx: float = to_screen(Vector2(x, 0.0)).x
		var bold: bool = absf(fmod(x, step * 5.0)) < 0.001
		_board.draw_line(Vector2(sx, 0.0), Vector2(sx, _board.size.y),
			GRID_BOLD if bold else GRID_INK, 1.0)
		if bold and f != null:
			_board.draw_string(f, Vector2(sx + 3.0, 14.0),
				"%d" % int(round(x)), HORIZONTAL_ALIGNMENT_LEFT, -1, 10,
				AXIS_INK)
		x += step

	var y: float = floor(top_left.y / step) * step
	while y <= bottom_right.y:
		var sy: float = to_screen(Vector2(0.0, y)).y
		var bold_y: bool = absf(fmod(y, step * 5.0)) < 0.001
		_board.draw_line(Vector2(0.0, sy), Vector2(_board.size.x, sy),
			GRID_BOLD if bold_y else GRID_INK, 1.0)
		if bold_y and f != null:
			_board.draw_string(f, Vector2(4.0, sy - 3.0),
				"%d" % int(round(y)), HORIZONTAL_ALIGNMENT_LEFT, -1, 10,
				AXIS_INK)
		y += step

	# The ground line. A turnaround stands on it, and having it drawn is what
	# makes an uneven pose obvious instead of merely wrong-looking.
	var o: Vector2 = to_screen(Vector2.ZERO)
	_board.draw_line(Vector2(0.0, o.y), Vector2(_board.size.x, o.y),
		AXIS_INK, 1.8)
	_board.draw_line(Vector2(o.x, 0.0), Vector2(o.x, _board.size.y),
		Color(AXIS_INK.r, AXIS_INK.g, AXIS_INK.b, 0.30), 1.2)

## The figure, at whatever angle the turn has reached.
##
## Two drawings are laid down, the near one over the far one, each brought to
## the same height and stood on the same ground so the figure does not bob or
## drift while it turns. The narrowing with the cosine of the angle is what
## makes the change read as a rotation rather than a dissolve.
func _draw_figure() -> void:
	if character == null or character.count() == 0:
		return
	var pair: Dictionary = character.between(turn)
	if pair.is_empty():
		return
	var a: Character360.Pose = pair["a"]
	var b: Character360.Pose = pair["b"]
	var t: float = float(pair["t"])
	# The gentler curve, now that there is nothing to hide. See the note on
	# TurnMorph.hand_over.
	var mix: float = TurnMorph.hand_over(t) \
		if (a != null and b != null and a.shape != null and b.shape != null) \
		else Character360.hand_over(t)
	var total: int = character.count()

	# Both drawings are warped onto one blended silhouette before either is
	# shown, so what crosses the screen is a single outline changing shape
	# rather than two outlines at different strengths. See `turn_morph.gd`.
	#
	# Falls back to the flat draw whenever the profiles are not there — a
	# turnaround loaded from a project saved before this existed has none
	# until it is re-read, and a figure that draws the old way is better
	# than a figure that does not draw.
	if a != null and b != null and a.shape != null and b.shape != null:
		if mix < 0.999:
			_draw_morph(a, a.shape, b.shape, t, 1.0 - mix)
		if mix > 0.001:
			# B is warped *backwards* toward A by the same amount, so the two
			# meet in the middle instead of one travelling all the way.
			_draw_morph(b, b.shape, a.shape, 1.0 - t, mix)
		return

	if a != null and mix < 0.999:
		_draw_pose(a, 1.0 - mix,
			Character360.foreshorten(float(int(pair["index_a"])),
				float(int(pair["index_b"])), t, total))
	if b != null and mix > 0.001:
		_draw_pose(b, mix,
			Character360.foreshorten(float(int(pair["index_a"])),
				float(int(pair["index_b"])), t, total))

## One warped drawing, placed by its feet and its middle.
##
## The mesh is built in figure space — feet at the origin, one unit is the
## standard height — so everything to do with where the character stands, how
## far the room is zoomed and where it is panned lives in this one transform
## and never inside the morph.
func _draw_morph(pose: Character360.Pose, mine: TurnMorph.Profile,
		other: TurnMorph.Profile, t: float, alpha: float) -> void:
	if character == null:
		return
	if pose == null or pose.texture == null:
		return
	var mesh: ArrayMesh = TurnMorph.build(pose.ink, pose.middle, mine, other,
		t, character.standard_height)
	if mesh == null:
		return
	var unit: float = maxf(character.standard_height, 1.0)
	var foot: Vector2 = to_screen(Vector2.ZERO)
	var at: Transform2D = Transform2D(0.0, Vector2(unit * _zoom, unit * _zoom),
		0.0, foot)
	_board.draw_set_transform_matrix(at)
	_board.draw_mesh(mesh, pose.texture, Transform2D.IDENTITY,
		Color(1.0, 1.0, 1.0, clampf(alpha, 0.0, 1.0)))
	_board.draw_set_transform_matrix(Transform2D.IDENTITY)

func _draw_pose(pose: Character360.Pose, alpha: float, squeeze: float) -> void:
	if pose == null or pose.texture == null:
		return
	# Placed by its feet and its middle, never by the corner of its file — a
	# turnaround is loosely centred and lining up the files would make the
	# figure wander as it turns.
	var wide: float = float(pose.ink.size.x) * squeeze
	var tall: float = float(pose.ink.size.y)
	var foot: Vector2 = to_screen(Vector2(0.0, 0.0))
	var box: Rect2 = Rect2(
		foot.x - wide * 0.5 * _zoom,
		foot.y - tall * _zoom,
		wide * _zoom, tall * _zoom)
	var src: Rect2 = Rect2(Vector2(pose.ink.position), Vector2(pose.ink.size))
	_board.draw_texture_rect_region(pose.texture, box, src,
		Color(1.0, 1.0, 1.0, clampf(alpha, 0.0, 1.0)))

## Which way the figure is facing, as a dial. Eight marks, the lit one being
## the pose nearest what is on screen.
func _draw_compass() -> void:
	if character == null or character.count() == 0:
		return
	var n: int = character.count()
	var mid: Vector2 = Vector2(_board.size.x * 0.5, UiKit.s(74.0))
	var reach: float = UiKit.s(42.0)
	_board.draw_arc(mid, reach, 0.0, TAU, 48,
		Color(GOLD.r, GOLD.g, GOLD.b, 0.28), UiKit.s(1.4))

	for i in n:
		var ang: float = float(i) / float(n) * TAU - PI * 0.5
		var at: Vector2 = mid + Vector2(cos(ang), sin(ang)) * reach
		var near: float = absf(fposmod(turn * float(n) - float(i) + float(n) * 0.5,
			float(n)) - float(n) * 0.5)
		var lit: bool = near < 0.5
		_board.draw_circle(at, UiKit.s(4.5) if lit else UiKit.s(3.0),
			CREAM if lit else Color(GOLD.r, GOLD.g, GOLD.b, 0.45))

	var head: float = turn * TAU - PI * 0.5
	_board.draw_line(mid, mid + Vector2(cos(head), sin(head)) * reach,
		EMBER, UiKit.s(2.2))
	_board.draw_circle(mid, UiKit.s(3.4), EMBER)

	var f: Font = UiKit.font if UiKit.font != null else ThemeDB.fallback_font
	if f != null:
		var pair: Dictionary = character.between(turn)
		if not pair.is_empty():
			var which: int = int(pair["index_a"])
			var pose: Character360.Pose = pair["a"]
			var facing: int = pose.facing if pose != null else which
			var row: Array = Character360.FACING[
				clampi(facing, 0, Character360.FACING.size() - 1)]
			_board.draw_string(f, Vector2(mid.x - UiKit.s(70.0),
				mid.y + reach + UiKit.s(20.0)),
				UiKit.label_for(String(row[1]), String(row[2])),
				HORIZONTAL_ALIGNMENT_CENTER, UiKit.s(140.0),
				int(UiKit.s(12.0)), CREAM)
