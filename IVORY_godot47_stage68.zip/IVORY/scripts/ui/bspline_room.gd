class_name BSplineRoom
extends Control
## A room for moving a drawing, rather than distorting one.

## The layer comes in on its own against a measured grid, and everything that
## happens here is done by steering curves and bones — never by pushing pixels
## about. That distinction runs through the whole design: a control point does
## not drag the ink near it, it changes the shape of a curve, and the drawing
## rides that curve. Which is why a limb bent here keeps its length and its
## thickness, and why the same bend done by shoving a mesh does not.
##
## The drawing is bound to a curve in **curve space**: for every scrap of ink,
## how far along the curve it sits and how far off to the side. Move the
## control points and the curve changes; each scrap is put back at the same
## place along the new curve, turned by however much the curve turned there.
## Length along the curve is preserved by construction, and because the curve
## is C² the turning changes smoothly — so a joint bends without the pinch
## that a triangle mesh folds into.

signal closed()
signal applied()

const ICON: String = "res://assets/icons/%s.png"
const GRID_INK: Color = Color(0.44, 0.45, 0.48, 0.30)
const GRID_BOLD: Color = Color(0.58, 0.60, 0.64, 0.46)
const AXIS_INK: Color = Color(0.72, 0.76, 0.82, 0.72)
const GOLD: Color = Color("#D9B45B")
const IVORY: Color = Color("#FFF8E7")
const BONE_INK: Color = Color("#E8D5A3")
const TAP_MS: int = 320
const HOLD_MS: int = 380

enum Mode { ADD, MOVE, CONNECT, BONE, POSE }

# --- what came in ---
var view: CanvasView = null
var layer_id: int = -1
var page: Rect2i = Rect2i()
var art: Image = null
var _art_tex: ImageTexture = null
var _ink_rect: Rect2i = Rect2i()

# --- the rig ---
var spline: BSpline = null
var bones: Array = []
## The sheet of ink, as a mesh laid over it. Everything the rigs do is done
## to these vertices; the picture rides on them.
var _rest: PackedVector2Array = PackedVector2Array()
var _now: PackedVector2Array = PackedVector2Array()
var _uv: PackedVector2Array = PackedVector2Array()
var _tris: PackedInt32Array = PackedInt32Array()
var _cols: int = 0
var _rows: int = 0
var _cell: Vector2 = Vector2.ONE
var _slot: PackedInt32Array = PackedInt32Array()
var _home: PackedInt32Array = PackedInt32Array()
## Per vertex: where it sits in the rest curve's own frame.
## How far *along* the rest curve each vertex sat, measured as distance and
## not as parameter — see `_bind_curve` for why that distinction is the whole
## difference between moving a drawing and stretching one.
var _curve_s: PackedFloat32Array = PackedFloat32Array()
var _curve_t: PackedFloat32Array = PackedFloat32Array()
var _curve_n: PackedFloat32Array = PackedFloat32Array()
var _curve_pull: PackedFloat32Array = PackedFloat32Array()
## Per vertex per bone: the vertex written in that bone's rest frame, and how
## much say the bone has.
var _skin: Array = []
var _mesh_node: MeshInstance2D = null
var _arc_pts: PackedVector2Array = PackedVector2Array()
var _arc_len: PackedFloat32Array = PackedFloat32Array()

# --- what the hand is doing ---
var mode: int = Mode.ADD
var _grab: int = -1
var _grab_bone: int = -1
var _grab_end: int = 0
var _bone_from: Vector2 = Vector2.ZERO
var _bone_drawing: bool = false
var _tap_ms: int = 0
var _tap_at: int = -1
var _press_ms: int = 0
var _press_at: Vector2 = Vector2.ZERO

# --- the window onto the page ---
var _zoom: float = 1.0
var _pan: Vector2 = Vector2.ZERO
var _touches: Dictionary = {}
var _pinch_span: float = 0.0
var _pinch_zoom: float = 1.0
var _pinch_mid: Vector2 = Vector2.ZERO

var _board: Control = null
var _bar: PanelContainer = null
var _mode_buttons: Dictionary = {}
var _say: Label = null

class Bone extends RefCounted:
	var rest_a: Vector2 = Vector2.ZERO
	var rest_b: Vector2 = Vector2.ZERO
	var a: Vector2 = Vector2.ZERO
	var b: Vector2 = Vector2.ZERO
	## A hinged joint turns in right angles, the way an elbow reaches its
	## stop. A free one turns wherever it is taken.
	var hinged: bool = false
	## The bone this one hangs from, so a chain moves as a chain.
	var parent: int = -1

	func length() -> float:
		return rest_a.distance_to(rest_b)

# ------------------------------------------------------------------ set up

## Opening a whole folder instead of one layer.
##
## Every rigged layer inside it is read in and its bones gathered into one
## skeleton, so a figure built as separate drawings — body, arm, head — poses
## as a figure. The layers stay exactly as many layers as they were: what is
## shared is the skeleton, never the ink.
var _framed: bool = false
var gather_group: int = -1
var _members: Array = []

func setup_group(canvas: CanvasView, group_id: int) -> bool:
	view = canvas
	if view == null or view.layers == null or view.projects.active == null:
		return false
	_members = []
	for l in view.layers.layers:
		if l.group_id == group_id and not l.rig.is_empty():
			_members.append(l)
	if _members.is_empty():
		return false
	gather_group = group_id
	if not setup(canvas):
		return false

	# The gathered skeleton is every member's bones side by side, in the pose
	# each was last left in.
	bones.clear()
	for l in _members:
		var doc: Dictionary = l.rig
		for row in doc.get("bones", []):
			var b: Bone = Bone.new()
			b.rest_a = Vector2(float(row["ax"]), float(row["ay"]))
			b.rest_b = Vector2(float(row["bx"]), float(row["by"]))
			b.a = Vector2(float(row.get("px", row["ax"])),
				float(row.get("py", row["ay"])))
			b.b = Vector2(float(row.get("qx", row["bx"])),
				float(row.get("qy", row["by"])))
			b.hinged = bool(row.get("hinged", false))
			b.parent = -1
			bones.append(b)

	# Bones that meet are chained, so a limb built across two layers still
	# swings from its shoulder rather than floating free of it.
	for i in bones.size():
		var mine: Bone = bones[i] as Bone
		var best: int = -1
		var best_d: float = 30.0 * 30.0
		for k in bones.size():
			if k == i:
				continue
			var d: float = mine.rest_a.distance_squared_to(
				(bones[k] as Bone).rest_b)
			if d < best_d:
				best_d = d
				best = k
		mine.parent = best

	_set_mode(Mode.POSE)
	_rebind()
	_refresh()
	return true

func setup(canvas: CanvasView) -> bool:
	view = canvas
	if view == null or view.layers == null or view.projects.active == null:
		return false
	var layer: LayerStack.Layer = view.layers.active()
	if layer == null:
		return false
	layer.surface.flush()
	page = Rect2i(Vector2i.ZERO, Vector2i(view.projects.active.page))
	_ink_rect = layer.surface.content_bounds().intersection(page)
	if _ink_rect.size.x < 4 or _ink_rect.size.y < 4:
		return false
	art = layer.surface.read_region(_ink_rect)
	if art == null:
		return false
	var used: Rect2i = art.get_used_rect()
	if used.size.x < 4 or used.size.y < 4:
		return false
	if used.position != Vector2i.ZERO or used.size != _ink_rect.size:
		var trim: Image = Image.create_empty(used.size.x, used.size.y, false,
			Image.FORMAT_RGBA8)
		trim.blit_rect(art, used, Vector2i.ZERO)
		art = trim
		_ink_rect = Rect2i(_ink_rect.position + used.position, used.size)
	_art_tex = ImageTexture.create_from_image(art)
	layer_id = layer.id

	spline = BSpline.new()
	bones = []
	_build_shell()
	_build_mesh()
	# A layer posed before comes back standing as it was left.
	if not layer.rig.is_empty() and gather_group < 0:
		load_rig(layer.rig)
	return true

func _build_shell() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP

	var back: ColorRect = ColorRect.new()
	back.color = Color(0.055, 0.058, 0.066, 1.0)
	back.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(back)

	_board = Control.new()
	_board.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_board.mouse_filter = Control.MOUSE_FILTER_STOP
	_board.draw.connect(_draw_board)
	_board.gui_input.connect(_on_board_input)
	add_child(_board)

	# Only one thing lives at the top of this room, and it is the way out.
	var leave: Button = UiKit.make_tool_button(ICON % "exit",
		UiKit.label_for("Exit", "خروج"))
	leave.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	leave.position = Vector2(size.x - UiKit.s(66.0), UiKit.s(14.0))
	leave.pressed.connect(func() -> void: closed.emit())
	add_child(leave)
	resized.connect(func() -> void:
		leave.position = Vector2(size.x - UiKit.s(66.0), UiKit.s(14.0))
		_layout_bar())

	_build_bar()

func _build_bar() -> void:
	_bar = PanelContainer.new()
	_bar.add_theme_stylebox_override("panel", UiKit.rail_style())
	_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	add_child(_bar)
	_bar.resized.connect(_layout_bar)

	var col: VBoxContainer = VBoxContainer.new()
	col.add_theme_constant_override("separation", int(UiKit.s(5.0)))
	_bar.add_child(col)

	_say = UiKit.make_label("", 11.0, UiKit.TEXT_DIM)
	_say.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_say.custom_minimum_size = Vector2(UiKit.s(300.0), 0.0)
	col.add_child(_say)

	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", int(UiKit.s(5.0)))
	col.add_child(row)

	_mode_button(row, Mode.ADD, UiKit.label_for("Add point", "أضف نقطة"))
	_mode_button(row, Mode.MOVE, UiKit.label_for("Move", "تحريك"))
	_mode_button(row, Mode.CONNECT, UiKit.label_for("Connect", "وصل"))
	_mode_button(row, Mode.BONE, UiKit.label_for("Add bone", "أضف عظماً"))
	_mode_button(row, Mode.POSE, UiKit.label_for("Pose", "تحريك العظام"))

	var row2: HBoxContainer = HBoxContainer.new()
	row2.add_theme_constant_override("separation", int(UiKit.s(5.0)))
	col.add_child(row2)

	var rest: Button = UiKit.make_text_button(
		UiKit.label_for("Rest pose", "الوضع الأصلي"), true)
	rest.pressed.connect(_rest_pose)
	row2.add_child(rest)

	var wipe: Button = UiKit.make_text_button(
		UiKit.label_for("Clear rig", "امسح الهيكل"), true)
	wipe.pressed.connect(func() -> void:
		spline.clear()
		bones.clear()
		_skin = []
		_grab = -1
		_rebind()
		_refresh())
	row2.add_child(wipe)

	var go: Button = UiKit.make_text_button(
		UiKit.label_for("Application", "تطبيق"), true)
	go.pressed.connect(_apply)
	row2.add_child(go)

	_set_mode(Mode.ADD)

func _mode_button(row: HBoxContainer, which: int, label: String) -> void:
	var b: Button = UiKit.make_text_button(label, true)
	b.toggle_mode = true
	b.pressed.connect(func() -> void: _set_mode(which))
	_mode_buttons[which] = b
	row.add_child(b)

func _layout_bar() -> void:
	if _bar == null:
		return
	_bar.position = Vector2((size.x - _bar.size.x) * 0.5,
		size.y - _bar.size.y - UiKit.s(14.0))

## The rules change with the mode, so the room says which rule is in force
## rather than leaving it to be discovered by a gesture that does nothing.
func _set_mode(which: int) -> void:
	mode = which
	for key in _mode_buttons.keys():
		(_mode_buttons[key] as Button).set_pressed_no_signal(key == which)
	_grab = -1
	_grab_bone = -1
	_bone_drawing = false
	match which:
		Mode.ADD:
			_tell(UiKit.label_for(
				"Put every point on the drawing first. Points off the artwork are refused — a point with no ink under it has nothing to carry.",
				"ضع كل النقاط على الرسم أولاً. النقاط خارج الرسم مرفوضة — نقطة بلا حبر تحتها لا تحمل شيئاً."))
		Mode.MOVE:
			_tell(UiKit.label_for(
				"Move only. Points cannot be added here, so a hand reaching for one can never leave a new one behind.",
				"التحريك فقط. لا تُضاف نقاط هنا، فاليد الممتدة إلى نقطة لا تترك خلفها نقطة جديدة أبداً."))
		Mode.CONNECT:
			_tell(UiKit.label_for(
				"Tap between two points to put a new one there, or tap a point twice to make the curve turn a corner at it instead of flowing through.",
				"اضغط بين نقطتين لوضع نقطة بينهما، أو اضغط نقطة مرتين ليصنع المنحنى زاوية عندها بدل أن ينساب."))
		Mode.BONE:
			_tell(UiKit.label_for(
				"Drag inside the drawing to lay a bone. A bone cannot begin, end or pass outside the artwork.",
				"اسحب داخل الرسم لتضع عظماً. لا يمكن للعظم أن يبدأ أو ينتهي أو يمر خارج الرسم."))
		Mode.POSE:
			_tell(UiKit.label_for(
				"Drag a joint to swing its bone. Tap a joint twice to switch it between a right-angle hinge and a free turn.",
				"اسحب مفصلاً لتحريك عظمه. اضغط المفصل مرتين للتبديل بين مفصل بزاوية قائمة ودوران حر."))
	_refresh()

func _tell(text: String) -> void:
	if _say != null:
		_say.text = text

# ------------------------------------------------------- page <-> screen

## Sets the page in the middle of the screen, once, the first moment both the
## page and the screen have a size.
##
## This used to `await get_tree().process_frame` from inside `setup()`. But
## `setup()` runs while the room is still a loose object — it is only added to
## anything if setup succeeds — and `get_tree()` on a node outside the tree is
## null. Awaiting a property of null is what raised
##
##     Invalid access to property or key 'process_frame'
##     on a base object of type 'null instance'
##
## and it is why the room never opened. Nothing needs to be awaited: the room
## is told when it is given a size, so it waits to be told.
func _frame_page() -> void:
	if _framed:
		return
	var span: Vector2 = Vector2(page.size)
	if span.x <= 0.0 or span.y <= 0.0 or size.x <= 0.0 or size.y <= 0.0:
		return
	_framed = true
	_zoom = minf(size.x / span.x, size.y / span.y) * 0.72
	_pan = size * 0.5 - span * 0.5 * _zoom
	_refresh()

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	resized.connect(_frame_page)
	_frame_page()

func to_screen(p: Vector2) -> Vector2:
	return p * _zoom + _pan

func to_page(p: Vector2) -> Vector2:
	return (p - _pan) / maxf(_zoom, 0.000001)

# ------------------------------------------------------------ safety sensor

## Whether there is ink under a place on the page.
##
## This is the sensor the whole room leans on. A control point steers a curve
## that the drawing rides; a point placed where no drawing is has nothing
## under it to carry, and a bone laid across empty air is a bone belonging to
## no limb. Both are refused rather than accepted and left to behave oddly
## later.
func on_ink(at: Vector2) -> bool:
	if art == null or art.get_width() < 1 or art.get_height() < 1:
		return false
	var local: Vector2i = Vector2i((at - Vector2(_ink_rect.position)).floor())
	if local.x < 0 or local.y < 0 \
			or local.x >= art.get_width() or local.y >= art.get_height():
		return false
	return art.get_pixel(local.x, local.y).a > 0.02

## A bone has to lie *along* the drawing, not merely start and end on it —
## an arm and a leg both have ink, and a bone joining them would cross the
## paper between. So the whole length is walked and every step has to land on
## something.
func bone_fits(a: Vector2, b: Vector2) -> bool:
	var span: float = a.distance_to(b)
	if span < 6.0:
		return false
	var steps: int = maxi(int(span / 3.0), 8)
	var misses: int = 0
	for i in steps + 1:
		if not on_ink(a.lerp(b, float(i) / float(steps))):
			misses += 1
			# A few steps may fall in a gap inside a stroke — an outline
			# drawing is mostly hollow. A run of them means the bone has left
			# the drawing altogether.
			# Whole steps on purpose — this is a count of samples.
			@warning_ignore("integer_division")
			var slack: int = floori(float(steps) / 6.0)
			if misses > maxi(slack, 2):
				return false
		else:
			misses = 0
	return true

# ------------------------------------------------------------------- input

func _on_board_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var st: InputEventScreenTouch = event as InputEventScreenTouch
		if st.pressed:
			_touches[st.index] = st.position
			if _touches.size() == 2:
				_begin_pinch()
			elif _touches.size() == 1:
				_press(st.position)
		else:
			_touches.erase(st.index)
			if _touches.is_empty():
				_release(st.position)
		_board.accept_event()
	elif event is InputEventScreenDrag:
		var sd: InputEventScreenDrag = event as InputEventScreenDrag
		_touches[sd.index] = sd.position
		if _touches.size() >= 2:
			_pinch()
		else:
			_drag(sd.position)
		_board.accept_event()
	elif event is InputEventMouseButton:
		var mb: InputEventMouseButton = event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			_zoom_at(mb.position, 1.1)
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_zoom_at(mb.position, 1.0 / 1.1)
		elif mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_press(mb.position)
			else:
				_release(mb.position)
		_board.accept_event()
	elif event is InputEventMouseMotion:
		var mm: InputEventMouseMotion = event as InputEventMouseMotion
		if mm.button_mask & MOUSE_BUTTON_MASK_LEFT:
			_drag(mm.position)
			_board.accept_event()

func _begin_pinch() -> void:
	_grab = -1
	_grab_bone = -1
	_bone_drawing = false
	var keys: Array = _touches.keys()
	var a: Vector2 = _touches[keys[0]]
	var b: Vector2 = _touches[keys[1]]
	_pinch_span = a.distance_to(b)
	_pinch_zoom = _zoom
	_pinch_mid = (a + b) * 0.5

func _pinch() -> void:
	var keys: Array = _touches.keys()
	if keys.size() < 2:
		return
	var a: Vector2 = _touches[keys[0]]
	var b: Vector2 = _touches[keys[1]]
	var span: float = a.distance_to(b)
	if _pinch_span < 8.0 or span < 8.0:
		return
	var mid: Vector2 = (a + b) * 0.5
	var anchor: Vector2 = to_page(_pinch_mid)
	_zoom = clampf(_pinch_zoom * span / _pinch_span, 0.05, 24.0)
	_pan += mid - _pinch_mid
	_pinch_mid = mid
	_pan += to_screen(anchor).direction_to(mid) * 0.0
	_pan += mid - to_screen(anchor)
	_refresh()

func _zoom_at(screen: Vector2, by: float) -> void:
	var anchor: Vector2 = to_page(screen)
	_zoom = clampf(_zoom * by, 0.05, 24.0)
	_pan += screen - to_screen(anchor)
	_refresh()

func _press(screen: Vector2) -> void:
	var w: Vector2 = to_page(screen)
	var now: int = Time.get_ticks_msec()
	_press_ms = now
	_press_at = screen
	var reach: float = 22.0 / maxf(_zoom, 0.000001)

	match mode:
		Mode.ADD:
			if not on_ink(w):
				_tell(UiKit.label_for("That is off the drawing — no point put down",
					"هذا خارج الرسم — لم تُوضع نقطة"))
				return
			spline.add_point(w)
			_rebind()
			_refresh()
		Mode.MOVE:
			_grab = _point_at(w, reach)
		Mode.CONNECT:
			var hit: int = _point_at(w, reach)
			if hit >= 0:
				var double: bool = now - _tap_ms <= TAP_MS and _tap_at == hit
				_tap_ms = now
				_tap_at = hit
				if double:
					# A corner, or back to a flow. This is knot insertion: the
					# same curve, given a place it is allowed to break.
					var was: int = spline.sharpness(hit)
					spline.sharpen(hit, 0 if was > 0 else BSpline.DEGREE)
					_rebind()
					_refresh()
				return
			_insert_between(w)
		Mode.BONE:
			if not on_ink(w):
				_tell(UiKit.label_for("A bone starts on the drawing",
					"العظم يبدأ على الرسم"))
				return
			_bone_from = w
			_bone_drawing = true
		Mode.POSE:
			var found: Array = _joint_at(w, reach)
			if found.is_empty():
				return
			var b_index: int = found[0]
			var which: int = found[1]
			var key: int = b_index * 2 + which
			var double_j: bool = now - _tap_ms <= TAP_MS and _tap_at == key
			_tap_ms = now
			_tap_at = key
			if double_j:
				(bones[b_index] as Bone).hinged = not (bones[b_index] as Bone).hinged
				_tell(UiKit.label_for("Right-angle hinge", "مفصل بزاوية قائمة")
					if (bones[b_index] as Bone).hinged
					else UiKit.label_for("Free turn", "دوران حر"))
				_refresh()
				return
			_grab_bone = b_index
			_grab_end = which

func _drag(screen: Vector2) -> void:
	var w: Vector2 = to_page(screen)
	if mode == Mode.MOVE and _grab >= 0:
		spline.move_point(_grab, w)
		_pose()
		_refresh()
	elif mode == Mode.BONE and _bone_drawing:
		_refresh()
	elif mode == Mode.POSE and _grab_bone >= 0:
		# Dragging the far end of a bone that hangs from another is a reach:
		# the hand goes where the finger goes and the elbow works itself out.
		# Anything else is a swing, exactly as before. Nothing was taken away
		# to add this — a lone bone, or the near end of any bone, behaves
		# precisely as it did, so a rig built before this exists still poses
		# the way its author expects.
		var reached: bool = false
		if _grab_end == 1 and (bones[_grab_bone] as Bone).parent >= 0:
			reached = _reach_to(_grab_bone, w)
		if not reached:
			_swing(_grab_bone, _grab_end, w)
		_pose()
		_refresh()

func _release(screen: Vector2) -> void:
	var w: Vector2 = to_page(screen)
	if mode == Mode.BONE and _bone_drawing:
		_bone_drawing = false
		if bone_fits(_bone_from, w):
			var b: Bone = Bone.new()
			b.rest_a = _bone_from
			b.rest_b = w
			b.a = b.rest_a
			b.b = b.rest_b
			b.parent = _bone_near(_bone_from)
			bones.append(b)
			_bind_bones()
			_tell(UiKit.label_for("Bone laid", "وُضع العظم"))
		else:
			_tell(UiKit.label_for(
				"That bone would leave the drawing — nothing laid",
				"هذا العظم يخرج عن الرسم — لم يُوضع شيء"))
		_refresh()
	var settled: bool = _grab >= 0
	_grab = -1
	_grab_bone = -1
	if settled:
		# Settled. Walk the curve at full precision now and pose from that,
		# so what is left on screen is the accurate shape rather than the
		# coarse one the drag was running on.
		_measure_arc()
		_pose()
		_refresh()

func _point_at(w: Vector2, reach: float) -> int:
	var best: int = -1
	var best_d: float = reach * reach
	for i in spline.size():
		var d: float = w.distance_squared_to(_posed_point(i))
		if d <= best_d:
			best_d = d
			best = i
	return best

func _posed_point(i: int) -> Vector2:
	return spline.points[i]

func _joint_at(w: Vector2, reach: float) -> Array:
	var best: Array = []
	var best_d: float = reach * reach
	for i in bones.size():
		var b: Bone = bones[i] as Bone
		var da: float = w.distance_squared_to(b.a)
		if da <= best_d:
			best_d = da
			best = [i, 0]
		var db: float = w.distance_squared_to(b.b)
		if db <= best_d:
			best_d = db
			best = [i, 1]
	return best

## The bone whose far end is nearest — the one this new bone hangs off, so a
## limb built outwards from a body moves as a chain rather than as loose
## sticks.
func _bone_near(at: Vector2) -> int:
	var best: int = -1
	var best_d: float = 26.0 * 26.0
	for i in bones.size():
		var d: float = at.distance_squared_to((bones[i] as Bone).rest_b)
		if d < best_d:
			best_d = d
			best = i
	return best

## Swinging a joint turns the bone about its other end rather than stretching
## it. A bone has a length and keeps it — that is the whole reason to use one
## instead of dragging the drawing directly.
func _swing(index: int, which: int, to: Vector2) -> void:
	var b: Bone = bones[index] as Bone
	var pivot: Vector2 = b.b if which == 0 else b.a
	var span: float = b.length()
	var dir: Vector2 = to - pivot
	if dir.length_squared() < 0.000001:
		return
	if b.hinged:
		# Quarter turns only. An elbow does not stop wherever it likes; it
		# reaches a stop, and this is that stop made honest.
		var step: float = TAU / 4.0
		var ang: float = round(dir.angle() / step) * step
		dir = Vector2.RIGHT.rotated(ang)
	dir = dir.normalized() * span
	if which == 0:
		b.a = pivot + dir
	else:
		b.b = pivot + dir
	_carry_children(index)

## Children follow their parent, so a forearm goes where the upper arm sends
## it instead of staying behind.
func _carry_children(index: int) -> void:
	var parent: Bone = bones[index] as Bone
	for i in bones.size():
		var child: Bone = bones[i] as Bone
		if child.parent != index:
			continue
		var shift: Vector2 = parent.b - parent.rest_b
		child.a = child.rest_a + shift
		child.b = child.rest_b + shift
		_carry_children(i)

## Reaching, rather than swinging.
##
## Swinging turns one bone about one end. That is exact and it is also the
## slow way to pose an arm: to put a hand on a doorknob you swing the upper
## arm, look, swing the forearm, look, and repeat until the two happen to
## agree. Everybody who has rigged a limb has done this, and nobody enjoys it.
##
## Reaching takes the *hand* to the doorknob and works out the elbow. Two
## bones, two known lengths, one known target — the triangle is determined,
## and the only thing left to choose is which way the elbow points, which is
## a property of the limb rather than of the pose. So it is solved in closed
## form: no iteration, no convergence, nothing to tune, and the same answer
## every time for the same input. On a tablet that matters twice, because an
## iterative solver would run this on every drag event of every frame.
##
## The chain is `index` (the lower bone: forearm) hanging from its parent
## (the upper: upper arm). `to` is where the far end of the lower bone should
## finish. Returns false when there is no two-bone chain here, so the caller
## can fall back to an ordinary swing.
##
## Lengths are never changed. When the target is further away than the arm is
## long, the arm straightens toward it and stops — which is what an arm does.
## When the target is closer than the arm can fold, the elbow opens to its
## tightest angle instead of inverting through itself.
func _reach_to(index: int, to: Vector2) -> bool:
	if index < 0 or index >= bones.size():
		return false
	var lower: Bone = bones[index] as Bone
	if lower.parent < 0 or lower.parent >= bones.size():
		return false
	var upper: Bone = bones[lower.parent] as Bone

	# The shoulder is the upper bone's far end from the joint they share.
	var root: Vector2 = upper.a
	var l1: float = upper.length()
	var l2: float = lower.length()
	if l1 < 0.001 or l2 < 0.001:
		return false

	var span: Vector2 = to - root
	var d: float = span.length()
	var reach: float = l1 + l2
	if d < 0.000001:
		span = Vector2.RIGHT
		d = 1.0

	if d >= reach - 0.000001:
		# Out of reach: straight at it, stopping where the arm ends.
		var straight: Vector2 = span / d
		upper.a = root
		upper.b = root + straight * l1
		lower.a = upper.b
		lower.b = root + straight * reach
		_carry_children(index)
		return true

	# Too close to fold any tighter: hold the tightest fold rather than let
	# the elbow pass through the shoulder, which is what an unclamped
	# arc-cosine does with a target inside the inner limit.
	var inner: float = absf(l1 - l2)
	if d < inner + 0.000001:
		d = inner + 0.000001
		span = span.normalized() * d

	# The elbow sits where two circles meet: one of radius l1 about the
	# shoulder, one of radius l2 about the wrist. `bend` picks which of the
	# two meeting points, and it is remembered from the pose the limb is
	# already in so the elbow does not flip sides as the hand crosses the
	# line between shoulder and target.
	var base: float = span.angle()
	var cos_a: float = clampf(
		(l1 * l1 + d * d - l2 * l2) / (2.0 * l1 * d), -1.0, 1.0)
	var swing: float = acos(cos_a)
	var bend: float = _elbow_side(root, upper.b, span)
	var arm: float = base + swing * bend

	upper.a = root
	upper.b = root + Vector2.RIGHT.rotated(arm) * l1
	lower.a = upper.b
	lower.b = root + span
	_carry_children(index)
	return true

## Which side of the shoulder-to-target line the elbow is currently on.
##
## Kept from where the limb already is rather than chosen by a setting: an
## elbow does not change which way it bends halfway through a wave, and asking
## an animator to tick a box for something the arm already knows would be
## asking them to describe the obvious. Returns +1 or -1, never 0 — a limb
## that happens to be perfectly straight has to bend *somewhere*, and one
## consistent side beats a coin toss on every frame.
func _elbow_side(root: Vector2, elbow: Vector2, span: Vector2) -> float:
	var arm: Vector2 = elbow - root
	var cross: float = span.x * arm.y - span.y * arm.x
	return -1.0 if cross < 0.0 else 1.0

func _rest_pose() -> void:
	for b in bones:
		(b as Bone).a = (b as Bone).rest_a
		(b as Bone).b = (b as Bone).rest_b
	_pose()
	_refresh()

## A new point is put where the curve already runs, between the two points it
## falls between — so adding one never changes the shape, it only gives the
## shape somewhere else to be held.
func _insert_between(w: Vector2) -> void:
	if spline.size() < 2:
		if on_ink(w):
			spline.add_point(w)
			_rebind()
			_refresh()
		return
	var best: int = 1
	var best_d: float = INF
	for i in range(1, spline.size()):
		var mid: Vector2 = (spline.points[i - 1] + spline.points[i]) * 0.5
		var d: float = w.distance_squared_to(mid)
		if d < best_d:
			best_d = d
			best = i
	var at: Vector2 = (spline.points[best - 1] + spline.points[best]) * 0.5
	spline.insert_point(best, at)
	_rebind()
	_refresh()

# ------------------------------------------------------------ curve binding

# ------------------------------------------------------------- the mesh

## A mesh over the ink, and nowhere else.
##
## Empty cells are dropped for the same reason they are dropped in the warp
## room: they cost the same to move as drawn ones and carry nothing, and they
## bridge gaps that the drawing does not — which is what lets one limb drag
## another it is not joined to.
func _build_mesh(density: int = 40) -> void:
	var span: Vector2 = Vector2(_ink_rect.size)
	var longest: float = maxf(span.x, span.y)
	_cols = clampi(int(round(density * span.x / longest)), 2, 96) + 1
	_rows = clampi(int(round(density * span.y / longest)), 2, 96) + 1
	_cell = Vector2(span.x / float(_cols - 1), span.y / float(_rows - 1))

	var cx_n: int = _cols - 1
	var cy_n: int = _rows - 1
	var probe: Image = art.duplicate()
	if cx_n < 1 or cy_n < 1 or probe.get_width() < 1 or probe.get_height() < 1:
		# A resize to nothing is a hard crash, and a drawing this small has
		# no rig worth building. Leaving the mesh empty is the honest answer.
		_rest = PackedVector2Array()
		_now = PackedVector2Array()
		_tris = PackedInt32Array()
		return
	probe.resize(cx_n, cy_n, Image.INTERPOLATE_BILINEAR)

	var live: PackedByteArray = PackedByteArray()
	live.resize(cx_n * cy_n)
	var any: bool = false
	for y in cy_n:
		for x in cx_n:
			var on: bool = probe.get_pixel(x, y).a > 0.004
			live[y * cx_n + x] = 1 if on else 0
			any = any or on
	if not any:
		live.fill(1)
	else:
		var grown: PackedByteArray = live.duplicate()
		for y in cy_n:
			for x in cx_n:
				if live[y * cx_n + x] != 0:
					continue
				for dy in range(-1, 2):
					for dx in range(-1, 2):
						var nx: int = x + dx
						var ny: int = y + dy
						if nx < 0 or ny < 0 or nx >= cx_n or ny >= cy_n:
							continue
						if live[ny * cx_n + nx] != 0:
							grown[y * cx_n + x] = 1
		live = grown

	_slot = PackedInt32Array()
	_slot.resize(_cols * _rows)
	_slot.fill(-1)
	_rest = PackedVector2Array()
	_uv = PackedVector2Array()
	_home = PackedInt32Array()
	var origin: Vector2 = Vector2(_ink_rect.position)

	var claim: Callable = func(x: int, y: int) -> int:
		var at: int = y * _cols + x
		if _slot[at] >= 0:
			return _slot[at]
		var fx: float = float(x) / float(_cols - 1)
		var fy: float = float(y) / float(_rows - 1)
		_rest.append(origin + Vector2(fx * span.x, fy * span.y))
		_uv.append(Vector2(fx, fy))
		_home.append(at)
		_slot[at] = _rest.size() - 1
		return _slot[at]

	_tris = PackedInt32Array()
	for cy in cy_n:
		for cx in cx_n:
			if live[cy * cx_n + cx] == 0:
				continue
			var a: int = claim.call(cx, cy)
			var b: int = claim.call(cx + 1, cy)
			var c: int = claim.call(cx, cy + 1)
			var d: int = claim.call(cx + 1, cy + 1)
			if (cx + cy) % 2 == 0:
				_tris.append_array([a, b, c])
				_tris.append_array([b, d, c])
			else:
				_tris.append_array([a, b, d])
				_tris.append_array([a, d, c])
	_now = _rest.duplicate()
	_push_mesh()

func _push_mesh() -> void:
	if _mesh_node == null or _now.is_empty():
		return
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = _now
	arrays[Mesh.ARRAY_TEX_UV] = _uv
	arrays[Mesh.ARRAY_INDEX] = _tris
	var mesh: ArrayMesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_mesh_node.mesh = mesh

# ---------------------------------------------------------- curve binding

## Where every part of the drawing sits *relative to the curve*, worked out
## once against the rest shape.
##
## Each vertex is written down as how far along the curve it lies and how far
## off to the side, measured in the curve's own frame at that spot. This is
## what makes the room move a drawing rather than distort one: the
## along-measure is never touched when the curve bends, so nothing stretches
## or compresses along its length. Only the frame turns, and the ink turns
## with it. A limb bent here comes out the same limb, the same length, the
## same thickness — bent.
func _bind_curve() -> void:
	var count: int = _rest.size()
	_curve_s = PackedFloat32Array()
	_curve_t = PackedFloat32Array()
	_curve_n = PackedFloat32Array()
	_curve_pull = PackedFloat32Array()
	_curve_s.resize(count)
	_curve_t.resize(count)
	_curve_n.resize(count)
	_curve_pull.resize(count)
	if spline == null or not spline.ready() or count == 0:
		return

	# How far the curve's authority reaches. Anything much further off than
	# the drawing is wide has nothing to do with this curve, and is left
	# alone rather than dragged along by a spine it does not belong to.
	var span: float = maxf(_ink_rect.size.x, _ink_rect.size.y) * 0.55
	_measure_arc()
	for i in count:
		var s_here: float = _nearest_length(_rest[i])
		var frame: Array = _at_length(s_here)
		var c: Vector2 = frame[0]
		var t: Vector2 = frame[1]
		var n: Vector2 = Vector2(-t.y, t.x)
		var off: Vector2 = _rest[i] - c
		_curve_s[i] = s_here
		_curve_t[i] = off.dot(t)
		_curve_n[i] = off.dot(n)
		_curve_pull[i] = clampf(1.0 - (off.length() / maxf(span, 1.0)), 0.0, 1.0)

## Every vertex written in the frame of every bone near it.
##
## Standard skinning: a vertex is stored in each bone's own coordinates once,
## and put back through wherever that bone has moved to. Bones share a vertex
## by weight, so the ink around a joint is partly governed by each side of it
## and passes smoothly from one to the other instead of tearing along a line.
func _bind_bones() -> void:
	_skin = []
	if bones.is_empty() or _rest.is_empty():
		return
	for i in _rest.size():
		var rows: Array = []
		var total: float = 0.0
		for k in bones.size():
			var b: Bone = bones[k] as Bone
			var away: float = _away_from_segment(_rest[i], b.rest_a, b.rest_b)
			# Inverse square of the distance to the bone itself, not to its
			# ends: a vertex beside the middle of a bone belongs to it just as
			# much as one beside its head.
			var w: float = 1.0 / pow(away * away + 64.0, 1.35)
			# ...and only if the two are actually joined by drawing. Straight
			# distance says a hand resting against a hip is part of the hip;
			# the paper between them says otherwise. Without this a bone in
			# one limb drags ink out of whatever limb happens to lie beside
			# it, which is the single worst thing a rig can do.
			if not _ink_between(_rest[i], b.rest_a, b.rest_b):
				w *= 0.04
			var frame: Transform2D = _bone_frame(b.rest_a, b.rest_b)
			rows.append({"bone": k, "w": w,
				"local": frame.affine_inverse() * _rest[i]})
			total += w
		if total <= 0.0:
			_skin.append([])
			continue
		# Only the few bones with real say are kept. A bone across the figure
		# contributing a thousandth is noise that costs as much to apply as a
		# bone that matters.
		var kept: Array = []
		for row in rows:
			var share: float = float(row["w"]) / total
			if share > 0.02:
				row["w"] = share
				kept.append(row)
		var again: float = 0.0
		for row in kept:
			again += float(row["w"])
		for row in kept:
			row["w"] = float(row["w"]) / maxf(again, 0.000001)
		_skin.append(kept)

## A bone's own coordinate system: along itself, and across itself.
static func _bone_frame(a: Vector2, b: Vector2) -> Transform2D:
	var dir: Vector2 = b - a
	if dir.length_squared() < 0.000001:
		dir = Vector2.RIGHT
	dir = dir.normalized()
	return Transform2D(dir, Vector2(-dir.y, dir.x), a)

## Whether there is a line of drawing from a place to the bone nearest it.
##
## Walked in a straight line to the closest point on the bone, checking for
## ink the whole way. A short run of blank is allowed, because an outlined
## drawing is mostly hollow and a stroke's inside is empty paper. A long run
## means the two are not the same piece of the figure.
func _ink_between(from: Vector2, a: Vector2, b: Vector2) -> bool:
	var ab: Vector2 = b - a
	var len2: float = ab.length_squared()
	var t: float = 0.0 if len2 < 0.000001 \
		else clampf((from - a).dot(ab) / len2, 0.0, 1.0)
	var to: Vector2 = a + ab * t
	var span: float = from.distance_to(to)
	if span < 3.0:
		return true
	var steps: int = clampi(int(span / 4.0), 3, 64)
	var blank: int = 0
	@warning_ignore("integer_division")
	var fifth: int = floori(float(steps) / 5.0)
	var allow: int = maxi(fifth, 2)
	for i in steps + 1:
		if on_ink(from.lerp(to, float(i) / float(steps))):
			blank = 0
		else:
			blank += 1
			if blank > allow:
				return false
	return true

static func _away_from_segment(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ab: Vector2 = b - a
	var len2: float = ab.length_squared()
	if len2 < 0.000001:
		return p.distance_to(a)
	var t: float = clampf((p - a).dot(ab) / len2, 0.0, 1.0)
	return p.distance_to(a + ab * t)

## The curve, walked and measured.
##
## Parameter and distance are not the same thing on a B-spline: it hurries
## through some spans and dawdles through others. Binding by parameter looks
## right until the control points are spread further apart, and then the
## drawing stretches along its own length — the exact thing this room exists
## not to do. So the curve is measured in real distance, and a vertex two
## hundred units along the rest curve is put two hundred units along the posed
## one. Bend it however hard you like: the limb keeps its length.
func _measure_arc() -> void:
	_arc_pts = PackedVector2Array()
	_arc_len = PackedFloat32Array()
	if spline == null or not spline.ready():
		return
	var steps: int = clampi(spline.size() * 40, 120, 900)
	var top: float = spline.span_max()
	var run: float = 0.0
	for i in steps + 1:
		var p: Vector2 = spline.at(top * float(i) / float(steps))
		if i > 0:
			run += p.distance_to(_arc_pts[i - 1])
		_arc_pts.append(p)
		_arc_len.append(run)

func arc_length() -> float:
	if _arc_len.is_empty():
		return 0.0
	return _arc_len[_arc_len.size() - 1]

## The place and heading at a given distance along the curve. Found by
## bisection on the measured table, so it costs a handful of comparisons
## however finely the curve was walked.
func _at_length(s: float) -> Array:
	if _arc_pts.size() < 2:
		return [Vector2.ZERO, Vector2.RIGHT]
	var want: float = clampf(s, 0.0, arc_length())
	var lo: int = 0
	var hi: int = _arc_len.size() - 1
	while lo < hi - 1:
		@warning_ignore("integer_division")
		var mid: int = (lo + hi) / 2
		if _arc_len[mid] <= want:
			lo = mid
		else:
			hi = mid
	var a: float = _arc_len[lo]
	var b: float = _arc_len[lo + 1]
	var f: float = 0.0 if b - a < 0.000001 else (want - a) / (b - a)
	var at: Vector2 = _arc_pts[lo].lerp(_arc_pts[lo + 1], f)
	var ahead: Vector2 = _arc_pts[mini(lo + 2, _arc_pts.size() - 1)]
	var behind: Vector2 = _arc_pts[maxi(lo - 1, 0)]
	var dir: Vector2 = ahead - behind
	if dir.length_squared() < 0.000000001:
		dir = Vector2.RIGHT
	return [at, dir.normalized()]

## The distance along the curve of the point on it nearest a place.
##
## Coarse first, then fine. Binding calls this once for every vertex of the
## mesh against a curve walked into hundreds of samples — checking all of them
## every time is a couple of million distance tests and a visible freeze on a
## tablet the moment a point is added. Striding the first pass and then looking
## closely only around the winner cuts that by roughly ten times and lands on
## the same answer, because the curve is smooth: the nearest sample to a place
## is always beside the nearest point to it.
func _nearest_length(to: Vector2) -> float:
	var count: int = _arc_pts.size()
	if count == 0:
		return 0.0
	@warning_ignore("integer_division")
	var chunk: int = floori(float(count) / 48.0)
	var stride: int = maxi(chunk, 1)
	var best: int = 0
	var best_d: float = INF
	var i: int = 0
	while i < count:
		var d: float = _arc_pts[i].distance_squared_to(to)
		if d < best_d:
			best_d = d
			best = i
		i += stride
	var lo: int = maxi(best - stride, 0)
	var hi: int = mini(best + stride, count - 1)
	for k in range(lo, hi + 1):
		var d2: float = _arc_pts[k].distance_squared_to(to)
		if d2 < best_d:
			best_d = d2
			best = k
	return _arc_len[best]

func _rebind() -> void:
	_bind_curve()
	_bind_bones()
	_pose()

# ---------------------------------------------------------------- posing

## Both rigs speak in displacements, and the displacements add.
##
## Each one says how far it would move a vertex from its rest place, and the
## two are summed. That way either rig used alone is exactly itself, and used
## together neither one overwrites the other — which is what happens if you
## pose one after the other and feed the second the first one's output.
func _pose() -> void:
	if _rest.is_empty():
		return
	var use_curve: bool = spline != null and spline.ready() \
		and _curve_s.size() == _rest.size()
	if use_curve:
		# The curve has changed shape since the last pose, so the map from
		# distance-along to place-on-it has to be measured again.
		_measure_arc()
	var use_bones: bool = not _skin.is_empty()

	for i in _rest.size():
		var here: Vector2 = _rest[i]
		var shift: Vector2 = Vector2.ZERO

		if use_curve:
			var frame: Array = _at_length(_curve_s[i])
			var c: Vector2 = frame[0]
			var t: Vector2 = frame[1]
			var n: Vector2 = Vector2(-t.y, t.x)
			var landed: Vector2 = c + t * _curve_t[i] + n * _curve_n[i]
			shift += (landed - here) * _curve_pull[i]

		if use_bones and i < _skin.size():
			var rows: Array = _skin[i]
			if not rows.is_empty():
				var to: Vector2 = Vector2.ZERO
				for row in rows:
					var b: Bone = bones[int(row["bone"])] as Bone
					to += (_bone_frame(b.a, b.b) * (row["local"] as Vector2)) \
						* float(row["w"])
				shift += to - here

		_now[i] = here + shift
	_push_mesh()

# ------------------------------------------------------------------- apply

## Puts the posed drawing back on the canvas.
##
## The rig is not thrown away. The bones stay on the layer with the pose they
## were left in, so coming back into this room finds the figure standing where
## it was rather than flat again — which is the difference between a tool you
## pose with and a tool you use once.
func _apply() -> void:
	if _now.is_empty() or view == null:
		return
	var baked: Dictionary = await _bake()
	if baked.is_empty():
		_tell(UiKit.label_for("Nothing to put down", "لا شيء ليوضع"))
		return
	var surface: PaintSurface = null
	for l in view.layers.layers:
		if l.id == layer_id:
			surface = l.surface
			l.rig = save_rig()
			break
	if surface == null:
		return

	var box: Rect2i = baked["rect"]
	view.stamp_region(layer_id, box, _ink_rect,
		baked["image"] as Image, baked["at"] as Vector2i,
		UiKit.label_for("B-Spline", "بي-سبلاين"))

	# The pose that was just put down becomes the new rest. Everything is
	# measured again from it — the rig is re-bound to where the drawing is
	# now, not to where it used to be — so the next pose starts from this one
	# instead of springing back to the first.
	_ink_rect = box.intersection(Rect2i(page.position - page.size,
		page.size * 3))
	surface.flush()
	var fresh: Image = surface.read_region(_ink_rect)
	if fresh != null:
		var used: Rect2i = fresh.get_used_rect()
		if used.size.x >= 2 and used.size.y >= 2:
			if used.position != Vector2i.ZERO or used.size != _ink_rect.size:
				var trim: Image = Image.create_empty(used.size.x, used.size.y,
					false, Image.FORMAT_RGBA8)
				trim.blit_rect(fresh, used, Vector2i.ZERO)
				fresh = trim
				_ink_rect = Rect2i(_ink_rect.position + used.position, used.size)
			art = fresh
			_art_tex = ImageTexture.create_from_image(art)
			if _mesh_node != null:
				_mesh_node.texture = _art_tex
			_build_mesh()
			for b in bones:
				var one: Bone = b as Bone
				one.rest_a = one.a
				one.rest_b = one.b
			_rebind()
	applied.emit()
	_refresh()
	_tell(UiKit.label_for("Put down on the canvas", "وُضع على اللوحة"))

## The bent drawing, rendered once by the graphics card.
func _bake() -> Dictionary:
	if _now.is_empty() or _art_tex == null:
		return {}
	var lo: Vector2 = _now[0]
	var hi: Vector2 = _now[0]
	for v in _now:
		lo.x = minf(lo.x, v.x)
		lo.y = minf(lo.y, v.y)
		hi.x = maxf(hi.x, v.x)
		hi.y = maxf(hi.y, v.y)
	var pad: Vector2 = Vector2(2.0, 2.0)
	var box: Rect2i = Rect2i(Vector2i((lo - pad).floor()),
		Vector2i((hi - lo + pad * 2.0).ceil()))
	box.size.x = clampi(box.size.x, 1, 4096)
	box.size.y = clampi(box.size.y, 1, 4096)

	var shifted: PackedVector2Array = PackedVector2Array()
	shifted.resize(_now.size())
	var origin: Vector2 = Vector2(box.position)
	for i in _now.size():
		shifted[i] = _now[i] - origin

	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = shifted
	arrays[Mesh.ARRAY_TEX_UV] = _uv
	arrays[Mesh.ARRAY_INDEX] = _tris
	var mesh: ArrayMesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)

	var port: SubViewport = SubViewport.new()
	port.size = box.size
	port.transparent_bg = true
	port.disable_3d = true
	port.render_target_update_mode = SubViewport.UPDATE_ONCE
	port.render_target_clear_mode = SubViewport.CLEAR_MODE_ONCE
	port.msaa_2d = Viewport.MSAA_4X

	var flat: MeshInstance2D = MeshInstance2D.new()
	flat.mesh = mesh
	flat.texture = _art_tex
	flat.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	flat.material = PaintSurface.premultiplied_material()
	port.add_child(flat)
	add_child(port)

	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var out: Image = port.get_texture().get_image()
	port.queue_free()
	if out == null:
		return {}
	if out.get_format() != Image.FORMAT_RGBA8:
		out.convert(Image.FORMAT_RGBA8)
	return {"image": out, "at": box.position, "rect": box}

# ------------------------------------------------------------------- rig

## The rig, written down so the layer can carry it between sessions.
# ------------------------------------------------------------ rig keys

## Writes the pose currently on screen into this layer's own timeline.
##
## Note what is *not* here: no new layer, no new frame, no copy of the
## drawing. A pose is a few dozen floats laid beside the drawing that already
## exists, which is the whole economy of rigged animation — a hundred poses
## cost less than one extra drawn frame, and that is why a rig can be keyed
## on every frame on a tablet where hand-drawing cannot.
func record_key(frame: int) -> RigTrack.RigKey:
	if view == null or view.layers == null:
		return null
	var l: LayerStack.Layer = view.layers.by_id(layer_id)
	if l == null:
		return null
	if l.poses == null:
		l.poses = RigTrack.new()
	RigTrack.take_bones(l.poses, frame, bones)
	if view.puppet != null and not view.puppet.pins.is_empty():
		RigTrack.take_pins(l.poses, frame, view.puppet.pins)
	return l.poses.key_at(frame)

## Puts a pose from the timeline back on the bones and re-skins.
##
## The far end of each bone is rebuilt from its own rest length rather than
## read from the key, so a bone is exactly as long here as it was drawn —
## see the note at the head of `rig_track.gd` for why storing both ends
## would have made limbs shrink by half mid-swing.
func take_pose(pose: Dictionary) -> void:
	if pose.is_empty() or bones.is_empty():
		return
	if not pose.has("bones"):
		return
	RigTrack.lay_bones(bones, pose["bones"])
	_pose()
	_refresh()

## The pose this layer holds at a frame, if it holds one.
func pose_at(frame: float) -> Dictionary:
	if view == null or view.layers == null:
		return {}
	var l: LayerStack.Layer = view.layers.by_id(layer_id)
	if l == null or l.poses == null:
		return {}
	return l.poses.pose_at(frame)

func save_rig() -> Dictionary:
	var pts: Array = []
	for p in spline.points:
		pts.append([p.x, p.y])
	var sharps: Array = []
	for i in spline.sharp.size():
		sharps.append(spline.sharp[i])
	var sticks: Array = []
	for b in bones:
		var one: Bone = b as Bone
		sticks.append({
			"ax": one.rest_a.x, "ay": one.rest_a.y,
			"bx": one.rest_b.x, "by": one.rest_b.y,
			"px": one.a.x, "py": one.a.y,
			"qx": one.b.x, "qy": one.b.y,
			"hinged": one.hinged, "parent": one.parent,
		})
	return {"points": pts, "sharp": sharps, "bones": sticks}

func load_rig(doc: Dictionary) -> void:
	if doc.is_empty():
		return
	spline.clear()
	for row in doc.get("points", []):
		spline.add_point(Vector2(float(row[0]), float(row[1])))
	var sharps: Array = doc.get("sharp", [])
	for i in mini(sharps.size(), spline.sharp.size()):
		spline.sharp[i] = int(sharps[i])
	spline.rebuild_knots()

	bones.clear()
	for row in doc.get("bones", []):
		var b: Bone = Bone.new()
		b.rest_a = Vector2(float(row["ax"]), float(row["ay"]))
		b.rest_b = Vector2(float(row["bx"]), float(row["by"]))
		b.a = Vector2(float(row.get("px", row["ax"])), float(row.get("py", row["ay"])))
		b.b = Vector2(float(row.get("qx", row["bx"])), float(row.get("qy", row["by"])))
		b.hinged = bool(row.get("hinged", false))
		b.parent = int(row.get("parent", -1))
		bones.append(b)
	_rebind()
	_refresh()

# -------------------------------------------------------------------- draw

func _refresh() -> void:
	if _board != null:
		_board.queue_redraw()

func _draw_board() -> void:
	_draw_grid()
	_draw_art()
	_draw_frame()
	_draw_curve()
	_draw_bones()

## A measured grid, labelled in the page's own units. The room is for precise
## work, and precise work needs to be able to answer "how far" without
## guessing.
func _draw_grid() -> void:
	# A step that stays legible at any zoom: as the page grows on screen the
	# grid subdivides, and as it shrinks the fine lines drop out rather than
	# collapsing into a grey wash.
	var want: float = 64.0 / maxf(_zoom, 0.000001)
	var step: float = pow(10.0, floor(log(maxf(want, 1.0)) / log(10.0)))
	for mult in [1.0, 2.0, 5.0, 10.0]:
		if step * mult >= want:
			step *= mult
			break

	var top_left: Vector2 = to_page(Vector2.ZERO)
	var bottom_right: Vector2 = to_page(_board.size)
	var f: Font = UiKit.font if UiKit.font != null else ThemeDB.fallback_font

	var x: float = floor(top_left.x / step) * step
	while x <= bottom_right.x:
		var sx: float = to_screen(Vector2(x, 0.0)).x
		var bold: bool = absf(fmod(x, step * 5.0)) < 0.001
		_board.draw_line(Vector2(sx, 0.0), Vector2(sx, _board.size.y),
			GRID_BOLD if bold else GRID_INK, 1.0)
		if bold and f != null:
			_board.draw_string(f, Vector2(sx + 3.0, 14.0), "%d" % int(round(x)),
				HORIZONTAL_ALIGNMENT_LEFT, -1, 10, AXIS_INK)
		x += step

	var y: float = floor(top_left.y / step) * step
	while y <= bottom_right.y:
		var sy: float = to_screen(Vector2(0.0, y)).y
		var bold_y: bool = absf(fmod(y, step * 5.0)) < 0.001
		_board.draw_line(Vector2(0.0, sy), Vector2(_board.size.x, sy),
			GRID_BOLD if bold_y else GRID_INK, 1.0)
		if bold_y and f != null:
			_board.draw_string(f, Vector2(4.0, sy - 3.0), "%d" % int(round(y)),
				HORIZONTAL_ALIGNMENT_LEFT, -1, 10, AXIS_INK)
		y += step

	# The origin, drawn as axes so X and Y are readable directions rather than
	# a wall of squares.
	var o: Vector2 = to_screen(Vector2.ZERO)
	_board.draw_line(Vector2(0.0, o.y), Vector2(_board.size.x, o.y), AXIS_INK, 1.6)
	_board.draw_line(Vector2(o.x, 0.0), Vector2(o.x, _board.size.y), AXIS_INK, 1.6)
	if f != null:
		_board.draw_string(f, o + Vector2(6.0, -6.0), "0,0",
			HORIZONTAL_ALIGNMENT_LEFT, -1, 11, AXIS_INK)
		_board.draw_string(f, Vector2(_board.size.x - 22.0, o.y - 6.0), "X",
			HORIZONTAL_ALIGNMENT_LEFT, -1, 12, AXIS_INK)
		_board.draw_string(f, Vector2(o.x + 6.0, 22.0), "Y",
			HORIZONTAL_ALIGNMENT_LEFT, -1, 12, AXIS_INK)

func _draw_art() -> void:
	if _art_tex == null:
		return
	var at: Vector2 = to_screen(Vector2(_ink_rect.position))
	var box: Rect2 = Rect2(at, Vector2(_ink_rect.size) * _zoom)
	_board.draw_texture_rect(_art_tex, box, false, Color(1, 1, 1, 0.92))

## The gold frame is the page itself — what the canvas will actually keep.
## Anything outside it exists here and nowhere else.
func _draw_frame() -> void:
	var box: Rect2 = Rect2(to_screen(Vector2(page.position)),
		Vector2(page.size) * _zoom)
	_board.draw_rect(box, Color(GOLD.r, GOLD.g, GOLD.b, 0.10), true)
	_board.draw_rect(box, GOLD, false, 2.4)
	var corner: float = minf(box.size.x, box.size.y) * 0.06
	for c in [[box.position, Vector2(1, 1)],
			[Vector2(box.end.x, box.position.y), Vector2(-1, 1)],
			[Vector2(box.position.x, box.end.y), Vector2(1, -1)],
			[box.end, Vector2(-1, -1)]]:
		var p: Vector2 = c[0]
		var d: Vector2 = c[1]
		_board.draw_line(p, p + Vector2(corner * d.x, 0.0), GOLD, 4.0)
		_board.draw_line(p, p + Vector2(0.0, corner * d.y), GOLD, 4.0)

func _draw_curve() -> void:
	if spline == null or spline.size() == 0:
		return
	# The control polygon, faint: it is the handle, not the shape.
	if spline.size() > 1:
		for i in range(1, spline.size()):
			_board.draw_line(to_screen(spline.points[i - 1]),
				to_screen(spline.points[i]),
				Color(IVORY.r, IVORY.g, IVORY.b, 0.22), 1.0)

	if spline.ready():
		var walk: PackedVector2Array = spline.walk(maxi(spline.size() * 24, 48))
		var line: PackedVector2Array = PackedVector2Array()
		for p in walk:
			line.append(to_screen(p))
		if line.size() > 1:
			_board.draw_polyline(line, Color(0.10, 0.09, 0.07, 0.55), 5.0)
			_board.draw_polyline(line, GOLD, 2.6)

	for i in spline.size():
		var s: Vector2 = to_screen(spline.points[i])
		var corner: bool = spline.sharpness(i) > 0
		_board.draw_circle(s + Vector2(1, 2), 9.0, Color(0, 0, 0, 0.35))
		if corner:
			# A corner point is square, because what it does to the curve is
			# categorically different from what a smooth one does.
			_board.draw_rect(Rect2(s - Vector2(8, 8), Vector2(16, 16)), IVORY, true)
			_board.draw_rect(Rect2(s - Vector2(8, 8), Vector2(16, 16)),
				Color("#8A7C58"), false, 2.0)
		else:
			_board.draw_circle(s, 8.0, IVORY)
			_board.draw_arc(s, 8.0, 0.0, TAU, 20, Color("#8A7C58"), 2.0)
		if i == _grab:
			_board.draw_arc(s, 13.0, 0.0, TAU, 24, GOLD, 2.0)

func _draw_bones() -> void:
	if _bone_drawing:
		var from: Vector2 = to_screen(_bone_from)
		var to: Vector2 = _board.get_local_mouse_position()
		if not _touches.is_empty():
			to = _touches[_touches.keys()[0]]
		var ok: bool = bone_fits(_bone_from, to_page(to))
		_board.draw_line(from, to,
			BONE_INK if ok else Color(0.85, 0.35, 0.30, 0.85), 3.0)

	for i in bones.size():
		var b: Bone = bones[i] as Bone
		_draw_bone(to_screen(b.a), to_screen(b.b), b.hinged)

## Drawn as a real bone shape rather than a line: a tapered spindle with a
## joint at each end, so which way it runs and where it pivots are both
## readable without a legend.
func _draw_bone(a: Vector2, b: Vector2, hinged: bool) -> void:
	var dir: Vector2 = b - a
	var span: float = dir.length()
	if span < 1.0:
		return
	dir = dir / span
	var side: Vector2 = Vector2(-dir.y, dir.x)
	var wide: float = clampf(span * 0.14, 4.0, 15.0)
	var neck: Vector2 = a + dir * (span * 0.22)

	var body: PackedVector2Array = PackedVector2Array([
		a, neck + side * wide, b, neck - side * wide])
	_board.draw_colored_polygon(body, Color(BONE_INK.r, BONE_INK.g, BONE_INK.b, 0.42))
	_board.draw_polyline(PackedVector2Array([a, neck + side * wide, b,
		neck - side * wide, a]), BONE_INK, 1.8)

	_board.draw_circle(a, wide * 0.82, IVORY)
	_board.draw_arc(a, wide * 0.82, 0.0, TAU, 20, Color("#8A7C58"), 2.0)
	if hinged:
		_board.draw_rect(Rect2(b - Vector2(wide, wide) * 0.72,
			Vector2(wide, wide) * 1.44), IVORY, true)
		_board.draw_rect(Rect2(b - Vector2(wide, wide) * 0.72,
			Vector2(wide, wide) * 1.44), Color("#8A7C58"), false, 2.0)
	else:
		_board.draw_circle(b, wide * 0.72, IVORY)
		_board.draw_arc(b, wide * 0.72, 0.0, TAU, 20, Color("#8A7C58"), 2.0)
