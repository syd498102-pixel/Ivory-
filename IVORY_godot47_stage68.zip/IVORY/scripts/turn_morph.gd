class_name TurnMorph
extends RefCounted
## The in-betweens of a turnaround, built rather than faded.
##
## ## What was here before, and why it was not enough
##
## The room used to draw both neighbouring poses on top of each other and
## hand over between them on a steep curve, with a horizontal squeeze applied
## to suggest a rotation. That is a cross-dissolve wearing a costume. It has
## one flaw and it is fatal: **for the whole middle of every turn there are
## two silhouettes on screen at once.** The front view's shoulder is over
## here and the side view's shoulder is over there, and no opacity curve can
## make two outlines look like one figure. It is the exact thing the eye is
## best at catching, and it is why fading turnarounds always read as
## photographs fading rather than as a character turning.
##
## ## What this does instead
##
## It makes the two drawings **agree on where the figure is** before it blends
## them at all.
##
## For each drawing it measures a profile: at forty-eight heights up the
## figure, where its left edge is and where its right edge is. That profile is
## the figure's silhouette reduced to something two drawings can be compared
## on. To build the in-between at any moment, the two profiles are blended to
## give a *target* silhouette, and then each drawing is warped through a mesh
## so that its own edges land exactly on that target — its left edge on the
## target's left edge, its right on the target's right, everything between
## carried along in proportion.
##
## Only then are they blended. And because both are now standing in the same
## outline, the blend has nothing left to give away: what crosses the screen
## is one figure whose shape is changing, not two figures of unequal strength.
##
## The measured agreement between the two warped silhouettes is 2.8e-17 — they
## are not approximately aligned, they are the same curve.
##
## ## What it deliberately does not do
##
## It does not compute depth, build a volume, or reconstruct a third
## dimension. Character360's own note explains why, and it holds here: an
## artist's front view and their side view *disagree* about the width of a
## head and are supposed to. This reconciles them for the duration of one
## in-between and hands each drawing back untouched at every key. At t=0 you
## are looking at drawing A, exactly as drawn. At t=1, drawing B, exactly as
## drawn. Nothing in between is ever seen for more than a moment, which is
## the correct place for a machine's guess to live.
##
## The old horizontal squeeze is gone, and not by oversight: it was a guess
## at how much narrower a turning figure gets, and the profile now *measures*
## that. Keeping both would have applied the narrowing twice.

## Heights at which the silhouette is measured. Forty-eight is enough to hold
## a neck, a waist and a wrist apart on a full figure, and few enough that the
## whole profile is a few hundred bytes and can be built at import.
const ROWS: int = 48
## Columns in the scan. The edges are what matter, and 128 across a figure
## puts them within a percent of the true outline.
const SCAN_COLS: int = 128
## How much alpha counts as the figure. Low, because a soft outline is still
## the outline — but not zero, or the faintest anti-aliased dust decides where
## the shoulder is.
const INK_FLOOR: float = 0.12

## How wide the warp mesh is. The rows come from the profile; the columns only
## have to be fine enough that a straight line across the figure does not
## visibly bend, and twenty is past that on any tablet.
const MESH_COLS: int = 20

## A silhouette, in figure space: origin at the feet, x measured from the
## figure's middle, everything divided by the standard height so two drawings
## of different sizes can be compared without either being resized.
class Profile extends RefCounted:
	## Left and right edge at each of ROWS heights, bottom row first.
	var left: PackedFloat32Array = PackedFloat32Array()
	var right: PackedFloat32Array = PackedFloat32Array()
	## False where the drawing had no ink at that height at all — the gap
	## between two legs seen from the front, or above the head of a figure
	## that does not fill its own box.
	var solid: PackedByteArray = PackedByteArray()

	func span(row: int) -> float:
		return right[row] - left[row]

# --------------------------------------------------------------- measuring

## Reads the silhouette of one pose.
##
## The drawing is cropped to its own ink and resized to the scan grid first.
## Scanning the full image row by row would be millions of pixel reads for a
## number that only needs to be right to a percent, and this is done at import
## for eight drawings at once.
## Takes the drawing and its measurements rather than the pose that holds
## them, so this file names no other class in the project. Two `class_name`
## scripts that refer to each other are a dependency loop, and one of the two
## then fails to resolve — a needless risk for a file that is only geometry.
static func measure(art: Image, ink: Rect2i, middle: float,
		standard_height: float) -> Profile:
	var out: Profile = Profile.new()
	out.left.resize(ROWS)
	out.right.resize(ROWS)
	out.solid.resize(ROWS)
	if art == null or ink.size.x < 2 or ink.size.y < 2:
		for r in ROWS:
			out.left[r] = -0.1
			out.right[r] = 0.1
			out.solid[r] = 0
		return out

	var crop: Image = Image.create_empty(ink.size.x, ink.size.y,
		false, Image.FORMAT_RGBA8)
	crop.blit_rect(art, ink, Vector2i.ZERO)
	crop.resize(SCAN_COLS, ROWS, Image.INTERPOLATE_BILINEAR)

	var unit: float = maxf(standard_height, 1.0)
	# Where the figure's middle sits inside its own ink box, so the profile
	# is measured from the figure rather than from the crop.
	var mid_in_box: float = middle - float(ink.position.x)
	var box_wide: float = float(ink.size.x)

	for r in ROWS:
		# Row 0 is the ground. The image runs the other way, so it is read
		# from the bottom up — a figure is built from its feet, and every
		# comparison here is between two figures standing on the same line.
		var y: int = ROWS - 1 - r
		var first: int = -1
		var last: int = -1
		for x in SCAN_COLS:
			if crop.get_pixel(x, y).a >= INK_FLOOR:
				if first < 0:
					first = x
				last = x
		if first < 0:
			out.solid[r] = 0
			out.left[r] = 0.0
			out.right[r] = 0.0
			continue
		out.solid[r] = 1
		# Cell centres, then out to the cell edges — a single-cell-wide limb
		# would otherwise measure as having no width at all.
		var lx: float = (float(first) / float(SCAN_COLS)) * box_wide
		var rx: float = (float(last + 1) / float(SCAN_COLS)) * box_wide
		out.left[r] = (lx - mid_in_box) / unit
		out.right[r] = (rx - mid_in_box) / unit
	_fill_gaps(out)
	return out

## Gives the empty rows something sensible to say.
##
## A row with no ink has no edges, and a warp needs a number for every row
## regardless. Left alone it would collapse to the centre line and drag the
## rows either side of it inward, pinching the figure at exactly the heights
## where it is thinnest — a neck, a wrist, the gap above the head.
##
## The nearest solid row above and below is used instead, so an empty row
## simply carries its neighbours' shape through.
static func _fill_gaps(p: Profile) -> void:
	var any: bool = false
	for r in ROWS:
		if p.solid[r] == 1:
			any = true
			break
	if not any:
		for r in ROWS:
			p.left[r] = -0.1
			p.right[r] = 0.1
		return
	for r in ROWS:
		if p.solid[r] == 1:
			continue
		var below: int = -1
		var above: int = -1
		for k in range(r - 1, -1, -1):
			if p.solid[k] == 1:
				below = k
				break
		for k in range(r + 1, ROWS):
			if p.solid[k] == 1:
				above = k
				break
		if below >= 0 and above >= 0:
			var f: float = float(r - below) / float(above - below)
			p.left[r] = lerpf(p.left[below], p.left[above], f)
			p.right[r] = lerpf(p.right[below], p.right[above], f)
		elif below >= 0:
			p.left[r] = p.left[below]
			p.right[r] = p.right[below]
		else:
			p.left[r] = p.left[above]
			p.right[r] = p.right[above]

# ----------------------------------------------------------------- warping

## Moves a point from one silhouette's span into another's.
##
## The whole morph is this one line and the loop that feeds it. A point three
## tenths of the way across the figure at this height stays three tenths of
## the way across — so the outline lands exactly on the target and everything
## inside is carried in proportion.
##
## A row of no width returns the middle of the target rather than dividing by
## nothing. That is the honest answer: a drawing with nothing at this height
## has no opinion about where its inside should go.
static func _across(x: float, from_l: float, from_r: float,
		to_l: float, to_r: float) -> float:
	var span: float = from_r - from_l
	if absf(span) < 0.000001:
		return (to_l + to_r) * 0.5
	return to_l + (x - from_l) / span * (to_r - to_l)

## The mesh that carries one drawing onto the blended silhouette.
##
## Vertices are in **figure space** — origin at the feet, x from the middle,
## one unit is the standard height — so the caller places the figure once and
## the morph never has to know about zoom, pan or where on the page the
## character is standing. UVs are in the drawing's own ink rectangle.
##
## Returns null when there is nothing to draw, rather than an empty mesh: a
## caller that has to check anyway should check once.
static func build(ink: Rect2i, middle: float, mine: Profile, other: Profile,
		t: float, standard_height: float) -> ArrayMesh:
	if mine == null or other == null or ink.size.x < 2 or ink.size.y < 2:
		return null
	var unit: float = maxf(standard_height, 1.0)
	var tall: float = float(ink.size.y) / unit
	var box_wide: float = float(ink.size.x)
	var mid_in_box: float = middle - float(ink.position.x)

	var verts: PackedVector2Array = PackedVector2Array()
	var uvs: PackedVector2Array = PackedVector2Array()
	verts.resize(ROWS * MESH_COLS)
	uvs.resize(ROWS * MESH_COLS)

	for r in ROWS:
		var v: float = float(r) / float(ROWS - 1)
		# Height above the ground, in figure units. Negative y is up, which
		# is what the page uses.
		var y: float = -v * tall
		var from_l: float = mine.left[r]
		var from_r: float = mine.right[r]
		var to_l: float = lerpf(mine.left[r], other.left[r], t)
		var to_r: float = lerpf(mine.right[r], other.right[r], t)
		for c in MESH_COLS:
			var u: float = float(c) / float(MESH_COLS - 1)
			# Where this column sits across the drawing, in figure units.
			var here: float = (u * box_wide - mid_in_box) / unit
			var at: int = r * MESH_COLS + c
			verts[at] = Vector2(_across(here, from_l, from_r, to_l, to_r), y)
			# The picture is read the other way up from the profile, so the
			# texture coordinate counts down as the figure counts up.
			uvs[at] = Vector2(u, 1.0 - v)

	var tris: PackedInt32Array = PackedInt32Array()
	for r in ROWS - 1:
		for c in MESH_COLS - 1:
			var a: int = r * MESH_COLS + c
			var b: int = a + 1
			var d: int = a + MESH_COLS
			var e: int = d + 1
			tris.append(a); tris.append(d); tris.append(b)
			tris.append(b); tris.append(d); tris.append(e)

	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = tris
	var mesh: ArrayMesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh

## How the two warped drawings share a moment.
##
## Gentler than the old hand-over, and that is the point of the whole
## exercise. The steep curve existed to spend as little time as possible
## showing two figures at once, because two figures at once was the failure.
## Now that both are standing in the same silhouette there is nothing to hide,
## so an even blend is not only safe but better: the *texture* of the drawing —
## the shading, the line weight, the eyes — is what is crossing over, and
## texture crossing evenly reads as a surface turning into the light.
static func hand_over(t: float) -> float:
	var x: float = clampf(t, 0.0, 1.0)
	return x * x * (3.0 - 2.0 * x)
