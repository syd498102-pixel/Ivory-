class_name Perf
extends RefCounted
## Watches how fast the device is actually drawing and adjusts what the app
## asks of it.
##
## Devices differ by more than an order of magnitude, and a setting that
## suits a fast tablet will crawl on a cheap phone while a setting that
## suits the phone wastes most of the tablet. Rather than guess from a model
## name, this measures the one number that matters — how long a frame takes
## — and moves between three tiers.
##
## It is deliberately slow to react. Nothing here should flicker between
## tiers because one frame happened to be busy: it takes a sustained stretch
## of slow frames to step down, and a longer stretch of fast ones to step
## back up.

enum Tier { LOW, MEDIUM, HIGH }

const SAMPLE: float = 0.5         # seconds per measurement
const DROP_MS: float = 26.0       # slower than this and something must give
const RAISE_MS: float = 13.0      # comfortably fast for a while: ask for more
const PATIENCE_DOWN: int = 2      # samples before easing off
const PATIENCE_UP: int = 8        # and rather more before asking for more

static var tier: int = Tier.HIGH

static var _clock: float = 0.0
static var _frames: int = 0
static var _slow: int = 0
static var _quick: int = 0

## Fed once per frame by the canvas.
static func tick(delta: float) -> void:
	_clock += delta
	_frames += 1
	if _clock < SAMPLE:
		return
	var average: float = (_clock / float(maxi(_frames, 1))) * 1000.0
	_clock = 0.0
	_frames = 0

	if average > DROP_MS:
		_slow += 1
		_quick = 0
	elif average < RAISE_MS:
		_quick += 1
		_slow = 0
	else:
		_slow = 0
		_quick = 0

	if _slow >= PATIENCE_DOWN and tier > Tier.LOW:
		tier -= 1
		_slow = 0
	elif _quick >= PATIENCE_UP and tier < Tier.HIGH:
		tier += 1
		_quick = 0

# ------------------------------------------------------------ what it buys

## Mipmaps are the first thing to go. They cost a full rebuild of a tile
## whenever a stroke settles, and what they buy — clean shrinking — is worth
## having but not worth stuttering for.
static func wants_mipmaps() -> bool:
	return tier == Tier.HIGH

## How many sleeping tiles may be woken in one frame. On a fast device this
## is unlimited so nothing ever appears soft; on a slow one it is rationed,
## because a burst of decompression is felt more than a moment of softness.
static func wake_budget() -> int:
	if tier == Tier.HIGH:
		return 1 << 20
	if tier == Tier.MEDIUM:
		return 6
	return 3

## Frames per second while nothing is happening.
static func idle_fps() -> int:
	if tier == Tier.LOW:
		return 8
	return 12

## Dabs held on the graphics card before folding them back into memory.
## Folding is a read back from the card, which stalls it, so a slow device
## does it less often and carries more work per frame instead.
static func fold_after() -> int:
	if tier == Tier.HIGH:
		return 600
	if tier == Tier.MEDIUM:
		return 900
	return 1400

# ------------------------------------------------- what the rig may spend

## How often a posed mesh is re-skinned while a clip plays, in frames.
##
## Posing is two separate costs and they are not the same size. Reading the
## pose is a handful of floats — it happens every frame on every device, so
## the *timing* of an animation is identical everywhere and a scene checked on
## a tablet plays back at the same speed on a phone.
##
## Pushing that pose through the mesh is the expensive half: every vertex of
## the skin re-weighted and re-uploaded. On a slow device that is rationed.
## The result is an animation that holds its shape for a frame at a time
## rather than one that runs slowly — which is the right trade, because a
## viewer forgives a pose held for two frames and does not forgive a scene
## that plays at half speed.
static func rig_solve_stride() -> int:
	if tier == Tier.HIGH:
		return 1
	if tier == Tier.MEDIUM:
		return 2
	return 3

## Whether secondary motion — hair and cloth trailing behind the main
## movement — is worth running at all.
##
## It is the first thing to go and the last to come back, because it is the
## only part of a rig nobody asked for directly: it is there to make motion
## look observed rather than drawn. A figure without it still animates. A
## figure that stutters does not.
static func wants_dynamics() -> bool:
	return tier == Tier.HIGH

## How many springs may be carried at once when dynamics do run. Long hair on
## a fast device; a suggestion of it on a middling one.
static func dynamics_budget() -> int:
	if tier == Tier.HIGH:
		return 256
	if tier == Tier.MEDIUM:
		return 64
	return 0

## Whether the timeline may draw the travel between rig keys as a live
## in-between rather than as two dots and a line.
##
## Drawing the tween means solving the pose once per pixel column of the band,
## which is real work for something that is only a hint. On a slow device the
## hint is dropped and the keys are still exactly where they are.
static func wants_tween_preview() -> bool:
	return tier != Tier.LOW

static func name_of_tier() -> String:
	if tier == Tier.HIGH:
		return "high"
	if tier == Tier.MEDIUM:
		return "medium"
	return "low"
