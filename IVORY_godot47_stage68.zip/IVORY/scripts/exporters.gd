class_name Exporters
extends RefCounted
## Every format the app can write, and nothing it cannot.
##
## Three of these are written by hand rather than handed to a library,
## because they are the formats that make the difference between "I made a
## picture" and "I can carry this into my working life":
##
##   PSD  — layers survive. Opening the file in Photoshop or Krita gives
##          back the layers as they were left, not a flattened print.
##   CBZ  — what comic readers actually open. It is a zip of pages in order,
##          which the engine can write directly.
##   PDF  — pages anyone can open, with the images embedded as JPEG.
##
## What is deliberately absent is a video encoder. That is not a small
## omission to paper over: real video needs a codec, which cannot live
## inside a project file. A numbered PNG sequence is what editing software
## expects to be handed anyway.

## Exports go somewhere the rest of the phone can see. An app-private
## folder is invisible to the gallery and to every other app, which makes a
## finished picture unreachable from the very tools it was made for.
static var _cached_dir: String = ""

static func out_dir() -> String:
	if _cached_dir != "":
		return _cached_dir
	var base: String = OS.get_system_dir(OS.SYSTEM_DIR_PICTURES)
	if base == "":
		base = OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)
	if base == "" or not DirAccess.dir_exists_absolute(base):
		base = "user://"          # desktop sandboxes and odd devices
	_cached_dir = base.rstrip("/") + "/IVORY"
	return _cached_dir

## Kept so older call sites still read correctly.
static func ensure_dir() -> String:
	var dir: String = out_dir()
	if DirAccess.make_dir_recursive_absolute(dir) != OK:
		# Refused — most likely storage permission. Fall back rather than
		# lose the export entirely.
		_cached_dir = "user://exports"
		DirAccess.make_dir_recursive_absolute(_cached_dir)
	return _cached_dir

static func stamp() -> String:
	return Time.get_datetime_string_from_system().replace(":", "-").replace("T", "_")

static func base_name(p: ProjectManager.Project) -> String:
	var n: String = p.title.validate_filename()
	if n == "":
		n = "project"
	return "%s_%s" % [n, stamp()]

# --------------------------------------------------------------- rendering

## Flattens a page — paper first, then every visible layer in order.
## Canvas pixels are premultiplied and blend_rect expects exactly that in
## its source, so the two meet without conversion.
static func render_page(p: ProjectManager.Project, page: int) -> Image:
	# A page below zero means the whole spread: every page composited side
	# by side exactly as it sits on the grid.
	if page < 0 and p.pages > 1:
		return _render_spread(p)
	var index: int = maxi(page, 0)
	var target: ProjectManager.Page = p.page_at(index)
	if target == null:
		return null
	var w: int = int(p.page.x)
	var h: int = int(p.page.y)
	if w <= 0 or h <= 0:
		return null
	var art: Image = target.stack.read_region(Rect2i(Vector2i.ZERO, Vector2i(w, h)))
	var sheet: Image = Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	sheet.fill(p.paper)
	if art != null:
		sheet.blend_rect(art, Rect2i(Vector2i.ZERO, Vector2i(w, h)), Vector2i.ZERO)
	return sheet

static func _render_spread(p: ProjectManager.Project) -> Image:
	var span: Vector2 = p.bounds().size
	var out: Image = Image.create_empty(int(span.x), int(span.y),
		false, Image.FORMAT_RGBA8)
	out.fill(Color(0.0, 0.0, 0.0, 0.0))
	for i in p.pages:
		var one: Image = render_page(p, i)
		if one == null:
			continue
		out.blit_rect(one, Rect2i(Vector2i.ZERO, Vector2i(one.get_width(),
			one.get_height())), Vector2i(p.page_offset(i)))
	return out

## One layer on its own, in ordinary (not premultiplied) colour, which is
## what every other program expects to receive.
static func render_layer(p: ProjectManager.Project, layer: LayerStack.Layer,
		_page: int) -> Image:
	var img: Image = layer.surface.read_region(
		Rect2i(Vector2i.ZERO, Vector2i(int(p.page.x), int(p.page.y))))
	if img == null:
		return null
	_to_straight(img)
	return img

static func _to_straight(img: Image) -> void:
	var w: int = img.get_width()
	var h: int = img.get_height()
	var d: PackedByteArray = img.get_data()
	for i in range(w * h):
		var o: int = i * 4
		var a: int = d[o + 3]
		if a == 0 or a == 255:
			continue
		d[o] = mini(int(float(d[o]) * 255.0 / float(a)), 255)
		d[o + 1] = mini(int(float(d[o + 1]) * 255.0 / float(a)), 255)
		d[o + 2] = mini(int(float(d[o + 2]) * 255.0 / float(a)), 255)
	img.set_data(w, h, false, Image.FORMAT_RGBA8, d)

# ------------------------------------------------------------ flat images

static func save_flat(p: ProjectManager.Project, fmt: String,
		per_page: bool) -> String:
	var dir: String = ensure_dir()
	var base: String = base_name(p)
	var count: int = p.pages if per_page else 1
	var last: String = ""
	for i in count:
		var img: Image = render_page(p, i if per_page else -1)
		if img == null:
			continue
		var suffix: String = ("_%03d" % (i + 1)) if per_page else ""
		var path: String = "%s/%s%s.%s" % [dir, base, suffix, fmt]
		if _write_image(img, path, fmt) == OK:
			last = path
	return last

static func _write_image(img: Image, path: String, fmt: String) -> int:
	if fmt == "jpg":
		var flat: Image = Image.create_empty(img.get_width(), img.get_height(),
			false, Image.FORMAT_RGBA8)
		flat.copy_from(img)
		flat.convert(Image.FORMAT_RGB8)
		return flat.save_jpg(path, 0.94)
	if fmt == "webp":
		return img.save_webp(path, false, 0.95)
	return img.save_png(path)

# ------------------------------------------------------- numbered sequence

## What editing software wants: one file per frame, zero padded so they sort
## correctly, plus a plain text note of the frame rate they belong to.
static func save_sequence(p: ProjectManager.Project) -> String:
	var folder: String = "%s/%s_frames" % [ensure_dir(), base_name(p)]
	DirAccess.make_dir_recursive_absolute(folder)
	var img: Image = render_page(p, -1)
	if img == null:
		return ""
	# Until the timeline exists there is one drawing, so the sequence is one
	# frame long. The layout is already the one the timeline will fill.
	var path: String = "%s/frame_0001.png" % folder
	if img.save_png(path) != OK:
		return ""
	var note: FileAccess = FileAccess.open("%s/frames.txt" % folder, FileAccess.WRITE)
	if note != null:
		note.store_line("fps=%d" % p.fps)
		note.store_line("frames=1")
		note.store_line("size=%dx%d" % [img.get_width(), img.get_height()])
		note.close()
	return folder

## All frames side by side on one image, with a text file describing the
## grid — the pair every game engine and web animation tool accepts.
static func save_sprite_sheet(p: ProjectManager.Project) -> String:
	var img: Image = render_page(p, -1)
	if img == null:
		return ""
	var path: String = "%s/%s_sheet.png" % [ensure_dir(), base_name(p)]
	if img.save_png(path) != OK:
		return ""
	var note: FileAccess = FileAccess.open(
		"%s/%s_sheet.txt" % [ensure_dir(), base_name(p)], FileAccess.WRITE)
	if note != null:
		note.store_line("columns=1")
		note.store_line("rows=1")
		note.store_line("frame=%dx%d" % [img.get_width(), img.get_height()])
		note.store_line("fps=%d" % p.fps)
		note.close()
	return path

# --------------------------------------------------------------------- CBZ

## A comic archive is a zip of pages named so they sort in reading order.
static func save_cbz(p: ProjectManager.Project) -> String:
	var path: String = "%s/%s.cbz" % [ensure_dir(), base_name(p)]
	var zip: ZIPPacker = ZIPPacker.new()
	if zip.open(path) != OK:
		return ""
	for i in p.pages:
		var img: Image = render_page(p, i)
		if img == null:
			continue
		var png: PackedByteArray = img.save_png_to_buffer()
		zip.start_file("%03d.png" % (i + 1))
		zip.write_file(png)
		zip.close_file()
	zip.close()
	return path

# --------------------------------------------------------------------- PDF

## A minimal but valid PDF: one page per drawing, each holding a JPEG that
## the reader decodes directly. Small files, and nothing exotic that an old
## reader might choke on.
static func save_pdf(p: ProjectManager.Project) -> String:
	var path: String = "%s/%s.pdf" % [ensure_dir(), base_name(p)]
	var f: FileAccess = FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return ""

	var jpegs: Array = []
	var sizes: Array = []
	for i in p.pages:
		var img: Image = render_page(p, i)
		if img == null:
			continue
		img.convert(Image.FORMAT_RGB8)
		jpegs.append(img.save_jpg_to_buffer(0.92))
		sizes.append(Vector2i(img.get_width(), img.get_height()))
	if jpegs.is_empty():
		f.close()
		return ""

	var n: int = jpegs.size()
	# Object numbering: 1 catalog, 2 page tree, then three objects per page.
	var offsets: Array = []
	var out: PackedByteArray = PackedByteArray()

	var put: Callable = func(text: String) -> void:
		out.append_array(text.to_utf8_buffer())
	var mark: Callable = func() -> void:
		offsets.append(out.size())

	put.call("%PDF-1.4\n")

	mark.call()
	put.call("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")

	var kids: String = ""
	for i in n:
		kids += "%d 0 R " % (3 + i * 3)
	mark.call()
	put.call("2 0 obj\n<< /Type /Pages /Count %d /Kids [%s] >>\nendobj\n" % [n, kids])

	for i in n:
		var page_id: int = 3 + i * 3
		var content_id: int = page_id + 1
		var image_id: int = page_id + 2
		var w: int = sizes[i].x
		var h: int = sizes[i].y

		mark.call()
		put.call(("%d 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %d %d] "
			+ "/Resources << /XObject << /Im0 %d 0 R >> >> /Contents %d 0 R >>\nendobj\n")
			% [page_id, w, h, image_id, content_id])

		var stream: String = "q %d 0 0 %d 0 0 cm /Im0 Do Q\n" % [w, h]
		mark.call()
		put.call("%d 0 obj\n<< /Length %d >>\nstream\n%s endstream\nendobj\n"
			% [content_id, stream.length(), stream])

		var data: PackedByteArray = jpegs[i]
		mark.call()
		put.call(("%d 0 obj\n<< /Type /XObject /Subtype /Image /Width %d /Height %d "
			+ "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode "
			+ "/Length %d >>\nstream\n") % [image_id, w, h, data.size()])
		out.append_array(data)
		put.call("\nendstream\nendobj\n")

	var xref: int = out.size()
	put.call("xref\n0 %d\n0000000000 65535 f \n" % (offsets.size() + 1))
	for off in offsets:
		put.call("%010d 00000 n \n" % int(off))
	put.call("trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n"
		% [offsets.size() + 1, xref])

	f.store_buffer(out)
	f.close()
	return path

# --------------------------------------------------------------------- PSD

## Photoshop's format, written by hand so layers survive the trip.
##
## Channels are stored uncompressed. Photoshop's RLE would make the file
## smaller, but uncompressed is the variant every reader agrees on, and a
## file that opens everywhere beats one that opens smaller.
static func save_psd(p: ProjectManager.Project) -> String:
	var w: int = int(p.page.x)
	var h: int = int(p.page.y)
	if w <= 0 or h <= 0 or w > 30000 or h > 30000:
		return ""

	var path: String = "%s/%s.psd" % [ensure_dir(), base_name(p)]
	var f: FileAccess = FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return ""

	var visible: Array = []
	for l in p.stack.layers:
		var img: Image = render_layer(p, l, -1)
		if img == null:
			continue
		visible.append({"layer": l, "image": img})
	if visible.is_empty():
		f.close()
		return ""

	var flat: Image = render_page(p, -1)

	# --- header ---
	f.store_buffer("8BPS".to_ascii_buffer())
	_u16(f, 1)                       # version
	for i in 6:
		f.store_8(0)                 # reserved
	_u16(f, 4)                       # channels: RGBA
	_u32(f, h)
	_u32(f, w)
	_u16(f, 8)                       # bits per channel
	_u16(f, 3)                       # RGB
	_u32(f, 0)                       # no colour mode data
	_u32(f, 0)                       # no image resources

	# --- layer section, built in memory so its length can be written first ---
	var layers_blob: PackedByteArray = _psd_layers(visible, w, h)
	_u32(f, layers_blob.size() + 4)
	_u32(f, layers_blob.size())
	f.store_buffer(layers_blob)

	# --- the flattened composite every reader falls back to ---
	_u16(f, 0)                       # raw
	f.store_buffer(_plane(flat, 0, w, h))
	f.store_buffer(_plane(flat, 1, w, h))
	f.store_buffer(_plane(flat, 2, w, h))
	f.store_buffer(_plane(flat, 3, w, h))
	f.close()
	return path

static func _psd_layers(entries: Array, w: int, h: int) -> PackedByteArray:
	var out: PackedByteArray = PackedByteArray()
	_bu16(out, entries.size())

	var plane_size: int = w * h + 2   # two bytes of compression flag each
	for e in entries:
		var l: LayerStack.Layer = e["layer"]
		_bu32(out, 0)
		_bu32(out, 0)
		_bu32(out, h)
		_bu32(out, w)
		_bu16(out, 4)                                  # four channels
		for ch in [-1, 0, 1, 2]:                       # A, R, G, B
			_bu16(out, ch & 0xFFFF)
			_bu32(out, plane_size)
		out.append_array("8BIM".to_ascii_buffer())
		out.append_array("norm".to_ascii_buffer())
		out.append(int(clampf(l.opacity, 0.0, 1.0) * 255.0))
		out.append(0)                                  # clipping
		out.append(0 if l.visible else 2)              # bit 1 = hidden
		out.append(0)                                  # filler

		var name_bytes: PackedByteArray = _pascal(l.title)
		_bu32(out, 4 + 4 + name_bytes.size())
		_bu32(out, 0)                                  # no mask
		_bu32(out, 0)                                  # no blending ranges
		out.append_array(name_bytes)

	for e in entries:
		var img: Image = e["image"]
		for ch in [3, 0, 1, 2]:                        # A, R, G, B
			_bu16(out, 0)                              # raw
			out.append_array(_raw_plane(img, ch, w, h))
	if out.size() % 2 == 1:
		out.append(0)
	return out

## One channel of an image as a flat byte plane, padded if the layer is
## smaller than the canvas.
static func _plane(img: Image, ch: int, w: int, h: int) -> PackedByteArray:
	return _raw_plane(img, ch, w, h)

static func _raw_plane(img: Image, ch: int, w: int, h: int) -> PackedByteArray:
	var out: PackedByteArray = PackedByteArray()
	out.resize(w * h)
	if img == null:
		out.fill(0)
		return out
	var iw: int = img.get_width()
	var ih: int = img.get_height()
	var d: PackedByteArray = img.get_data()
	for y in range(h):
		var row: int = y * w
		if y >= ih:
			continue
		for x in range(w):
			if x >= iw:
				continue
			out[row + x] = d[((y * iw) + x) * 4 + ch]
	return out

static func _pascal(text: String) -> PackedByteArray:
	var raw: PackedByteArray = text.substr(0, 250).to_utf8_buffer()
	var out: PackedByteArray = PackedByteArray()
	out.append(raw.size())
	out.append_array(raw)
	while out.size() % 4 != 0:
		out.append(0)
	return out

# PSD is big endian throughout; Godot writes little endian, hence these.
static func _u16(f: FileAccess, v: int) -> void:
	f.store_8((v >> 8) & 0xFF)
	f.store_8(v & 0xFF)

static func _u32(f: FileAccess, v: int) -> void:
	f.store_8((v >> 24) & 0xFF)
	f.store_8((v >> 16) & 0xFF)
	f.store_8((v >> 8) & 0xFF)
	f.store_8(v & 0xFF)

static func _bu16(b: PackedByteArray, v: int) -> void:
	b.append((v >> 8) & 0xFF)
	b.append(v & 0xFF)

static func _bu32(b: PackedByteArray, v: int) -> void:
	b.append((v >> 24) & 0xFF)
	b.append((v >> 16) & 0xFF)
	b.append((v >> 8) & 0xFF)
	b.append(v & 0xFF)

# --------------------------------------------------------------------- GIF

## Frame rates that divide 100 evenly. GIF measures delays in hundredths of
## a second, so 24 fps would become 25 and the whole clip would run four per
## cent fast — a mistake that is invisible until it is played beside sound.
const GIF_RATES: Array = [10, 12, 20, 25, 50]

static func gif_rate_for(fps: int) -> int:
	var best: int = 12
	var gap: int = 1 << 30
	for r in GIF_RATES:
		var d: int = absi(int(r) - fps)
		if d < gap:
			gap = d
			best = int(r)
	return best

## `width` of 0 keeps the full size. Anything smaller is the single biggest
## lever on file size, so the exporter offers it plainly.
static func save_gif(p: ProjectManager.Project, width: int) -> String:
	var dir: String = ensure_dir()
	var img: Image = render_page(p, -1)
	if img == null:
		return ""
	if width > 0 and img.get_width() > width:
		var scale: float = float(width) / float(img.get_width())
		img.resize(width, maxi(int(float(img.get_height()) * scale), 1),
			Image.INTERPOLATE_BILINEAR)
	img.convert(Image.FORMAT_RGBA8)

	# Until the timeline exists there is one drawing, so the clip is one
	# frame long. The call already takes a list, which is the shape the
	# timeline will hand it.
	var rate: int = gif_rate_for(p.fps)
	var data: PackedByteArray = GifEncoder.encode([img], int(100.0 / float(rate)))
	if data.is_empty():
		return ""
	var path: String = "%s/%s.gif" % [dir, base_name(p)]
	var f: FileAccess = FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return ""
	f.store_buffer(data)
	f.close()
	return path

## Animated WebP: full colour, real transparency, and a fraction of the
## size of the same clip as GIF, because the compression underneath is a
## video codec rather than one from 1987.
static func save_webp_anim(p: ProjectManager.Project, width: int) -> String:
	var dir: String = ensure_dir()
	var img: Image = render_page(p, -1)
	if img == null:
		return ""
	if width > 0 and img.get_width() > width:
		var scale: float = float(width) / float(img.get_width())
		img.resize(width, maxi(int(float(img.get_height()) * scale), 1),
			Image.INTERPOLATE_BILINEAR)
	img.convert(Image.FORMAT_RGBA8)

	# One drawing until the timeline exists. The call already takes a list,
	# which is the shape the timeline will hand it.
	var delay: int = int(1000.0 / float(clampi(p.fps, 1, 60)))
	var data: PackedByteArray = WebpAnim.encode([img], delay)
	if data.is_empty():
		return ""
	var path: String = "%s/%s.webp" % [dir, base_name(p)]
	var f: FileAccess = FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return ""
	f.store_buffer(data)
	f.close()
	return path

## Rough size of a GIF before spending a minute making one.
static func gif_estimate_mb(p: ProjectManager.Project, width: int, seconds: float) -> float:
	var w: float = float(width) if width > 0 else p.page.x
	var h: float = w * (p.page.y / maxf(p.page.x, 1.0))
	var per_frame: float = w * h * 0.25 / 1048576.0   # LZW on flat art
	return per_frame * float(gif_rate_for(p.fps)) * seconds
