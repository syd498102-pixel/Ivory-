class_name BrushLibrary
extends RefCounted

# Every brush is a stamp texture (white RGB, shaped alpha) plus dynamics.
# The stamp is tinted at draw time, so one texture serves every colour.

## Stamps are generated once and reused at every size. 256 means a 400px
## brush is being shrunk rather than stretched, which is the difference
## between a crisp edge and a soft one.
const STAMP_PX: int = 256

class Preset:
	var id: String = ""
	## Which family this belongs to, and which of its five shapes it is.
	## Variants share a family's rhythm — its spacing, its scatter, the way
	## it answers to speed — and differ only in the stamp itself. That is
	## what keeps five inks feeling like ink.
	var family: String = ""
	var variant: int = 0
	var name_en: String = ""
	var name_ar: String = ""
	## Built the first time this brush is actually painted with. Generating
	## all eight at 256 pixels on startup is around half a million pixel
	## operations before the first frame is shown, paid for brushes most
	## sessions never touch.
	var texture: ImageTexture = null
	var spacing: float = 0.10       # stamp gap as a fraction of size
	var scatter: float = 0.0        # random offset, fraction of size
	var angle_jitter: float = 0.0   # radians
	var size_jitter: float = 0.0    # fraction
	var follow_direction: bool = false
	var speed_thin: float = 0.0     # how much a fast stroke thins the mark
	var default_size: float = 22.0
	var default_opacity: float = 1.0

var presets: Array[Preset] = []

## A stamp is a fixed picture, so painting at 600 pixels from a 256 pixel
## stamp is asking one pixel to cover six — which is exactly the softness
## that shows up on large brushes. When a size asks for more than the stamp
## holds, a bigger one is generated once and kept.
var _large: Dictionary = {}

func _init() -> void:
	_build()

## The stamp to use at this size: the standard one until it would be
## stretched, then a purpose-built larger one.
func texture_for(index: int, dab_size: float) -> Texture2D:
	var p: Preset = get_preset(index)
	if p == null:
		return null
	if dab_size <= float(STAMP_PX) * 1.05:
		return standard_texture(p)
	if _large.has(p.id):
		return _large[p.id]
	var big: ImageTexture = _build_large(p)
	_large[p.id] = big
	return big

## Regenerates one preset's shape at double resolution. Done once per brush,
## the first time someone paints large with it.
func _build_large(p: Preset) -> ImageTexture:
	var keep: int = _px
	_px = STAMP_PX * 2
	var tex: ImageTexture = make_texture(_shape_for(p.id))
	_px = keep
	return tex

func get_preset(i: int) -> Preset:
	if presets.is_empty():
		return null
	return presets[clampi(i, 0, presets.size() - 1)]

## The standard stamp for a preset, generated on first use and kept.
func standard_texture(p: Preset) -> ImageTexture:
	if p == null:
		return null
	if p.texture == null:
		p.texture = make_texture(_shape_for(p.id))
	return p.texture

## One place that knows which shape belongs to which brush, used both for
## the standard stamp and for the larger one big sizes need.
## The stamp for one preset: its family decides the kind of mark, its
## variant decides which of the five.
func _shape_for(id: String) -> PackedFloat32Array:
	var parts: PackedStringArray = id.split("_")
	var family: String = parts[0]
	var v: int = int(parts[1]) if parts.size() > 1 else 0
	match family:
		"pen":
			match v:
				0: return round_buffer(0.94)          # clean liner
				1: return round_buffer(0.99)          # hard technical
				2: return _nib_buffer(0.95, 0.42, -PI * 0.25)   # chisel
				3: return _nib_buffer(0.90, 0.62, PI * 0.25)    # italic
				_: return _dry_buffer(0.92, 0.30, 0.35)         # pencil-ish
		"ink":
			match v:
				0: return round_buffer(0.55)          # soft round
				1: return round_buffer(0.20)          # wet, bleeding
				2: return _nib_buffer(0.60, 0.35, 0.0)          # broad nib
				3: return _dry_buffer(0.55, 0.11, 0.55)         # dry brush
				_: return _dry_buffer(0.35, 0.34, 0.70)         # rough ink
		"airbrush":
			match v:
				0: return round_buffer(0.0)
				1: return round_buffer(0.18)          # tighter core
				2: return round_buffer(0.35)          # nearly a soft round
				3: return _dry_buffer(0.05, 0.24, 0.50)         # speckled
				_: return _nib_buffer(0.0, 0.55, PI * 0.5)      # oval spray
		"watercolor":
			match v:
				0: return _watercolor_buffer(1337, 1.0)
				1: return _watercolor_buffer(4801, 0.55)        # broader wash
				2: return _watercolor_buffer(2209, 1.8)         # ragged edge
				3: return _watercolor_buffer(6633, 2.6)         # granulating
				_: return _watercolor_buffer(8842, 0.35)        # flat wash
		"paint":
			match v:
				0: return _bristle_buffer(4242, 1.0)
				1: return _bristle_buffer(1120, 0.5)            # few, fat
				2: return _bristle_buffer(9033, 1.8)            # dense
				3: return _bristle_buffer(3377, 1.35)           # flat brush
				_: return _dry_buffer(0.45, 0.09, 0.65)         # scrub
		"spruce":
			match v:
				0: return _spruce_buffer(777, 1.0)
				1: return _spruce_buffer(1414, 0.55)            # sparse
				2: return _spruce_buffer(2828, 1.7)             # thick
				3: return _spruce_buffer(5656, 2.4)             # bushy
				_: return _spruce_buffer(9999, 0.8)             # young
		"leaves":
			match v:
				0: return _leaves_buffer(2024, 1.0)
				1: return _leaves_buffer(1701, 0.45)            # scattered
				2: return _leaves_buffer(3141, 1.8)             # dense
				3: return _leaves_buffer(2718, 2.6)             # canopy
				_: return _leaves_buffer(1618, 0.7)             # sprig
		"light":
			# A hot core, a spread that falls away by inverse square, and
			# for two of them a flare. The five are genuinely different
			# lights rather than five sizes of the same one.
			match v:
				0: return _light_buffer(0.16, 0.22, 0)      # a bright bulb
				1: return _light_buffer(0.06, 0.10, 0)      # neon filament
				2: return _light_buffer(0.26, 0.42, 0)      # broad lamp
				3: return _light_buffer(0.14, 0.26, 4)      # four-point flare
				_: return _light_buffer(0.05, 0.58, 0)      # ambient haze
		"fur":
			match v:
				0: return _fur_buffer(5150, 1.0)
				1: return _fur_buffer(6060, 0.5)                # coarse
				2: return _fur_buffer(7070, 1.7)                # fine
				3: return _fur_buffer(8080, 2.4)                # thick pelt
				_: return _fur_buffer(9090, 0.75)               # short
	return round_buffer(0.7)

# ---------------------------------------------------------------- building

## Eight families, five shapes each.
##
## A family is a way of behaving: how far apart the stamps fall, how much
## they scatter and turn, whether they follow the stroke, how speed thins
## the mark. Its five variants share all of that and differ only in the
## stamp — so five inks feel like ink, and choosing among them is choosing a
## nib rather than a different tool.
const FAMILIES: Array = [
	# id, English, Arabic, spacing, scatter, angle jitter, size jitter,
	# follow, speed thin, size, opacity
	["pen", "Pen", "قلم", 0.06, 0.0, 0.0, 0.0, false, 0.25, 8.0, 1.0],
	["ink", "Ink", "حبر", 0.07, 0.0, 0.0, 0.0, false, 0.0, 16.0, 1.0],
	["watercolor", "Watercolor", "ألوان مائية", 0.16, 0.06, PI, 0.18,
		false, 0.0, 90.0, 0.35],
	["paint", "Paint", "دهان", 0.05, 0.0, 0.0, 0.08, true, 0.0, 60.0, 0.75],
	["spruce", "Spruce", "شجر صنوبر", 0.30, 0.22, 0.5, 0.35, false, 0.55,
		70.0, 1.0],
	["leaves", "Leaves", "أوراق شجر", 0.34, 0.30, PI, 0.40, false, 0.0,
		80.0, 1.0],
	["fur", "Fur", "فرو", 0.12, 0.0, 0.25, 0.25, true, 0.0, 55.0, 0.85],
	["airbrush", "Airbrush", "رذاذ", 0.04, 0.0, 0.0, 0.0, false, 0.0,
		70.0, 0.12],
	# Light falls very close together and never turns: a glow is a
	# continuous thing, and a gap between two dabs shows as a bead on the
	# stroke rather than as texture. It also never thins with speed —
	# light does not run out because a hand moved quickly.
	["light", "Light", "ضوء", 0.03, 0.0, 0.0, 0.0, false, 0.0, 64.0, 0.55],
]

## What each variant is called within its family. The same five words for
## every family, because they mean the same thing everywhere: the first is
## the plain one, and the rest are the ways it is usually varied.
const VARIANT_NAMES: Array = [
	["Plain", "عادية"],
	["Fine", "رفيعة"],
	["Broad", "عريضة"],
	["Rough", "خشنة"],
	["Soft", "ناعمة"],
]

## Light's five are different lights, not different sizes of one — so they
## are named for what they are rather than by the shared five words.
const LIGHT_NAMES: Array = [
	["Bulb", "مصباح"],
	["Filament", "خيط متوهج"],
	["Lamp", "ضوء واسع"],
	["Flare", "توهج نجمي"],
	["Haze", "ضباب ضوئي"],
]

const PER_FAMILY: int = 5

func _build() -> void:
	presets.clear()
	for row in FAMILIES:
		for v in PER_FAMILY:
			var p: Preset = Preset.new()
			p.family = String(row[0])
			p.variant = v
			p.id = "%s_%d" % [p.family, v]
			p.name_en = "%s %s" % [String(row[1]), String(VARIANT_NAMES[v][0])]
			p.name_ar = "%s %s" % [String(row[2]), String(VARIANT_NAMES[v][1])]
			p.spacing = float(row[3])
			p.scatter = float(row[4])
			p.angle_jitter = float(row[5])
			p.size_jitter = float(row[6])
			p.follow_direction = bool(row[7])
			p.speed_thin = float(row[8])
			p.default_size = float(row[9])
			p.default_opacity = float(row[10])
			_tune(p)
			presets.append(p)

## Small adjustments where a variant's shape asks for them. A dry stamp
## needs to fall closer together or the gaps in it become gaps in the line;
## a broad nib wants a little more room. Everything else stays as the
## family set it.
func _tune(p: Preset) -> void:
	match p.variant:
		1:
			# Fine: smaller, and it tapers a little more with speed, the way
			# a thin nib naturally does.
			p.default_size *= 0.68
			p.speed_thin = minf(p.speed_thin + 0.15, 0.85)
			p.size_jitter *= 0.6
		2:
			# Broad: wider, set further apart, and steadier — a broad mark
			# with the same jitter as a fine one looks ragged rather than
			# confident.
			p.default_size *= 1.35
			p.spacing *= 1.15
			p.size_jitter *= 0.5
			p.angle_jitter *= 0.5
		3:
			# Rough: the stamp has gaps in it, so the stamps must fall
			# closer together or its gaps become gaps in the line. A touch
			# more opacity makes up for the ink it loses.
			p.spacing *= 0.55
			p.default_opacity = minf(p.default_opacity * 1.15, 1.0)
			p.size_jitter = maxf(p.size_jitter, 0.10)
		4:
			# Soft: larger, closer, and lighter — it builds up rather than
			# covering in one pass, which is what soft means in practice.
			p.default_size *= 1.15
			p.spacing *= 0.8
			p.default_opacity *= 0.85

	# Light keeps its own names and its own rhythm.
	#
	# The shared tuning above is written for marks made of pigment, and two
	# of its rules are wrong for a glow: thinning with speed, which light
	# does not do, and the loose spacing a broad mark wants, which leaves a
	# glow beaded instead of continuous.
	if p.family == "light":
		p.speed_thin = 0.0
		p.spacing = minf(p.spacing, 0.035)
		p.name_en = "%s %s" % ["Light", String(LIGHT_NAMES[p.variant][0])]
		p.name_ar = "%s %s" % ["ضوء", String(LIGHT_NAMES[p.variant][1])]
		match p.variant:
			1:
				# A filament is thin and fierce.
				p.default_size = 26.0
				p.default_opacity = 0.85
			2:
				p.default_size = 130.0
				p.default_opacity = 0.40
			3:
				p.default_size = 90.0
				p.default_opacity = 0.60
			4:
				# Haze is meant to be built up in passes, never laid down
				# in one.
				p.default_size = 190.0
				p.default_opacity = 0.22

## The families, in order, for a panel that shows them as one row.
func families() -> Array:
	var out: Array = []
	for row in FAMILIES:
		out.append({"id": String(row[0]), "en": String(row[1]),
			"ar": String(row[2])})
	return out

func index_of(family_index: int, variant: int) -> int:
	return clampi(family_index, 0, FAMILIES.size() - 1) * PER_FAMILY \
		+ clampi(variant, 0, PER_FAMILY - 1)

func family_index_of(preset_index: int) -> int:
	var i: int = floori(float(clampi(preset_index, 0, presets.size() - 1)) / float(PER_FAMILY))
	return i

func variant_of(preset_index: int) -> int:
	return clampi(preset_index, 0, presets.size() - 1) % PER_FAMILY

# ---------------------------------------------------------------- helpers

## The shapes below were tuned on a 128px stamp. This keeps their
## proportions when the stamp grows, rather than re-tuning twenty numbers.
## The working size for the stamp being generated right now. Normally the
## constant; briefly doubled while a large variant is built.
var _px: int = STAMP_PX

## The shapes below were tuned on a 128px stamp. This keeps their
## proportions whatever the stamp is generated at.
var S: float = float(STAMP_PX) / 128.0

func _blank() -> PackedFloat32Array:
	S = float(_px) / 128.0
	var b: PackedFloat32Array = PackedFloat32Array()
	b.resize(_px * _px)
	b.fill(0.0)
	return b

## Soft dot blended with max() so overlapping dabs never bloom past 1.0.
func _dab(buf: PackedFloat32Array, cx: float, cy: float,
		radius: float, strength: float) -> void:
	var r: float = maxf(radius, 0.6)
	var x0: int = maxi(int(floor(cx - r)), 0)
	var x1: int = mini(int(ceil(cx + r)), _px - 1)
	var y0: int = maxi(int(floor(cy - r)), 0)
	var y1: int = mini(int(ceil(cy + r)), _px - 1)
	for y in range(y0, y1 + 1):
		var dy: float = float(y) - cy
		for x in range(x0, x1 + 1):
			var dx: float = float(x) - cx
			var d: float = sqrt(dx * dx + dy * dy) / r
			if d >= 1.0:
				continue
			var a: float = (1.0 - d * d) * strength
			var i: int = y * _px + x
			if a > buf[i]:
				buf[i] = a

func _line(buf: PackedFloat32Array, a: Vector2, b: Vector2,
		r0: float, r1: float, strength: float) -> void:
	var steps: int = maxi(int(a.distance_to(b) / maxf(r0, 0.8) * 1.6), 2)
	for s in range(steps + 1):
		var t: float = float(s) / float(steps)
		var p: Vector2 = a.lerp(b, t)
		_dab(buf, p.x, p.y, lerpf(r0, r1, t), strength)

func make_texture(buf: PackedFloat32Array) -> ImageTexture:
	var img: Image = Image.create_empty(_px, _px, false, Image.FORMAT_RGBA8)
	var bytes: PackedByteArray = PackedByteArray()
	bytes.resize(_px * _px * 4)
	for i in range(_px * _px):
		var a: int = int(clampf(buf[i], 0.0, 1.0) * 255.0)
		var o: int = i * 4
		bytes[o] = 255
		bytes[o + 1] = 255
		bytes[o + 2] = 255
		bytes[o + 3] = a
	img.set_data(_px, _px, false, Image.FORMAT_RGBA8, bytes)
	# Mipmaps matter more than they look: a 4px pen samples a 256px stamp,
	# and without them that is a lottery of single pixels — the source of
	# the crawling, sparkling edge on thin strokes.
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)

# ----------------------------------------------------------------- shapes

## A solid square of the current stamp size, for the square eraser.
func solid_buffer() -> PackedFloat32Array:
	var buf: PackedFloat32Array = _blank()
	buf.fill(1.0)
	return buf

func round_buffer(hardness: float) -> PackedFloat32Array:
	var buf: PackedFloat32Array = _blank()
	var c: float = float(_px) * 0.5
	var rad: float = c - 2.0
	var inner: float = clampf(hardness, 0.0, 0.98)
	for y in _px:
		for x in _px:
			var d: float = Vector2(float(x) - c + 0.5, float(y) - c + 0.5).length() / rad
			var a: float = 0.0
			if d < 1.0:
				a = 1.0 - smoothstep(inner, 1.0, d)
			buf[y * _px + x] = a
	return buf

## Light, built the way light behaves rather than the way a soft brush does.
##
## A soft round brush falls off in a smooth curve from the middle to the
## edge, and it reads as a blurry blob because nothing in the world dims like
## that. Light has two parts and they are not the same shape: a core that is
## simply *saturated* — as bright as the medium goes, flat across its whole
## width — and around it a spread that falls away by the inverse square of
## distance, which is the law light actually obeys. The two together give the
## small fierce middle and the long faint reach that the eye reads as
## something glowing, instead of something smudged.
##
## `spikes`, when asked for, adds a flare: the spread is doubled along a few
## directions and left alone elsewhere. That is what a lens does with a bright
## point, and it is why four-point stars appear around highlights in a
## photograph.
##
## The whole stamp is faded out over its last fifth. Without that, the spread
## would still be faintly alive when it reached the edge of the texture and
## every dab would carry a square boundary in it.
func _light_buffer(core: float, spread: float, spikes: int) -> PackedFloat32Array:
	var buf: PackedFloat32Array = _blank()
	var c: float = float(_px) * 0.5
	var rad: float = c - 2.0
	var reach: float = maxf(spread, 0.0001)
	for y in _px:
		for x in _px:
			var off: Vector2 = Vector2(float(x) - c + 0.5, float(y) - c + 0.5)
			var d: float = off.length() / rad
			if d >= 1.0:
				buf[y * _px + x] = 0.0
				continue
			# The core: full strength, easing out over its outer third so
			# there is no visible disc edge inside the glow.
			var v: float = 1.0 - smoothstep(core * 0.35, core, d)
			# The spread: inverse square, the law light obeys.
			var halo: float = 1.0 / (1.0 + (d / reach) * (d / reach))
			v = maxf(v, halo * 0.92)
			if spikes > 0:
				# Sharpened by raising to a high power, so a spike is a
				# narrow ray rather than a broad lobe.
				var along: float = absf(cos(off.angle() * float(spikes) * 0.5))
				var ray: float = pow(along, 14.0)
				v += ray * halo * 0.85
			buf[y * _px + x] = clampf(v, 0.0, 1.0) \
				* (1.0 - smoothstep(0.80, 1.0, d))
	return buf

## A nib: a round stamp squashed along one axis and turned.
##
## Drawing with it gives a line that thickens and thins with direction —
## what a chisel or an italic nib does, and what a plain disc never can.
## The corners are eased slightly so the ends of a stroke are not two hard
## points, which is the one place a squashed disc gives itself away.
func _nib_buffer(hardness: float, squash: float, angle: float) -> PackedFloat32Array:
	var buf: PackedFloat32Array = _blank()
	var c: float = float(_px) * 0.5
	var r: float = c - 2.0 * S
	var turn: Vector2 = Vector2(cos(angle), sin(angle))
	for y in _px:
		for x in _px:
			var d: Vector2 = Vector2(float(x) - c, float(y) - c)
			# Measured in the nib's own frame, so the squash follows the
			# angle rather than the screen.
			var along: float = d.dot(turn)
			var across: float = d.dot(Vector2(-turn.y, turn.x))
			# A superellipse rather than a plain ellipse: the exponent
			# rounds the two ends without fattening the middle.
			var u: float = absf(along) / r
			var v: float = absf(across) / (r * maxf(squash, 0.05))
			var reach: float = pow(pow(u, 2.4) + pow(v, 2.4), 1.0 / 2.4)
			var a: float = 0.0
			if reach < 1.0:
				a = 1.0 - smoothstep(clampf(hardness, 0.0, 0.98), 1.0, reach)
			buf[y * _px + x] = a
	return buf

## A dry stamp: a round one with its ink broken up, for a brush that has
## almost run out.
##
## Three things make this read as tooth on paper rather than as static:
##
##   The grain is *multiplied* in, never added, so the silhouette stays
##   round and only the coverage suffers.
##
##   Two frequencies are used together — a coarse one for the clumps and a
##   finer one for the tooth inside them. One frequency alone looks like
##   noise; two look like a surface.
##
##   The break-up strengthens toward the rim. A dry brush loses its edge
##   first and keeps ink longest in the middle, and doing this evenly is
##   what makes cheap dry brushes look like a photocopy.
func _dry_buffer(hardness: float, grain_size: float, bite: float) -> PackedFloat32Array:
	var buf: PackedFloat32Array = round_buffer(hardness)
	var coarse: FastNoiseLite = FastNoiseLite.new()
	coarse.set_seed(9091)
	coarse.noise_type = FastNoiseLite.TYPE_SIMPLEX
	coarse.frequency = grain_size / S

	var fine: FastNoiseLite = FastNoiseLite.new()
	fine.set_seed(3312)
	fine.noise_type = FastNoiseLite.TYPE_SIMPLEX
	fine.frequency = (grain_size * 3.1) / S

	var c: float = float(_px) * 0.5
	var rad: float = c - 2.0 * S
	for y in _px:
		for x in _px:
			var i: int = y * _px + x
			if buf[i] <= 0.0:
				continue
			var n: float = (coarse.get_noise_2d(float(x), float(y)) + 1.0) * 0.5
			var g: float = (fine.get_noise_2d(float(x), float(y)) + 1.0) * 0.5
			var tooth: float = n * 0.72 + g * 0.28
			var edge: float = clampf(
				Vector2(float(x) - c, float(y) - c).length() / rad, 0.0, 1.0)
			var strength: float = bite * (0.55 + 0.45 * edge)
			buf[i] *= clampf(1.0 - strength + tooth * strength * 1.9, 0.0, 1.0)
	return buf

func _watercolor_buffer(seed_at: int = 1337, edge_bite: float = 1.0) -> PackedFloat32Array:
	var buf: PackedFloat32Array = _blank()
	var c: float = float(_px) * 0.5
	var rad: float = c - 3.0

	var edge: FastNoiseLite = FastNoiseLite.new()
	edge.set_seed(seed_at)
	edge.noise_type = FastNoiseLite.TYPE_SIMPLEX
	edge.frequency = (0.020 * edge_bite) / S

	var grain: FastNoiseLite = FastNoiseLite.new()
	grain.set_seed(seed_at + 61)
	grain.noise_type = FastNoiseLite.TYPE_SIMPLEX
	grain.frequency = 0.16 / S

	for y in _px:
		for x in _px:
			var v: Vector2 = Vector2(float(x) - c + 0.5, float(y) - c + 0.5)
			var d: float = v.length() / rad
			var wobble: float = edge.get_noise_2d(float(x), float(y)) * 0.22
			var a: float = 1.0 - smoothstep(0.28 + wobble, 1.0 + wobble, d)
			if a <= 0.0:
				continue
			# paper grain, plus the darker rim real watercolour leaves behind
			var g: float = 0.72 + 0.28 * (grain.get_noise_2d(float(x), float(y)) * 0.5 + 0.5)
			var rim: float = 1.0 + 0.45 * smoothstep(0.55, 0.95, d)
			buf[y * _px + x] = clampf(a * g * rim, 0.0, 1.0)
	return buf

func _bristle_buffer(seed_at: int = 4242, bristle_density: float = 1.0) -> PackedFloat32Array:
	var buf: PackedFloat32Array = _blank()
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.set_seed(seed_at)
	var w: float = float(_px)
	for i in int(46.0 * S * bristle_density):
		var y: float = 8.0 * S + rng.randf() * (w - 16.0 * S)
		var thick: float = rng.randf_range(0.7, 2.0) * S
		var strength: float = rng.randf_range(0.35, 1.0)
		var sway: float = rng.randf_range(-3.0, 3.0) * S
		var prev: Vector2 = Vector2(4.0 * S, y)
		var seg: int = 6
		for s in range(1, seg + 1):
			var t: float = float(s) / float(seg)
			var p: Vector2 = Vector2(4.0 * S + (w - 8.0 * S) * t, y + sin(t * PI) * sway)
			_line(buf, prev, p, thick, thick, strength)
			prev = p
	# fade the two ends so consecutive stamps blend into a continuous streak
	for y2 in _px:
		for x2 in _px:
			var fx: float = absf(float(x2) - w * 0.5) / (w * 0.5)
			buf[y2 * _px + x2] *= 1.0 - smoothstep(0.75, 1.0, fx)
	return buf

func _spruce_buffer(seed_at: int = 777, branch_density: float = 1.0) -> PackedFloat32Array:
	var buf: PackedFloat32Array = _blank()
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.set_seed(seed_at)
	var c: Vector2 = Vector2(float(_px) * 0.5, float(_px) * 0.5)
	for i in int(9.0 * branch_density):
		var ang: float = rng.randf_range(0.0, TAU)
		var length: float = rng.randf_range(24.0, 52.0) * S
		var dir: Vector2 = Vector2(cos(ang), sin(ang))
		var base: Vector2 = c + dir * rng.randf_range(0.0, 16.0) * S
		var tip: Vector2 = base + dir * length
		_line(buf, base, tip, 2.2 * S, 0.8 * S, 0.95)
		var needles: int = 9
		for n in range(1, needles):
			var t: float = float(n) / float(needles)
			var along: Vector2 = base.lerp(tip, t)
			var nlen: float = (1.0 - t) * rng.randf_range(7.0, 13.0) * S
			for side in [-1.0, 1.0]:
				var na: float = ang + side * rng.randf_range(0.7, 1.15)
				_line(buf, along, along + Vector2(cos(na), sin(na)) * nlen,
					1.5 * S, 0.5 * S, rng.randf_range(0.5, 0.95))
	return buf

func _leaves_buffer(seed_at: int = 2024, leaf_density: float = 1.0) -> PackedFloat32Array:
	var buf: PackedFloat32Array = _blank()
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.set_seed(seed_at)
	var c: Vector2 = Vector2(float(_px) * 0.5, float(_px) * 0.5)
	for i in int(26.0 * S * leaf_density):
		var ang: float = rng.randf_range(0.0, TAU)
		var dist: float = sqrt(rng.randf()) * (float(_px) * 0.42)
		var pos: Vector2 = c + Vector2(cos(ang), sin(ang)) * dist
		var leaf_ang: float = rng.randf_range(0.0, TAU)
		var leaf_len: float = rng.randf_range(6.0, 13.0) * S
		var dir: Vector2 = Vector2(cos(leaf_ang), sin(leaf_ang))
		var strength: float = rng.randf_range(0.45, 1.0)
		# taper: thin at both tips, fat in the middle
		_line(buf, pos - dir * leaf_len, pos, 0.8 * S, 3.2 * S, strength)
		_line(buf, pos, pos + dir * leaf_len, 3.2 * S, 0.8 * S, strength)
	return buf

func _fur_buffer(seed_at: int = 5150, strand_density: float = 1.0) -> PackedFloat32Array:
	var buf: PackedFloat32Array = _blank()
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.set_seed(seed_at)
	var w: float = float(_px)
	for i in int(70.0 * S * strand_density):
		var x: float = rng.randf_range(6.0 * S, w - 6.0 * S)
		var y: float = rng.randf_range(6.0 * S, w - 6.0 * S)
		var ang: float = rng.randf_range(-0.55, 0.55)
		var length: float = rng.randf_range(9.0, 26.0) * S
		var dir: Vector2 = Vector2(cos(ang), sin(ang))
		_line(buf, Vector2(x, y), Vector2(x, y) + dir * length,
			1.6 * S, 0.4 * S, rng.randf_range(0.35, 1.0))
	# soften the border so tiled stamps do not show seams
	var c: float = w * 0.5
	for y2 in _px:
		for x2 in _px:
			var d: float = Vector2(float(x2) - c, float(y2) - c).length() / (c - 2.0)
			buf[y2 * _px + x2] *= 1.0 - smoothstep(0.7, 1.0, d)
	return buf
