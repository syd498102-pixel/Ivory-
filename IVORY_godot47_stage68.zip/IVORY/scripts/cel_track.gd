class_name CelTrack
extends RefCounted
## The drawings of one layer, one per frame, held in memory.
##
## This is the thing that was wrong before. Adding a frame used to add a
## layer, so a ten second scene meant two hundred and forty layers and a
## panel nobody could read. A frame is not a layer — it is the same layer at
## another moment, and it belongs here.
##
## Each cel is kept as a compressed image with the corner it sits at, so an
## empty frame costs almost nothing and a full one costs what its ink costs
## rather than the whole page. The layer keeps exactly one live surface; the
## playhead swaps what is in it.
##
## A cel holds until the next one. Draw on frame one and nothing else, and
## the whole clip shows that drawing — which is what a held pose is.

## Frame -> {"png": PackedByteArray, "at": Vector2i, "size": Vector2i}
var cels: Dictionary = {}
var _sorted_frames: Array[int] = []
var _frames_dirty: bool = true

## Which cel the live surface is currently holding, so it can be written
## back before another is loaded.
var loaded: int = -1

func _ensure_sorted() -> void:
	if not _frames_dirty:
		return
	_sorted_frames.clear()
	for key in cels.keys():
		_sorted_frames.append(int(key))
	_sorted_frames.sort()
	_frames_dirty = false

func frames() -> Array:
	_ensure_sorted()
	# Read-only by convention; callers only iterate this list. Avoiding a
	# duplicate here matters because the timeline asks for it every redraw.
	return _sorted_frames

func has_frame(frame: int) -> bool:
	return cels.has(frame)

func is_empty() -> bool:
	return cels.is_empty()

## The cel showing at this moment: the latest one at or before it.
func frame_showing(at: int) -> int:
	_ensure_sorted()
	if _sorted_frames.is_empty():
		return -1
	# Binary search for the last key <= at. This keeps scrubbing/playback
	# effectively O(log n) even on long clips with hundreds of cels.
	var lo: int = 0
	var hi: int = _sorted_frames.size() - 1
	var best: int = -1
	while lo <= hi:
		var mid: int = (lo + hi) >> 1
		var value: int = _sorted_frames[mid]
		if value <= at:
			best = value
			lo = mid + 1
		else:
			hi = mid - 1
	return best

## How long a cel is held — to the next one, or to the end of the clip.
func hold_length(frame: int, clip_end: int) -> int:
	_ensure_sorted()
	for one in _sorted_frames:
		if one > frame:
			return maxi(one - frame, 1)
	return maxi(clip_end - frame, 1)

# ------------------------------------------------------------- the surface

## Writes whatever is on the surface into the cel it belongs to.
##
## Stored compressed rather than as raw pixels: a page of line art packs to
## a fraction of its size, and a scene is hundreds of these.
func commit(surface: PaintSurface) -> void:
	if surface == null or loaded < 0:
		return
	# Pending GPU stamps must be folded into the CPU mirror before the cel is
	# serialized; otherwise a very recent dab can disappear during a seek.
	surface.flush()
	var box: Rect2i = surface.content_bounds()
	if box.size.x <= 0 or box.size.y <= 0:
		cels[loaded] = {"png": PackedByteArray(), "at": Vector2i.ZERO,
			"size": Vector2i.ZERO}
		_frames_dirty = true
		return
	var img: Image = surface.read_region(box)
	if img == null:
		return
	cels[loaded] = {"png": img.save_png_to_buffer(), "at": box.position,
		"size": box.size}
	_forget_cache(loaded)
	_frames_dirty = true

## The last image handed out, so scrubbing back and forth over the same few
## drawings does not decompress them again each time. Small on purpose: the
## point is the handful of frames a hand moves between, not the whole clip.
const CACHE: int = 6
var _cache: Dictionary = {}
var _cache_order: Array = []

func _cached(frame: int) -> Image:
	if _cache.has(frame):
		return _cache[frame]
	var img: Image = image_of(frame)
	if img == null:
		return null
	_cache[frame] = img
	_cache_order.append(frame)
	while _cache_order.size() > CACHE:
		_cache.erase(_cache_order.pop_front())
	return img

func _forget_cache(frame: int) -> void:
	_cache.erase(frame)
	_cache_order.erase(frame)

## Releases decompressed cel Images that are no longer useful. The PNG bytes
## remain authoritative, so pruning trades RAM for a future decode only.
func prune_cache(keep_frames: Array = []) -> void:
	var keep: Dictionary = {}
	for f in keep_frames:
		keep[int(f)] = true
	var i: int = 0
	while i < _cache_order.size():
		var frame: int = int(_cache_order[i])
		if keep.has(frame):
			i += 1
			continue
		_cache.erase(frame)
		_cache_order.remove_at(i)

func cache_bytes_estimate() -> int:
	var total: int = 0
	for frame in _cache.keys():
		var img: Image = _cache[frame]
		if img != null:
			total += img.get_width() * img.get_height() * 4
	return total

## Puts a cel onto the surface, replacing what was there.
func capture_surface(surface: PaintSurface, frame: int) -> void:
	if surface == null:
		return
	surface.flush()
	var box: Rect2i = surface.content_bounds()
	if box.size.x <= 0 or box.size.y <= 0:
		cels[frame] = {"png": PackedByteArray(), "at": Vector2i.ZERO,
			"size": Vector2i.ZERO}
	else:
		var img: Image = surface.read_region(box)
		if img == null:
			return
		cels[frame] = {"png": img.save_png_to_buffer(), "at": box.position,
			"size": box.size}
	_frames_dirty = true
	loaded = frame

func load_into(surface: PaintSurface, frame: int) -> void:
	if surface == null:
		return
	surface.clear_all()
	loaded = frame
	if not cels.has(frame):
		return
	var cel: Dictionary = cels[frame]
	if (cel["png"] as PackedByteArray).is_empty():
		return
	# Through the cache: flipping back and forth across a few drawings is
	# what an animator does constantly, and decompressing the same PNG on
	# every flip is what makes that feel sticky.
	var img: Image = _cached(frame)
	if img == null:
		return
	if img.get_format() != Image.FORMAT_RGBA8:
		img.convert(Image.FORMAT_RGBA8)
	# Written premultiplied, read back premultiplied, copied not blended —
	# so a frame looks the same however often it is swapped in and out.
	surface.blit_image(img, Vector2(cel["at"] as Vector2i), true)

## Moves the surface to the cel that should be showing, writing back first.
## Returns true when anything actually changed.
func show_frame(surface: PaintSurface, at: int, write_back: bool = true) -> bool:
	# A layer that has never entered animation must keep its ordinary static
	# drawing. The timeline should not erase it merely because the playhead
	# exists. Once the first cel is created, cels take ownership of the layer.
	if cels.is_empty():
		return false
	var want: int = frame_showing(at)
	if want < 0:
		if loaded == -1:
			return false
		if write_back:
			commit(surface)
		surface.clear_all()
		loaded = -1
		return true
	if want == loaded:
		return false
	if write_back:
		commit(surface)
	load_into(surface, want)
	return true

# ------------------------------------------------------------------- edits

## A new cel at this frame. `copy_previous` starts it from the drawing
## before it, which is what tracing a movement wants; otherwise it is blank,
## which is what starting a fresh pose wants.
func add_frame(surface: PaintSurface, frame: int, copy_previous: bool) -> void:
	commit(surface)
	if copy_previous:
		var from: int = frame_showing(frame - 1)
		if from >= 0 and cels.has(from):
			cels[frame] = (cels[from] as Dictionary).duplicate(true)
			_frames_dirty = true
		else:
			cels[frame] = {"png": PackedByteArray(), "at": Vector2i.ZERO,
				"size": Vector2i.ZERO}
	else:
		cels[frame] = {"png": PackedByteArray(), "at": Vector2i.ZERO,
			"size": Vector2i.ZERO}
	_frames_dirty = true
	load_into(surface, frame)

## Inserts a blank cel immediately after `frame`. Any existing cels at or
## after that position slide one frame to the right, preserving the exact
## drawing order and holds.
func insert_blank_after(surface: PaintSurface, frame: int) -> void:
	if surface != null:
		commit(surface)
	var insert_at: int = maxi(frame + 1, 0)
	var order: Array = frames().duplicate()
	order.reverse()
	for key in order:
		var old_frame: int = int(key)
		if old_frame < insert_at:
			continue
		var cel: Variant = cels[old_frame]
		cels.erase(old_frame)
		cels[old_frame + 1] = cel
		_forget_cache(old_frame)
		_frames_dirty = true
		if loaded == old_frame:
			loaded = old_frame + 1
	cels[insert_at] = {"png": PackedByteArray(), "at": Vector2i.ZERO,
		"size": Vector2i.ZERO}
	_frames_dirty = true
	loaded = insert_at
	if surface != null:
		surface.clear_all()

func remove_frame(frame: int) -> void:
	cels.erase(frame)
	_forget_cache(frame)
	_frames_dirty = true
	if loaded == frame:
		loaded = -1

## Slides a cel to another frame, and everything after it along with it when
## a hold is being lengthened.
func move_frame(from: int, to: int) -> void:
	if from == to or not cels.has(from):
		return
	var cel: Variant = cels[from]
	cels.erase(from)
	cels[to] = cel
	_forget_cache(from)
	_forget_cache(to)
	_frames_dirty = true
	if loaded == from:
		loaded = to

## Slides everything after a frame along, which is what lengthening a hold
## does to the drawings that follow it.
##
## The list is copied first. `frames()` hands back the track's own sorted
## cache rather than a copy — reversing it in place left that cache in the
## wrong order while the cels were being moved underneath it, and a frame
## could land on top of another one.
func shift_after(frame: int, by: int) -> void:
	if by == 0:
		return
	var order: Array = frames().duplicate()
	if by > 0:
		order.reverse()
	for f in order:
		var one: int = int(f)
		if one <= frame:
			continue
		var cel: Variant = cels[one]
		var to: int = maxi(one + by, frame + 1)
		if to == one:
			continue
		cels.erase(one)
		cels[to] = cel
		_forget_cache(one)
		_forget_cache(to)
		if loaded == one:
			loaded = to
		_frames_dirty = true

## A picture of one cel, for the timeline's row and for onion skins. Nothing
## is decompressed twice: the caller keeps what it is given.
func image_of(frame: int) -> Image:
	if not cels.has(frame):
		return null
	var cel: Dictionary = cels[frame]
	var png: PackedByteArray = cel["png"]
	if png.is_empty():
		return null
	var img: Image = Image.new()
	if img.load_png_from_buffer(png) != OK:
		return null
	return img

func origin_of(frame: int) -> Vector2i:
	if not cels.has(frame):
		return Vector2i.ZERO
	return (cels[frame] as Dictionary)["at"]

## Roughly what this track is costing, so the timeline can say so honestly.
func bytes() -> int:
	var total: int = 0
	for f in cels.keys():
		total += (cels[f]["png"] as PackedByteArray).size()
	return total

# ------------------------------------------------------------------ saving

func to_dict() -> Dictionary:
	var rows: Array = []
	for f in frames():
		var cel: Dictionary = cels[f]
		# An empty cel has nothing to encode, and handing empty bytes to
		# Marshalls is what printed
		#     to_dict(): Condition "ret.is_empty()" is true
		# on every save. A frame with no pixels is a frame with no pixels;
		# it is written as a hole and read back as one.
		var raw: PackedByteArray = cel["png"]
		if raw.is_empty():
			continue
		rows.append({
			"f": int(f),
			"x": (cel["at"] as Vector2i).x,
			"y": (cel["at"] as Vector2i).y,
			"png": Marshalls.raw_to_base64(raw),
		})
	return {"cels": rows}

func from_dict(doc: Dictionary) -> void:
	cels.clear()
	_frames_dirty = true
	loaded = -1
	for row in doc.get("cels", []):
		cels[int(row.get("f", 0))] = {
			"png": Marshalls.base64_to_raw(String(row.get("png", ""))),
			"at": Vector2i(int(row.get("x", 0)), int(row.get("y", 0))),
			"size": Vector2i.ZERO,
		}
