class_name LayerStack
extends Node2D
## The ordered pile of drawing layers, with folders.
##
## `layers` is one flat array in draw order: index 0 is the bottom of the
## picture, the last index is the top. A layer belonging to a folder carries
## that folder's id, and members of the same folder are always kept next to
## each other — so the flat array stays the single truth about what covers
## what, and folders are a view onto it rather than a second structure that
## could drift out of step.
##
## Nothing here destroys a layer. Removing one moves it off-stage into
## `_detached`, where it sleeps compressed until either the history brings
## it back or the history forgets it. That is what lets deleting a layer be
## as undoable as drawing a line.

signal changed()
signal active_changed(index: int)

const MAX_LAYERS: int = 24
const MAX_GROUPS: int = 8

class Layer:
	## The drawings of this layer, one per frame, in memory. A frame is the
	## same layer at another moment — it never becomes a layer of its own.
	var cels: CelTrack = CelTrack.new()
	var id: int = 0
	var title: String = ""
	var surface: PaintSurface = null
	var visible: bool = true
	var opacity: float = 1.0
	var locked: bool = false
	var group_id: int = 0
	## The bottom plate. It can be emptied but never removed, moved or
	## foldered, so the stack always has ground to stand on.
	var is_background: bool = false
	var thumb: ImageTexture = null
	## Written rather than drawn. The words and how they are set are kept
	## beside the pixels, so the layer can be restyled later instead of being
	## erased and typed again.
	## A light layer: it adds to what is beneath instead of covering it.
	var glow: bool = false
	## A turnaround. The eight drawings and the angle stay on the layer, so
	## the figure can still be turned after it has been placed — the pixels
	## are only ever the pose it happens to be facing.
	var is_360: bool = false
	var character: Character360 = null
	var rig_360: Rig360 = null
	var turn_360: float = 0.0
	## How much of the rig is shown, each 0 to 1. Nothing here is ever drawn
	## into the pixels; it only governs what the room puts on screen.
	var show_bones: float = 1.0
	var show_points: float = 1.0
	var show_rings: float = 1.0
	var is_text: bool = false
	var text_state: Dictionary = {}
	## Where the writing sits and how far it is turned. Kept apart from the
	## pixels so it can be moved and turned any number of times without the
	## letters being resampled once — every move re-renders from the words,
	## so text never softens the way a rotated picture of text does.
	var text_at: Vector2 = Vector2.ZERO
	var text_turn: float = 0.0
	## The curve and bones this layer was last posed with. Kept on the layer
	## so returning to the B-Spline room finds the figure standing where it
	## was left rather than flat again.
	var rig: Dictionary = {}
	## And the poses that rig takes over time.
	##
	## Beside `cels`, and for the same reason: `cels` is what this layer is
	## drawn as at each moment, `poses` is what it is bent into. A layer may
	## carry either, both, or neither — a rigged cut-out has poses and one
	## drawing; a hand-drawn walk has drawings and no poses; a mouth chart
	## has neither and is switched instead.
	var poses: RigTrack = RigTrack.new()

	## The black ring drawn round this layer's mouth, if one was drawn.
	##
	## Null on every layer that is not a mouth, which is nearly all of them —
	## a layer carries this the way it carries a rig: only once it has been
	## given one.
	var mouth_ring: MouthRing = null
	## Which mouth shape this layer is holding right now, as a Viseme.Mouth.
	## Live state rather than saved state: it is worked out from the sound
	## every frame, so writing it down would only be a way of disagreeing
	## with the sound later.
	var mouth_now: int = 0

class Group:
	var id: int = 0
	var title: String = ""
	var visible: bool = true
	var opacity: float = 1.0
	var collapsed: bool = false
	var node: Node2D = null
	## An animation folder. It reads the bones of every layer inside it and
	## treats them as one skeleton, so an arm layer and a body layer move
	## together as a figure — while staying the separate layers they are. The
	## folder holds the rig; it never merges the drawings.
	var is_animation: bool = false

	## A switch folder: exactly one layer inside it is visible at a time.
	##
	## This is how a mouth chart works, and an eye chart, and a hand chart.
	## Twelve mouth shapes go in one folder, and the folder shows the one the
	## dialogue needs. Without it, lip sync means twelve visibility toggles
	## per syllable and there is no such thing as a fast expression change —
	## which is most of what makes a rig usable in production rather than
	## impressive in a demo.
	##
	## Note what it is *not*: it is not a new kind of layer, and it does not
	## merge or move anything. A switch folder is an ordinary folder that
	## answers one extra question when the stack works out what is visible.
	## Turn it off and every layer inside comes back exactly as it was.
	var is_switch: bool = false
	## Which member is showing, counted from the top of the folder as the
	## layers panel draws it. Clamped on read rather than on write, so
	## deleting a layer can never leave this pointing at nothing.
	var switch_index: int = 0

var layers: Array[Layer] = []
var groups: Array[Group] = []
var active_index: int = 0

## While one layer is being looked at on its own, everything else steps
## aside. Kept here rather than in the panel, because _apply_looks rewrites
## visibility on every change and would otherwise stomp on it.
var solo_id: int = 0

## Which folder the panel is pointing at, or 0 when a layer is. Kept apart
## from `active_index` because "the folder is selected" and "a layer inside
## it is selected" have to lead to different things when a new layer is
## added, and one number cannot say both.
var active_group: int = 0

var history: History = null

var _detached: Dictionary = {}      # layer id -> Layer, waiting in the wings
var _next_layer_id: int = 1
var _next_group_id: int = 1

func _ready() -> void:
	if layers.is_empty():
		var bg: Layer = _spawn_layer()
		bg.is_background = true
		bg.title = "Background"
		layers.append(bg)
		var first: Layer = _spawn_layer()
		layers.append(first)
		active_index = 1
		_rebuild()

# ------------------------------------------------------------------ access

func active() -> Layer:
	if layers.is_empty():
		return null
	return layers[clampi(active_index, 0, layers.size() - 1)]

func active_surface() -> PaintSurface:
	var l: Layer = active()
	if l == null:
		return null
	return l.surface

func by_id(id: int) -> Layer:
	for l in layers:
		if l.id == id:
			return l
	if _detached.has(id):
		return _detached[id]
	return null

func surface_by_id(id: int) -> PaintSurface:
	for l in layers:
		if l.id == id:
			return l.surface
	return null

func group_by_id(id: int) -> Group:
	for g in groups:
		if g.id == id:
			return g
	return null

func can_draw() -> bool:
	var l: Layer = active()
	if l == null or not l.visible or l.locked:
		return false
	var g: Group = group_by_id(l.group_id)
	if g != null and not g.visible:
		return false
	return true

## Flat index of the highest member of a folder, or -1 if it has none.
## Whether this layer is allowed to gain new frames.
##
## A rigged figure is animated by moving its bones, not by drawing it again.
## Once bones are on a layer, a button that makes a fresh blank frame is not
## a help — it is a way to end up with a skeleton posed on one frame and an
## empty page on the next, which reads as the character vanishing. So on a
## rigged layer, and on everything inside an animation folder, the frame
## button stops making frames and only walks between the ones already there.
##
## Nothing is ever removed by this. It withholds an action; it does not undo
## one.
func frames_locked(l: Layer) -> bool:
	if l == null:
		return false
	# A turnaround is posed by turning it and moving its rig, never by
	# drawing it again — so it is locked for the same reason a boned layer
	# is, and by the same rule rather than a second one bolted alongside.
	if l.is_360:
		return true
	if not l.rig.is_empty():
		return true
	var g: Group = group_by_id(l.group_id)
	return g != null and g.is_animation

func active_frames_locked() -> bool:
	if layers.is_empty():
		return false
	return frames_locked(layers[clampi(active_index, 0, layers.size() - 1)])

## Every layer inside a folder, bottom first.
func layers_in_group(id: int) -> Array:
	var out: Array = []
	for l in layers:
		if l.group_id == id:
			out.append(l)
	return out

## Whether a folder has anything rigged inside it worth gathering.
func group_has_rig(id: int) -> bool:
	for l in layers_in_group(id):
		if not l.rig.is_empty():
			return true
	return false

func group_top_index(id: int) -> int:
	var top: int = -1
	for i in layers.size():
		if layers[i].group_id == id:
			top = i
	return top

## The drawings inside a folder, bottom first — the order a switch channel
## counts in.
func members_of(id: int) -> Array:
	var out: Array = []
	for l in layers:
		if l.group_id == id:
			out.append(l)
	return out

func member_count(id: int) -> int:
	var n: int = 0
	for l in layers:
		if l.group_id == id:
			n += 1
	return n

# ---------------------------------------------------------- switch folders

## Turns a folder into a chart, or back into an ordinary folder.
##
## Turning it on does not touch a single layer. Turning it off does not
## restore anything either — because nothing was taken away: the layers kept
## their own `visible` flags the whole time, and `_apply_looks` simply stopped
## asking about them. That is the reason this is a folder flag and not a new
## layer type. A mouth chart that has to be dismantled to be edited is a
## mouth chart nobody edits.
func set_switch(id: int, on: bool) -> void:
	var g: Group = group_by_id(id)
	if g == null or g.is_switch == on:
		return
	g.is_switch = on
	_apply_looks()
	changed.emit()

## Which member of a chart is showing. Clamped against the folder's real
## contents on every read, so deleting the layer a chart was pointing at
## shows its neighbour instead of showing nothing.
func switch_index(id: int) -> int:
	var g: Group = group_by_id(id)
	if g == null:
		return 0
	var n: int = member_count(id)
	if n <= 0:
		return 0
	return clampi(g.switch_index, 0, n - 1)

## `announce` is false while a clip is playing.
##
## Changing which member a chart shows is two separate things: rewriting
## visibility, which is a handful of booleans, and telling the rest of the app
## the stack changed — which rebuilds the layers panel. During playback a
## mouth chart steps several times a second, and rebuilding a panel that many
## times a second to redraw rows nobody is looking at is exactly the kind of
## waste that heats a tablet for nothing. The pixels still change on every
## step; only the announcement is withheld.
func set_switch_index(id: int, index: int, announce: bool = true) -> void:
	var g: Group = group_by_id(id)
	if g == null or not g.is_switch:
		return
	var n: int = member_count(id)
	if n <= 0:
		return
	# Wraps rather than stops. Stepping through a mouth chart is a loop by
	# nature, and a chart that jams at its last shape makes the animator
	# reach for the first one by hand every cycle.
	var want: int = ((index % n) + n) % n
	if want == g.switch_index:
		return
	g.switch_index = want
	_apply_looks()
	if announce:
		changed.emit()

func step_switch(id: int, by: int) -> void:
	set_switch_index(id, switch_index(id) + by)

## Whether this layer is the one its chart is currently showing. A layer in
## an ordinary folder, or in none, always answers yes — it is not in a chart,
## so a chart has nothing to say about it.
func switch_shows(l: Layer) -> bool:
	var g: Group = group_by_id(l.group_id)
	if g == null or not g.is_switch:
		return true
	var mates: Array = members_of(g.id)
	var want: int = switch_index(g.id)
	return want < mates.size() and (mates[want] as Layer).id == l.id

# ------------------------------------------------------------------ record

func _snapshot() -> Array:
	return [{"t": "arrangement", "state": capture_arrangement()}]

func _record(label: String, steps: Array) -> void:
	if history != null:
		history.push(label, steps)

# --------------------------------------------------------- layer structure

func _spawn_layer() -> Layer:
	var l: Layer = Layer.new()
	l.id = _next_layer_id
	_next_layer_id += 1
	l.title = "Layer %d" % l.id
	l.surface = PaintSurface.new()
	l.surface.name = "Layer_%d" % l.id
	add_child(l.surface)
	return l

## `group_id` of -1 means "wherever the current layer lives", which is
## almost always what someone adding a layer means.
func add_layer(at: int = -1, group_id: int = -1) -> Layer:
	if layers.size() >= MAX_LAYERS:
		return null
	var before: Array = _snapshot()
	var l: Layer = _spawn_layer()

	if group_id >= 0:
		l.group_id = group_id
	elif not layers.is_empty():
		var near: Layer = layers[clampi(active_index, 0, layers.size() - 1)]
		if not near.is_background:
			l.group_id = near.group_id

	var index: int = layers.size()
	if at >= 0:
		index = clampi(at, 1, layers.size())
	layers.insert(index, l)
	active_index = index
	active_group = l.group_id
	_rebuild()
	_record(UiKit.label_for("New layer", "طبقة جديدة"), before)
	active_changed.emit(active_index)
	return l

## New layers land above the current one. If a folder is what is selected,
## the layer goes above the whole folder and stays outside it — putting it
## inside would mean a folder could never be built on top of.
func add_layer_here() -> Layer:
	if active_group != 0:
		var top: int = group_top_index(active_group)
		if top >= 0:
			return add_layer(top + 1, 0)
	return add_layer(active_index + 1)

## A copy dropped in directly above the original — the quickest safety net
## there is before trying something risky.
func duplicate_layer(index: int) -> Layer:
	if index < 0 or index >= layers.size() or layers.size() >= MAX_LAYERS:
		return null
	var before: Array = _snapshot()
	var src: Layer = layers[index]
	var copy: Layer = _spawn_layer()
	copy.title = src.title + " copy"
	copy.opacity = src.opacity
	copy.visible = src.visible
	copy.group_id = src.group_id
	copy.surface.blend_from(src.surface, 1.0)

	layers.insert(index + 1, copy)
	active_index = index + 1
	active_group = 0
	_rebuild()
	_record(UiKit.label_for("Duplicate layer", "نسخة مطابقة"), before)
	active_changed.emit(active_index)
	return copy

func can_remove(index: int) -> bool:
	if index < 0 or index >= layers.size():
		return false
	if layers[index].is_background:
		return false
	return layers.size() > 1

func remove_layer(index: int) -> void:
	if not can_remove(index):
		return
	var before: Array = _snapshot()
	_detach(layers[index])
	layers.remove_at(index)
	var next: int = active_index
	if active_index >= index:
		next = active_index - 1
	active_index = clampi(next, 0, maxi(layers.size() - 1, 0))
	active_group = 0
	_rebuild()
	_record(UiKit.label_for("Delete layer", "حذف طبقة"), before)
	active_changed.emit(active_index)

## Moves a layer to a new slot and, at the same time, into or out of a
## folder. Both happen at once because doing them one after the other would
## leave the array in a state that breaks the folder-members-are-adjacent
## rule in between.
func relocate(from: int, to: int, group_id: int) -> void:
	if from < 0 or from >= layers.size():
		return
	var l: Layer = layers[from]
	if l.is_background:
		return
	var dest: int = clampi(to, 1, layers.size())
	if dest > from:
		dest -= 1
	dest = clampi(dest, 1, maxi(layers.size() - 1, 1))
	if dest == from and l.group_id == group_id:
		return
	var before: Array = _snapshot()
	layers.remove_at(from)
	l.group_id = group_id
	layers.insert(dest, l)
	active_index = layers.find(l)
	active_group = 0
	_rebuild()
	_record(UiKit.label_for("Move layer", "نقل طبقة"), before)
	active_changed.emit(active_index)

func set_active(index: int) -> void:
	var i: int = clampi(index, 0, maxi(layers.size() - 1, 0))
	active_group = 0
	active_index = i
	active_changed.emit(active_index)

func set_active_group(id: int) -> void:
	active_group = id
	active_changed.emit(active_index)

func set_visible_at(index: int, on: bool) -> void:
	if index < 0 or index >= layers.size():
		return
	var before: Array = _snapshot()
	layers[index].visible = on
	_apply_looks()
	_record(UiKit.label_for("Show or hide", "إظهار وإخفاء"), before)
	changed.emit()

## Silent on purpose: this fires on every slider tick. The panel records one
## history entry when the finger lifts, so undoing a fade is one tap rather
## than two hundred.
func set_opacity_at(index: int, value: float) -> void:
	if index < 0 or index >= layers.size():
		return
	layers[index].opacity = clampf(value, 0.0, 1.0)
	_apply_looks()

## Light or paint. Changing it costs nothing but a swapped material, so it
## can be turned on after the fact on a layer already drawn.
func set_glow_at(index: int, on: bool) -> void:
	if index < 0 or index >= layers.size():
		return
	layers[index].glow = on
	_apply_looks()
	changed.emit()

func set_locked_at(index: int, on: bool) -> void:
	if index < 0 or index >= layers.size():
		return
	var before: Array = _snapshot()
	layers[index].locked = on
	_record(UiKit.label_for("Lock layer", "قفل طبقة"), before)
	changed.emit()

## Merging changes pixels *and* structure, so both go into one entry and one
## tap takes the whole thing back.
func merge_down(index: int) -> bool:
	if index <= 0 or index >= layers.size():
		return false
	var upper: Layer = layers[index]
	var lower: Layer = layers[index - 1]

	var touched: Dictionary = {}
	for c in upper.surface.get_tile_coords():
		touched[c] = lower.surface.snapshot_tile(c)
	var steps: Array = [
		{"t": "pixels", "layer": lower.id, "tiles": touched},
		{"t": "arrangement", "state": capture_arrangement()},
	]

	lower.surface.blend_from(upper.surface, upper.opacity if upper.visible else 0.0)
	_detach(upper)
	layers.remove_at(index)
	active_index = clampi(index - 1, 0, maxi(layers.size() - 1, 0))
	active_group = 0
	_rebuild()
	_record(UiKit.label_for("Merge layers", "دمج طبقتين"), steps)
	active_changed.emit(active_index)
	return true

func clear_layer(index: int) -> void:
	if index < 0 or index >= layers.size():
		return
	var l: Layer = layers[index]
	var tiles: Dictionary = {}
	for c in l.surface.get_tile_coords():
		tiles[c] = l.surface.snapshot_tile(c)
	l.surface.clear_all()
	_record(UiKit.label_for("Erase layer", "مسح طبقة"),
		[{"t": "pixels", "layer": l.id, "tiles": tiles}])
	changed.emit()

# --------------------------------------------------------- group structure

## Folders are never created empty: the selected layer walks in with them.
## That also lets a folder simply dissolve when its last member leaves,
## which removes a whole class of "empty folder in the way" problems.
func group_layer(index: int) -> Group:
	if index < 0 or index >= layers.size() or groups.size() >= MAX_GROUPS:
		return null
	var l: Layer = layers[index]
	if l.is_background or l.group_id != 0:
		return null
	var before: Array = _snapshot()
	var g: Group = Group.new()
	g.id = _next_group_id
	_next_group_id += 1
	g.title = "Group %d" % g.id
	g.node = Node2D.new()
	g.node.name = "Group_%d" % g.id
	add_child(g.node)
	groups.append(g)
	l.group_id = g.id
	_rebuild()
	_record(UiKit.label_for("New folder", "مجلد جديد"), before)
	changed.emit()
	return g

func ungroup_layer(index: int) -> void:
	if index < 0 or index >= layers.size() or layers[index].group_id == 0:
		return
	var before: Array = _snapshot()
	layers[index].group_id = 0
	_rebuild()
	_record(UiKit.label_for("Out of folder", "إخراج من مجلد"), before)
	changed.emit()

func set_group_visible(id: int, on: bool) -> void:
	var g: Group = group_by_id(id)
	if g == null:
		return
	var before: Array = _snapshot()
	g.visible = on
	_apply_looks()
	_record(UiKit.label_for("Show or hide folder", "إظهار مجلد"), before)
	changed.emit()

## Silent for the same reason as layer opacity — see set_opacity_at.
func set_group_opacity(id: int, value: float) -> void:
	var g: Group = group_by_id(id)
	if g == null:
		return
	g.opacity = clampf(value, 0.0, 1.0)
	_apply_looks()

## Folding is a way of looking, not a change to the picture, so it stays out
## of the history. Undo should never spend a tap on it.
func set_group_collapsed(id: int, on: bool) -> void:
	var g: Group = group_by_id(id)
	if g == null:
		return
	g.collapsed = on
	changed.emit()

## Empties a folder without touching the drawings inside it.
func dissolve_group(id: int) -> void:
	if group_by_id(id) == null:
		return
	var before: Array = _snapshot()
	for l in layers:
		if l.group_id == id:
			l.group_id = 0
	if active_group == id:
		active_group = 0
	_rebuild()
	_record(UiKit.label_for("Remove folder", "إزالة مجلد"), before)
	changed.emit()

func set_solo(id: int) -> void:
	solo_id = id
	_apply_looks()
	changed.emit()

# ------------------------------------------------------- arrangement state

## The whole shape of the document as plain numbers — order, folders,
## opacities, which layer is selected. A few hundred bytes, which is why
## structural undo costs almost nothing to keep.
func capture_arrangement() -> Dictionary:
	var rows: Array = []
	for l in layers:
		rows.append({
			"id": l.id,
			"group": l.group_id,
			"opacity": l.opacity,
			"visible": l.visible,
			"locked": l.locked,
			"title": l.title,
		})
	var folders: Array = []
	for g in groups:
		folders.append({
			"id": g.id,
			"title": g.title,
			"opacity": g.opacity,
			"visible": g.visible,
			"collapsed": g.collapsed,
			"switch": g.is_switch,
			"switch_index": g.switch_index,
			"animation": g.is_animation,
		})
	return {
		"layers": rows,
		"groups": folders,
		"active": active_index,
		"active_group": active_group,
		"solo": solo_id,
	}

func apply_arrangement(state: Dictionary) -> void:
	# Folders first, so layers have somewhere to point at.
	var wanted_groups: Dictionary = {}
	for row in state["groups"]:
		var id: int = int(row["id"])
		wanted_groups[id] = true
		var g: Group = group_by_id(id)
		if g == null:
			g = Group.new()
			g.id = id
			g.node = Node2D.new()
			g.node.name = "Group_%d" % id
			add_child(g.node)
			groups.append(g)
			_next_group_id = maxi(_next_group_id, id + 1)
		g.title = String(row["title"])
		g.opacity = float(row["opacity"])
		g.visible = bool(row["visible"])
		g.collapsed = bool(row["collapsed"])
		# Defaulted rather than required: undo states captured by an older
		# build carry none of these, and an arrangement that refused to load
		# because it predates a feature would turn undo into a crash.
		g.is_switch = bool(row.get("switch", false))
		g.switch_index = maxi(int(row.get("switch_index", 0)), 0)
		g.is_animation = bool(row.get("animation", g.is_animation))
	for i in range(groups.size() - 1, -1, -1):
		if wanted_groups.has(groups[i].id):
			continue
		if groups[i].node != null:
			groups[i].node.queue_free()
		groups.remove_at(i)

	var rebuilt: Array[Layer] = []
	var kept: Dictionary = {}
	for row in state["layers"]:
		var layer_id: int = int(row["id"])
		var l: Layer = by_id(layer_id)
		if l == null:
			continue
		if _detached.has(layer_id):
			_reattach(l)
		l.group_id = int(row["group"])
		l.opacity = float(row["opacity"])
		l.visible = bool(row["visible"])
		l.locked = bool(row["locked"])
		l.title = String(row["title"])
		rebuilt.append(l)
		kept[layer_id] = true

	# Anything the saved shape does not mention steps off-stage rather than
	# being destroyed — a redo may well want it back.
	for l in layers:
		if not kept.has(l.id):
			_detach(l)
	layers = rebuilt

	active_index = clampi(int(state["active"]), 0, maxi(layers.size() - 1, 0))
	active_group = int(state["active_group"])
	solo_id = int(state["solo"])
	_rebuild()
	changed.emit()
	active_changed.emit(active_index)

# --------------------------------------------------------------- off-stage

func _detach(l: Layer) -> void:
	if l == null or _detached.has(l.id):
		return
	l.surface.settle()
	l.surface.sleep_all()
	if l.surface.get_parent() != null:
		l.surface.get_parent().remove_child(l.surface)
	_detached[l.id] = l

func _reattach(l: Layer) -> void:
	_detached.erase(l.id)
	if l.surface.get_parent() == null:
		add_child(l.surface)

## Called by the history once it no longer remembers a layer.
func purge_detached(keep: Dictionary) -> void:
	for id in _detached.keys():
		if keep.has(id):
			continue
		var l: Layer = _detached[id]
		_detached.erase(id)
		l.surface.dispose()

# ------------------------------------------------------------ housekeeping

func _rebuild() -> void:
	_pack_groups()
	_drop_empty_groups()
	_reparent()
	_apply_looks()

## Pulls every folder's members together at the position of its lowest
## member, keeping their relative order. Called after any structural change,
## so nothing else in this file has to think about the adjacency rule.
func _pack_groups() -> void:
	var out: Array[Layer] = []
	var taken: Dictionary = {}
	for l in layers:
		if taken.has(l.id):
			continue
		if l.group_id == 0:
			out.append(l)
			taken[l.id] = true
			continue
		for m in layers:
			if m.group_id == l.group_id and not taken.has(m.id):
				out.append(m)
				taken[m.id] = true
	layers = out

func _drop_empty_groups() -> void:
	for i in range(groups.size() - 1, -1, -1):
		var g: Group = groups[i]
		if member_count(g.id) > 0:
			continue
		if active_group == g.id:
			active_group = 0
		if g.node != null:
			g.node.queue_free()
		groups.remove_at(i)

## Puts every surface under the right parent, then orders the parents and
## their children to match the flat array exactly.
func _reparent() -> void:
	for l in layers:
		var want: Node = self
		if l.group_id != 0:
			var g: Group = group_by_id(l.group_id)
			if g != null and g.node != null:
				want = g.node
		var had: Node = l.surface.get_parent()
		if had != want:
			if had != null:
				had.remove_child(l.surface)
			want.add_child(l.surface)

	var order: Array[Node] = []
	var seen: Dictionary = {}
	for l in layers:
		if l.group_id == 0:
			order.append(l.surface)
		elif not seen.has(l.group_id):
			seen[l.group_id] = true
			var order_group: Group = group_by_id(l.group_id)
			if order_group != null and order_group.node != null:
				order.append(order_group.node)
	for i in order.size():
		move_child(order[i], i)

	for g in groups:
		if g.node == null:
			continue
		var slot: int = 0
		for l in layers:
			if l.group_id == g.id:
				g.node.move_child(l.surface, slot)
				slot += 1

## A layer's final look is its own settings folded together with its
## folder's. Dimming a folder dims everything inside it, which is exactly
## what a folder is for.
## How sharp each layer currently is, 0 soft to 1 sharp. Written by the
## timeline whenever the playhead or the focus lines move.
var focus_sharpness: Dictionary = {}
var _blur_shader: Shader = null

## Depth of field, put on the layers.
##
## A folder speaks for everything under it: one focus line on the top layer of
## a folder makes the whole folder the subject, because a figure drawn across
## body, arm and head is one thing in the shot even though it is three layers
## in the stack. Asking for a line on each would be asking the artist to
## repeat what the folder already says.
func apply_focus(clip: Variant, frame: int) -> void:
	focus_sharpness.clear()
	if clip == null or not clip.focus_live(frame):
		for l in layers:
			_set_blur(l, 0.0)
		return

	# A folder is sharp if anything inside it is.
	var folder_sharp: Dictionary = {}
	for l in layers:
		if l.group_id == 0:
			continue
		var sharp: float = clip.focus_at(l.id, frame)
		if not folder_sharp.has(l.group_id):
			folder_sharp[l.group_id] = sharp
		else:
			folder_sharp[l.group_id] = maxf(float(folder_sharp[l.group_id]), sharp)

	for l in layers:
		var sharp: float = clip.focus_at(l.id, frame)
		if l.group_id != 0 and folder_sharp.has(l.group_id):
			sharp = maxf(sharp, float(folder_sharp[l.group_id]))
		focus_sharpness[l.id] = sharp
		_set_blur(l, 1.0 - sharp)

## The blur is a material on the layer itself, so it costs nothing at all
## while the radius is zero — which is every frame of every project that is
## not using depth of field.
func _set_blur(l: Layer, amount: float) -> void:
	if l == null or l.surface == null:
		return
	if amount > 0.004 and _blur_shader == null:
		_blur_shader = load("res://shaders/lens_blur.gdshader") as Shader
	l.surface.set_blur(amount, _blur_shader)

func _apply_looks() -> void:
	for l in layers:
		var alpha: float = l.opacity
		var shown: bool = l.visible
		var g: Group = group_by_id(l.group_id)
		if g != null:
			alpha *= g.opacity
			shown = shown and g.visible
		# A chart shows one member. Asked before solo, so that looking at a
		# single layer on its own still overrides everything — solo is a
		# thing the user is doing right now, and it should win.
		if g != null and g.is_switch and not switch_shows(l):
			shown = false
		if solo_id != 0:
			shown = l.id == solo_id
			alpha = l.opacity
		l.surface.visible = shown
		# Premultiplied pixels dim on every channel at once, so fading a
		# layer uses the same number in all four. Touching alpha alone would
		# leave colours too strong for the alpha carrying them and the layer
		# would look bruised instead of faint.
		l.surface.modulate = Color(alpha, alpha, alpha, alpha)
		l.surface.set_glow(l.glow)

# ------------------------------------------------------------- whole stack

func begin_frames(index: int, first_frame: int = 0) -> bool:
	if index < 0 or index >= layers.size():
		return false
	var l: Layer = layers[index]
	if l.cels.has_frame(first_frame):
		l.cels.load_into(l.surface, first_frame)
		return true
	l.cels.capture_surface(l.surface, first_frame)
	return true

func show_frame(at: int, write_back: bool = true) -> void:
	for l in layers:
		l.cels.show_frame(l.surface, at, write_back)

## Inserts one blank animation frame across every layer. All drawings and
## holds from the insertion point onward move together, so the scene stays
## synchronized.
func insert_blank_frame_after(frame: int) -> void:
	commit_all_cels()
	for l in layers:
		# Do not convert a non-animated static layer into an animated layer.
		# Existing animation tracks all shift together so timing remains aligned.
		if not l.cels.is_empty():
			l.cels.insert_blank_after(l.surface, frame)
	changed.emit()

func commit_all_cels() -> void:
	for l in layers:
		l.cels.commit(l.surface)

func update_view(view_world: Rect2, zoom: float) -> void:
	for l in layers:
		l.surface.update_view(view_world, zoom)

func flush_all() -> void:
	for l in layers:
		l.surface.flush()

func settle_all() -> void:
	for l in layers:
		l.surface.settle()
		var keep: Array = []
		if l.cels.loaded >= 0:
			keep.append(l.cels.loaded)
		l.cels.prune_cache(keep)

## What the eye sees at one point: every visible layer, bottom to top.
func sample(world_pos: Vector2) -> Color:
	var out: Color = Color(0.0, 0.0, 0.0, 0.0)
	for l in layers:
		if not l.surface.visible:
			continue
		var alpha: float = l.surface.modulate.a
		if alpha <= 0.001:
			continue
		var c: Color = l.surface.sample(world_pos)
		c.a *= alpha
		if c.a <= 0.0:
			continue
		var a: float = c.a + out.a * (1.0 - c.a)
		if a <= 0.0:
			continue
		out = Color(
			(c.r * c.a + out.r * out.a * (1.0 - c.a)) / a,
			(c.g * c.a + out.g * out.a * (1.0 - c.a)) / a,
			(c.b * c.a + out.b * out.a * (1.0 - c.a)) / a,
			a)
	return out

## Flattened pixels of a region — what the fill tool reads, so a fill on a
## clean layer still respects linework drawn on the layer below.
func read_region(rect: Rect2i) -> Image:
	if rect.size.x <= 0 or rect.size.y <= 0:
		return null
	var out: Image = Image.create_empty(rect.size.x, rect.size.y, false, Image.FORMAT_RGBA8)
	out.fill(Color(0.0, 0.0, 0.0, 0.0))
	for l in layers:
		if not l.surface.visible or l.surface.modulate.a <= 0.001:
			continue
		l.surface.read_region(rect, out)
	return out

# -------------------------------------------------------------- thumbnails

func refresh_thumb(index: int, px: int = 96) -> void:
	if index < 0 or index >= layers.size():
		return
	var l: Layer = layers[index]
	var box: Rect2i = l.surface.content_bounds()
	if box.size.x <= 0 or box.size.y <= 0:
		l.thumb = null
		return
	# Keep the read cheap no matter how far the drawing sprawls.
	var limit: int = 4096
	if maxi(box.size.x, box.size.y) > limit:
		var centre: Vector2i = box.position + Vector2i(roundi(float(box.size.x) * 0.5), roundi(float(box.size.y) * 0.5))
		var half: int = int(float(limit) * 0.5)
		box = Rect2i(centre - Vector2i(half, half), Vector2i(limit, limit))
	var img: Image = l.surface.read_region(box)
	if img == null:
		l.thumb = null
		return
	img.resize(px, px, Image.INTERPOLATE_BILINEAR)
	if l.thumb == null:
		l.thumb = ImageTexture.create_from_image(img)
	else:
		l.thumb.update(img)

func refresh_all_thumbs(px: int = 96) -> void:
	for i in layers.size():
		refresh_thumb(i, px)

# ----------------------------------------------------------------- display

## The panel's row list, top of the picture first. Each entry is either
## {"kind": "group", "gid": n} or {"kind": "layer", "index": n}.
func display_rows() -> Array:
	var rows: Array = []
	var i: int = layers.size() - 1
	while i >= 0:
		var l: Layer = layers[i]
		if l.group_id == 0:
			rows.append({"kind": "layer", "index": i})
			i -= 1
			continue
		var bottom: int = i
		while bottom - 1 >= 0 and layers[bottom - 1].group_id == l.group_id:
			bottom -= 1
		var g: Group = group_by_id(l.group_id)
		rows.append({"kind": "group", "gid": l.group_id})
		if g == null or not g.collapsed:
			for k in range(i, bottom - 1, -1):
				rows.append({"kind": "layer", "index": k})
		i = bottom - 1
	return rows
