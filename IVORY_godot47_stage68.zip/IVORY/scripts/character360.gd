class_name Character360
extends RefCounted
## A character read from a turnaround sheet, and turned.

## ## What this is, and what it is not
##
## Eight drawings of the same figure seen from eight directions. Scrubbed, it
## reads as a model on a turntable. It is not one: nothing here is three
## dimensional, nothing is projected, and no depth is ever computed. It is
## eight pictures and an honest account of how to get from one to the next.
##
## That distinction is load-bearing. A real 3D turn would need volume, and
## volume is exactly what a drawing does not have — an artist's front view and
## their side view disagree about the width of a head, and they are *supposed*
## to. Trying to reconcile them into a solid is how 2-D characters end up
## looking like melted clay. Keeping it flat keeps every drawing exactly as it
## was drawn, and asks the in-betweens to do only what in-betweens do.
##
## ## Reading the sheet
##
## Files are matched on the number they carry, not on their position in the
## folder — `01` is the front and the pose everything else is measured
## against, however the file browser happened to sort them. A sheet that skips
## a number still loads: the gap is left as a wider turn between its
## neighbours rather than refused.

## The eight compass points of a standard turnaround, in the order the
## numbers run.
const FACING: Array = [
	["01", "Front", "أمام"],
	["02", "Front right", "أمام يمين"],
	["03", "Right", "يمين"],
	["04", "Back right", "خلف يمين"],
	["05", "Back", "خلف"],
	["06", "Back left", "خلف يسار"],
	["07", "Left", "يسار"],
	["08", "Front left", "أمام يسار"],
]

## How far a pose may be off the common height before it is corrected.
## Turnarounds drawn by hand drift by a few pixels; anything past this is a
## different drawing, not a wobble.
const HEIGHT_SLACK: float = 0.18

class Pose extends RefCounted:
	## 0 to 7 — which way the figure is looking.
	var facing: int = 0
	## The number read off the filename, kept so a sheet that skips one can
	## still say what it has.
	var stamp: int = 1
	var art: Image = null
	var texture: ImageTexture = null
	## Where the ink sits in the file, and where the figure's feet and middle
	## are. Everything is aligned on these rather than on the image corner,
	## because a turnaround is only ever loosely centred.
	var ink: Rect2i = Rect2i()
	var height: float = 0.0
	var ground: float = 0.0
	var middle: float = 0.0
	## This drawing's outline, measured once at import. What makes the
	## in-betweens a morph rather than a fade — see `turn_morph.gd`.
	var shape: TurnMorph.Profile = null

var poses: Array = []
## The pose the rig is built on and every other one is measured against.
var master: int = 0
## The common height every pose was brought to.
var standard_height: float = 0.0

# ------------------------------------------------------------------ reading

## Reads a folder of images as a turnaround.
##
## Returns a report rather than just succeeding or failing, because a
## half-read sheet is the usual case and the user needs to know which drawing
## was the problem — "import failed" tells them nothing they can act on.
static func read_sequence(paths: PackedStringArray) -> Dictionary:
	var out: Character360 = Character360.new()
	var trouble: Array = []
	var found: Dictionary = {}

	for path in paths:
		var stamp: int = _stamp_of(path)
		if stamp <= 0:
			trouble.append({"path": path, "why": "no_number"})
			continue
		if found.has(stamp):
			trouble.append({"path": path, "why": "duplicate"})
			continue
		var img: Image = Image.load_from_file(path)
		if img == null:
			trouble.append({"path": path, "why": "unreadable"})
			continue
		if img.get_format() != Image.FORMAT_RGBA8:
			img.convert(Image.FORMAT_RGBA8)
		found[stamp] = img

	if found.is_empty():
		return {"ok": false, "character": null, "trouble": trouble,
			"why": "nothing_readable"}

	var stamps: Array = found.keys()
	stamps.sort()
	for stamp in stamps:
		var pose: Pose = Pose.new()
		pose.stamp = int(stamp)
		# The number *is* the direction. Eight views, so nine wraps back to
		# the front — a sheet numbered 1..16 at finer steps still lands each
		# drawing on the right side of the figure.
		pose.facing = (int(stamp) - 1) % FACING.size()
		pose.art = found[stamp]
		if not out._measure(pose):
			trouble.append({"path": "%02d" % int(stamp), "why": "blank"})
			continue
		out.poses.append(pose)

	if out.poses.is_empty():
		return {"ok": false, "character": null, "trouble": trouble,
			"why": "all_blank"}

	# 01 is the front and the master. If the sheet has no 01, the lowest
	# number takes its place rather than the import being refused.
	out.master = 0
	for i in out.poses.size():
		if (out.poses[i] as Pose).stamp == 1:
			out.master = i
			break

	out._level_heights()
	var thrown: Array = out._weed_out()
	out._make_textures()
	# Measured after levelling and weeding, so the profiles describe the
	# drawings that survived, at the height they were brought to.
	out.read_shapes()
	for row in thrown:
		trouble.append(row)
	return {"ok": true, "character": out, "trouble": trouble,
		"thrown": thrown, "count": out.poses.size()}

## The number in a filename, taken from the last run of digits.
##
## `01_FRONT.png`, `char_01.png` and `turn 1.png` all mean the same thing, and
## a sheet is rarely named the way the importer would have chosen.
static func _stamp_of(path: String) -> int:
	var base: String = path.get_file().get_basename()
	var digits: String = ""
	var best: String = ""
	for i in base.length():
		var c: String = base[i]
		if c >= "0" and c <= "9":
			digits += c
		else:
			if digits.length() > 0:
				best = digits
			digits = ""
	if digits.length() > 0:
		best = digits
	if best == "":
		return -1
	return int(best)

## Where the figure actually is inside its file.
func _measure(pose: Pose) -> bool:
	var used: Rect2i = pose.art.get_used_rect()
	if used.size.x < 2 or used.size.y < 2:
		return false
	pose.ink = used
	pose.height = float(used.size.y)
	# The feet, not the frame. A figure with a raised arm has a taller
	# bounding box and the same height, and lining the boxes up would have it
	# sink into the ground as it turned.
	pose.ground = float(used.position.y + used.size.y)
	pose.middle = float(used.position.x) + float(used.size.x) * 0.5
	return true

## Brings every pose to one height.
##
## A hand-drawn turnaround is never perfectly consistent — the side view comes
## out a few pixels shorter than the front, every time. Left alone, the figure
## visibly breathes as it turns, which is the single thing that gives away
## that this is eight drawings rather than one object.
##
## The common height is the **median**, not the average: one pose drawn badly
## wrong drags an average along with it and would rescale the seven good
## drawings to match the mistake. A median ignores it.
func _level_heights() -> void:
	if poses.is_empty():
		return
	var tall: Array = []
	for p in poses:
		tall.append((p as Pose).height)
	tall.sort()
	standard_height = float(tall[floori(float(tall.size()) / 2.0)])
	if standard_height <= 1.0:
		return

	for p in poses:
		var pose: Pose = p as Pose
		var factor: float = standard_height / maxf(pose.height, 1.0)
		if absf(factor - 1.0) < 0.004:
			continue
		if absf(factor - 1.0) > HEIGHT_SLACK:
			# Too far out to be drift. Rescaling it would be guessing at
			# what the artist meant; it is left as drawn.
			continue
		var want: Vector2i = Vector2i(
			maxi(int(round(float(pose.art.get_width()) * factor)), 1),
			maxi(int(round(float(pose.art.get_height()) * factor)), 1))
		var lifted: Image = pose.art.duplicate()
		lifted.resize(want.x, want.y, Image.INTERPOLATE_LANCZOS)
		pose.art = lifted
		_measure(pose)

## Throws out drawings that should not be in a turnaround.
##
## Two things go wrong with a real folder of exports, and both quietly ruin
## the turn rather than failing outright:
##
##   * **A repeat.** The same drawing exported twice under two numbers. Left
##     in, the figure stalls for a whole eighth of its turn and then jumps —
##     which reads as a stutter nobody can find the cause of.
##   * **A stray.** A drawing that is not this figure at all: a different
##     character, a note to self, a background plate that got swept into the
##     selection. Left in, the figure flickers into something else once per
##     revolution.
##
## Both are found by comparing the *shapes* rather than the pixels. A
## downsampled coverage map — where the ink is, at a coarse grid — is
## unaffected by colour, by antialiasing, and by a few pixels of drift, and
## two drawings of one figure from one angle agree on it almost exactly while
## two different figures do not.
func _weed_out() -> Array:
	var thrown: Array = []
	if poses.size() < 3:
		return thrown

	var maps: Array = []
	for p in poses:
		maps.append(_coverage(p as Pose))

	# --- repeats ---
	var keep: Array = []
	var keep_maps: Array = []
	for i in poses.size():
		var twin: int = -1
		for k in keep.size():
			if _apart(maps[i], keep_maps[k]) < 0.035:
				twin = k
				break
		if twin >= 0:
			thrown.append({"path": "%02d" % (poses[i] as Pose).stamp,
				"why": "repeat"})
			continue
		keep.append(poses[i])
		keep_maps.append(maps[i])

	# --- strays ---
	# Measured against the middle of the set rather than against the master,
	# because the master could itself be the odd one out and then everything
	# else would be thrown away instead.
	if keep.size() >= 4:
		var spread: Array = []
		for i in keep.size():
			var total: float = 0.0
			for k in keep.size():
				if k != i:
					total += _apart(keep_maps[i], keep_maps[k])
			spread.append(total / float(keep.size() - 1))
		var sorted_spread: Array = spread.duplicate()
		sorted_spread.sort()
		var middle: float = float(sorted_spread[floori(float(sorted_spread.size()) / 2.0)])
		var final: Array = []
		var final_maps: Array = []
		for i in keep.size():
			# Well beyond the middle of the set, and beyond an absolute floor
			# — a set of eight genuinely varied views should never have one
			# thrown out just for being the most distinctive of them.
			if float(spread[i]) > middle * 1.9 and float(spread[i]) > 0.34:
				thrown.append({"path": "%02d" % (keep[i] as Pose).stamp,
					"why": "stray"})
				continue
			final.append(keep[i])
			final_maps.append(keep_maps[i])
		keep = final

	if keep.size() >= 2:
		poses = keep
		# The master may have been one of the ones thrown out.
		master = 0
		for i in poses.size():
			if (poses[i] as Pose).stamp == 1:
				master = i
				break
	else:
		# Everything looked like everything else. Better to keep the sheet as
		# it came than to hand back one drawing and call it a turnaround.
		thrown.clear()
	return thrown

## Where the ink is, on a coarse grid, as a run of numbers between 0 and 1.
##
## Taken over the figure's own box rather than the file's, so a drawing that
## happens to sit further left is not called a different figure for it.
func _coverage(pose: Pose) -> PackedFloat32Array:
	var cells: int = 12
	var out: PackedFloat32Array = PackedFloat32Array()
	out.resize(cells * cells)
	if pose.art == null or pose.ink.size.x < 2 or pose.ink.size.y < 2:
		out.fill(0.0)
		return out
	var crop: Image = Image.create_empty(pose.ink.size.x, pose.ink.size.y,
		false, Image.FORMAT_RGBA8)
	crop.blit_rect(pose.art, pose.ink, Vector2i.ZERO)
	crop.resize(cells, cells, Image.INTERPOLATE_BILINEAR)
	for y in cells:
		for x in cells:
			out[y * cells + x] = crop.get_pixel(x, y).a
	return out

## How different two coverage maps are, from 0 (identical) to 1.
static func _apart(a: PackedFloat32Array, b: PackedFloat32Array) -> float:
	if a.size() != b.size() or a.is_empty():
		return 1.0
	var total: float = 0.0
	for i in a.size():
		total += absf(a[i] - b[i])
	return total / float(a.size())

## Measures every surviving pose's silhouette.
##
## Done here, once, rather than per frame: it is a crop, a resize and a scan
## of a small grid per drawing, which is nothing at import and would be
## everything at sixty frames a second.
func read_shapes() -> void:
	for p in poses:
		var pose: Pose = p as Pose
		pose.shape = TurnMorph.measure(pose.art, pose.ink, pose.middle,
			standard_height)

# ------------------------------------------------------------------ saving

## Writes the turnaround beside the project's layer images.
##
## The drawings go out as **PNG files next to the document**, exactly as the
## layers do, and never as text inside it. Eight full-size drawings encoded as
## base64 would be a document several megabytes long that has to be parsed in
## one gulp before anything at all can appear on screen — and it would be
## re-parsed on every load whether the turnaround is looked at or not.
##
## What goes into the document is the *measurements*: which drawing is which
## way round, where the ink sits in it, where the feet and middle are. Those
## are small, and they are the part that took work to arrive at.
##
## The silhouettes are deliberately **not** written. They are derived from the
## drawings, and derived state in a file is state that can come to disagree
## with what it was derived from. They are measured again on load, which costs
## a crop and a small scan per drawing.
func to_dict(dir: String, tag: String) -> Dictionary:
	var rows: Array = []
	for p in poses:
		var pose: Pose = p as Pose
		if pose.art == null:
			continue
		var file: String = "%s_pose_%02d.png" % [tag, pose.stamp]
		if pose.art.save_png("%s/%s" % [dir, file]) != OK:
			continue
		rows.append({
			"stamp": pose.stamp,
			"facing": pose.facing,
			"file": file,
			"ink_x": pose.ink.position.x, "ink_y": pose.ink.position.y,
			"ink_w": pose.ink.size.x, "ink_h": pose.ink.size.y,
			"height": pose.height, "ground": pose.ground,
			"middle": pose.middle,
		})
	if rows.is_empty():
		return {}
	return {"master": master, "standard": standard_height, "poses": rows}

## Reads a turnaround back.
##
## A drawing whose file has gone missing is skipped rather than fatal — a
## folder can be moved, synced badly, or half-copied, and seven eighths of a
## turnaround is far better than an error. What survives is re-measured from
## whatever is actually there.
static func from_dict(doc: Dictionary, dir: String) -> Character360:
	var rows: Array = doc.get("poses", [])
	if rows.is_empty():
		return null
	var out: Character360 = Character360.new()
	for row in rows:
		var file: String = String(row.get("file", ""))
		if file == "":
			continue
		var img: Image = Image.load_from_file("%s/%s" % [dir, file])
		if img == null:
			continue
		if img.get_format() != Image.FORMAT_RGBA8:
			img.convert(Image.FORMAT_RGBA8)
		var pose: Pose = Pose.new()
		pose.stamp = int(row.get("stamp", 1))
		pose.facing = int(row.get("facing", 0)) % FACING.size()
		pose.art = img
		pose.ink = Rect2i(
			int(row.get("ink_x", 0)), int(row.get("ink_y", 0)),
			int(row.get("ink_w", img.get_width())),
			int(row.get("ink_h", img.get_height())))
		pose.height = float(row.get("height", pose.ink.size.y))
		pose.ground = float(row.get("ground",
			pose.ink.position.y + pose.ink.size.y))
		pose.middle = float(row.get("middle",
			float(pose.ink.position.x) + float(pose.ink.size.x) * 0.5))
		# Measured again if the saved box does not describe this image —
		# a drawing edited outside the app, or a file that was replaced.
		if pose.ink.size.x < 2 or pose.ink.size.y < 2 \
				or pose.ink.position.x + pose.ink.size.x > img.get_width() \
				or pose.ink.position.y + pose.ink.size.y > img.get_height():
			if not out._measure(pose):
				continue
		out.poses.append(pose)
	if out.poses.is_empty():
		return null
	out.standard_height = float(doc.get("standard", 0.0))
	if out.standard_height <= 1.0:
		out._level_heights()
	out.master = clampi(int(doc.get("master", 0)), 0, out.poses.size() - 1)
	out._make_textures()
	out.read_shapes()
	return out

func _make_textures() -> void:
	for p in poses:
		var pose: Pose = p as Pose
		pose.texture = ImageTexture.create_from_image(pose.art)

# ------------------------------------------------------------------ turning

func count() -> int:
	return poses.size()

func pose_at(index: int) -> Pose:
	if poses.is_empty():
		return null
	return poses[posmod(index, poses.size())] as Pose

## Which two drawings a turn falls between, and how far along it is.
##
## `turn` is 0 to 1 around the whole figure, so it wraps: past the last pose
## it comes back to the first, because a turnaround is a circle.
func between(turn: float) -> Dictionary:
	var n: int = poses.size()
	if n == 0:
		return {}
	if n == 1:
		return {"a": poses[0], "b": poses[0], "t": 0.0}
	var walk: float = fposmod(turn, 1.0) * float(n)
	var i: int = int(floor(walk))
	var f: float = walk - float(i)
	return {"a": pose_at(i), "b": pose_at(i + 1), "t": f,
		"index_a": posmod(i, n), "index_b": posmod(i + 1, n)}

## How the two drawings share an in-between frame.
##
## Not a straight cross-fade. A plain dissolve shows both drawings at half
## strength in the middle, and two figures at half strength read as one ghost
## — the moment everybody recognises as "these are just photos fading". The
## curve here holds each pose at nearly full strength across most of its own
## stretch and hands over quickly in the middle, so what is on screen is
## almost always *a drawing* rather than an average of two.
static func hand_over(t: float) -> float:
	var x: float = clampf(t, 0.0, 1.0)
	# Steeper than smoothstep: flat at both ends, brisk through the middle.
	return x * x * x * (x * (x * 6.0 - 15.0) + 10.0)

## How wide a pose should be drawn at a given point in the turn.
##
## A figure turning away from the camera narrows, and it narrows as the cosine
## of the angle — that much *is* honest geometry and costs nothing to obey.
## Applying it lets the in-between read as a rotation instead of a slide, and
## it is the whole reason this looks like a turn rather than a dissolve.
## Never below a floor, or a profile view would vanish to a line.
static func foreshorten(from_facing: float, to_facing: float, t: float,
		total: int) -> float:
	var span: float = maxf(float(total), 1.0)
	var here: float = lerpf(from_facing, to_facing, t) / span * TAU
	return maxf(absf(cos(here)) * 0.22 + 0.78, 0.62)
